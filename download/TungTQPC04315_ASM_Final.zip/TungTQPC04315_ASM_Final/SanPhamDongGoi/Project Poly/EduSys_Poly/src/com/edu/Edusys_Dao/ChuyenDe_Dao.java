/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Entity.ChuyenDe;
import com.edu.Entity.NhanVien;
import com.edu.Helper.JDBC_Helper;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author tungt
 */
public class ChuyenDe_Dao extends Edusys_Dao<ChuyenDe, String> {
    String insert_Sql = "insert into chuyende values(?,?,?,?,?,?)";
    String update_Sql = "update chuyende set tenCD = ?, hocphi = ?, thoiluong = ?, hinh = ?,mota = ? where MaCD = ?";
    String delete_Sql = "delete from chuyende where MaCD = ?";
    String select_ALL = "select * from chuyende";
    String select_byid = "select * from chuyende where MaCD = ?";

    @Override
    public void insert(ChuyenDe entity) {
        JDBC_Helper.update(insert_Sql, entity.getMaCD(),entity.getTenCD(),entity.getHocPhi(),entity.getThoiLuong(),entity.getHinh(),entity.getMoTa());
    }

    @Override
    public void update(ChuyenDe entity) {
        JDBC_Helper.update(update_Sql,entity.getTenCD(),
                entity.getHocPhi(),entity.getThoiLuong(),entity.getHinh(),entity.getMoTa(), entity.getMaCD());
    }

    @Override
    public void delete(String key) {
        JDBC_Helper.update(delete_Sql, key);
    }

    @Override
    public List<ChuyenDe> selectALL() {
         return this.Select_by_sql(select_ALL);
    }

    @Override
    public ChuyenDe select_ById(String key) {
        List<ChuyenDe> list = this.Select_by_sql(select_byid, key);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<ChuyenDe> Select_by_sql(String sql, Object... args) {
        List<ChuyenDe> list = new ArrayList<ChuyenDe>();
        try {
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {                
                ChuyenDe e = new ChuyenDe();
                e.setMaCD(rs.getString("MaCD"));
                e.setTenCD(rs.getString("tenCD"));
                e.setHocPhi(rs.getDouble("hocphi"));
                e.setThoiLuong(rs.getInt("thoiluong"));
                e.setHinh(rs.getString("hinh"));
                e.setMoTa(rs.getString("mota"));
                list.add(e);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
