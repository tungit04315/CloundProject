/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Entity.NhanVien;
import com.edu.Helper.JDBC_Helper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class NhanVien_Dao extends Edusys_Dao<NhanVien, String> {

    String insert_Sql = "insert into Nhanvien values(?,?,?,?)";
    String update_Sql = "update nhanvien set matkhau = ?, hoten = ?, vaitro = ? where MaNV = ?";
    String delete_Sql = "delete from nhanvien where MaNV = ?";
    String select_ALL = "select * from nhanvien";
    String select_byid = "select * from nhanvien where MaNV = ?";

    @Override
    public void insert(NhanVien entity) {
        JDBC_Helper.update(insert_Sql, entity.getMaNV(), entity.getMatKhau(), entity.getHoTen(), entity.isVaiTro());
    }

    @Override
    public void update(NhanVien entity) {
        JDBC_Helper.update(update_Sql, entity.getMatKhau(), entity.getHoTen(), entity.isVaiTro(), entity.getMaNV());
    }

    @Override
    public void delete(String key) {
        JDBC_Helper.update(delete_Sql, key);
    }

    @Override
    public List<NhanVien> selectALL() {
        return this.Select_by_sql(select_ALL);
    }

    @Override
    public NhanVien select_ById(String key) {
        List<NhanVien> list = this.Select_by_sql(select_byid, key);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NhanVien> Select_by_sql(String sql, Object... args) {
        List<NhanVien> list = new ArrayList<NhanVien>();
        try {
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {                
                NhanVien e = new NhanVien();
                e.setMaNV(rs.getString("MaNV"));             
                e.setMatKhau(rs.getString("matkhau"));
                e.setHoTen(rs.getString("hoten"));
                e.setVaiTro(rs.getBoolean("vaitro"));
                list.add(e);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
