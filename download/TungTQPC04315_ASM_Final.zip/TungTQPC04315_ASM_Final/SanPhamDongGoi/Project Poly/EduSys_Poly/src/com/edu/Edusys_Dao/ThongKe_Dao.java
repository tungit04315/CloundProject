/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Helper.JDBC_Helper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class ThongKe_Dao {

    List<Object[]> getListOfArray(String sql, String[] cols, Object... args) {
        try {
            List<Object[]> list = new ArrayList<>();
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {
                Object[] values = new Object[cols.length];
                for (int i = 0; i < cols.length; i++) {
                    values[i] = rs.getObject(cols[i]);
                }
                list.add(values);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Object[]> getBangDiem(Integer maKH) {
        String sql = "{CALL sp_bangdiem(?)}";
        String cols[] = {"MaNH", "hoten", "diem"};
        return this.getListOfArray(sql, cols, maKH);
    }

    public List<Object[]> getLuongNguoiHoc() {
        String sql = "{CALL sp_thongkenguoihoc}";
        String[] cols = {"Nam", "Soluong", "Dautien", "Cuoicung"};
        return this.getListOfArray(sql, cols);
    }

    public List<Object[]> getDiemChuyenDe() {
        String sql = "{CALL sp_thongkediem}";
        String[] cols = {"tenCD", "SoHV", "thapnhat", "caonhat", "trungbinh"};
        return this.getListOfArray(sql, cols);
    }

    public List<Object[]> getDoanhThu(int nam) {
        String sql = "{CALL sp_thongkedoanhthu (?)}";
        String[] cols = {"tenCD", "SoKH", "SoHV", "Doanhthu", "thapnhat", "caonhat", "trungbinh"};
        return this.getListOfArray(sql, cols, nam);
    }
}
