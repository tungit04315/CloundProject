/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Class_Edusys.Icon_ShowPass;
import com.edu.Edusys_Dao.NhanVien_Dao;
import com.edu.Entity.NhanVien;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLNV_Edusys extends javax.swing.JDialog {

    NhanVien_Dao dao = new NhanVien_Dao();
    int index = -1;

    public QLNV_Edusys(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
    }

    public void init() {
        fillTable();
        this.index = -1;
        this.updateStatus();
    }

    public void insert() {
        NhanVien nv = getForm();
        String mk2 = new String(txt_xacNhanMacKhau.getPassword());
        if (!mk2.equalsIgnoreCase(nv.getMatKhau())) {
            MsgBox.alert(this, "Xác nhận mật khẩu không đúng");
        } else {
            try {
                dao.insert(nv);
                this.fillTable();
                this.clearForm();
                MsgBox.alert(this, "Thêm nhân viên thành công");
            } catch (Exception e) {
                MsgBox.alert(this, "Thêm nhân viên thất bại");
            }
        }
    }

    public void update() {
        NhanVien nv = getForm();
        String mk2 = new String(txt_xacNhanMacKhau.getPassword());
        if (!mk2.equalsIgnoreCase(nv.getMatKhau())) {
            MsgBox.alert(this, "Xác nhận mật khẩu không đúng");
            txt_xacNhanMacKhau.requestFocus();
        } else {
            try {
                dao.update(nv);
                this.fillTable();

                MsgBox.alert(this, "Cập Nhật nhân viên thành công");
            } catch (Exception e) {
                MsgBox.alert(this, "Cập Nhật nhân viên thất bại");
            }
        }
    }

    public void delete() {
        if (!Auth.isManager()) {
            MsgBox.alert(this, "Bạn không có quyền xoá nhân viên");
        } else {
            String maNV = txt_maNV.getText();
            if (maNV.equalsIgnoreCase(Auth.user.getMaNV())) {
                MsgBox.alert(this, "Bạn không được xoá chính bạn !!!");
            } else if (MsgBox.confirm(this, "Bạn thực sự muốn xoá nhân viên này")) {
                try {
                    dao.delete(maNV);
                    this.fillTable();
                    this.clearForm();
                    MsgBox.alert(this, "Xoá nhân viên thành công");
                } catch (Exception e) {
//                    e.printStackTrace();
                    MsgBox.alert(this, "Xoá nhân viên thất bại");
                }
            }
        }
    }

    public void clearForm() {
        NhanVien nv = new NhanVien();
        this.setForm(nv);
        this.index = -1;
        this.updateStatus();
    }

    public void edit() {
        String maNV = (String) tbl_QLNV.getValueAt(index, 0);
        NhanVien nv = dao.select_ById(maNV);
        this.setForm(nv);
        tabs_big.setSelectedIndex(1);
        this.updateStatus();
    }

    public void first() {
        index = 0;
        edit();
    }

    public void prev() {
        if (index > 0) {
            index--;
            edit();
        }
    }

    public void next() {
        if (index < tbl_QLNV.getRowCount() - 1) {
            index++;
            edit();
        }
    }

    public void last() {
        index = tbl_QLNV.getRowCount() - 1;
        edit();
    }

    public void fillTable() {
        DefaultTableModel model = (DefaultTableModel) tbl_QLNV.getModel();
        model.setRowCount(0);
        try {
            List<NhanVien> list = dao.selectALL();
            for (NhanVien nv : list) {
                Object[] row = {nv.getMaNV(), nv.getMatKhau(), nv.getHoTen(), nv.isVaiTro() ? "Trưởng Phòng" : "Nhân Viên"};
                model.addRow(row);
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    public void setForm(NhanVien nv) {
        txt_maNV.setText(nv.getMaNV());
        txt_hoTen.setText(nv.getHoTen());
        txt_macKhau.setText(nv.getMatKhau());
        txt_xacNhanMacKhau.setText(nv.getMatKhau());
        rdo_truongPhong.setSelected(nv.isVaiTro());
        rdo_nhanVien.setSelected(!nv.isVaiTro());
    }

    public NhanVien getForm() {
        NhanVien nv = new NhanVien();
        nv.setMaNV(txt_maNV.getText());
        nv.setHoTen(txt_hoTen.getText());
        nv.setMatKhau(new String(txt_macKhau.getPassword()));
        nv.setVaiTro(rdo_truongPhong.isSelected());
        return nv;
    }

    public void updateStatus() {
        boolean edit = (this.index >= 0);
        boolean first = (this.index == 0);
        boolean last = (this.index == tbl_QLNV.getRowCount() - 1);
        // trạng thái form 
        txt_maNV.setEditable(!edit);
        btn_them.setEnabled(!edit);
        btn_sua.setEnabled(edit);
        btn_xoa.setEnabled(edit);

        // trạng thái điều hướng
        btn_dauTien.setEnabled(edit && !first);
        btn_Sau.setEnabled(edit && !first);
        btn_Truoc.setEnabled(edit && !last);
        btn_cuoiCung.setEnabled(edit && !last);
    }

    public boolean check_input() {

        if (txt_maNV.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống mã nhân viên");
            txt_maNV.requestFocus();
            return false;
        }
        if (txt_macKhau.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống mật khẩu");
            txt_macKhau.requestFocus();
            return false;
        }
        if (txt_xacNhanMacKhau.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống ô xác nhận mật khẩu");
            txt_xacNhanMacKhau.requestFocus();
            return false;
        }
        if (txt_hoTen.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống họ tên");
            txt_hoTen.requestFocus();
            return false;
        }
//        boolean kq;
//        List<NhanVien> list = dao.selectALL();
//        for (int i = 0; i < list.size(); i++) {
//            kq = list.get(i).getMaNV().contains(txt_maNV.getText());
//            if (kq == true) {
//               MsgBox.alert(this, "Mã nhân viên không được phép trùng");
//               return false;
//            }
//        }

        if(txt_maNV.getText().length() > 7 || txt_maNV.getText().length() < 7){
            MsgBox.alert(this, "Mã nhân viên không được quá 7 ký tự hoặc ít hơn 7");
            txt_maNV.requestFocus();
            return false;
        } 
        return true;
    }

    public boolean kiemTraMaTrung() {
        boolean kq;
        List<NhanVien> list = dao.selectALL();
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaNV().contains(txt_maNV.getText());
            if (kq == true) {
                MsgBox.alert(this, "Mã nhân viên không được phép trùng");
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tabs_big = new javax.swing.JTabbedPane();
        pnl_list = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLNV = new javax.swing.JTable();
        pnl_edit = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_maNV = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_macKhau = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        txt_xacNhanMacKhau = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();
        txt_hoTen = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        rdo_truongPhong = new javax.swing.JRadioButton();
        rdo_nhanVien = new javax.swing.JRadioButton();
        btn_sua = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        btn_them = new javax.swing.JButton();
        btn_moi = new javax.swing.JButton();
        btn_dauTien = new javax.swing.JButton();
        btn_Sau = new javax.swing.JButton();
        btn_Truoc = new javax.swing.JButton();
        btn_cuoiCung = new javax.swing.JButton();
        lbl_showPassword = new javax.swing.JLabel();
        lbl_showPassword_2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                                  Quản Lý Nhân Viên");

        tbl_QLNV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã Nhân Viên", "Mật Khẩu", "Họ Tên", "Vai Trò"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_QLNV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLNVMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLNV);

        javax.swing.GroupLayout pnl_listLayout = new javax.swing.GroupLayout(pnl_list);
        pnl_list.setLayout(pnl_listLayout);
        pnl_listLayout.setHorizontalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 602, Short.MAX_VALUE)
        );
        pnl_listLayout.setVerticalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_listLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tabs_big.addTab("Danh Sách", pnl_list);

        pnl_edit.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Mã Nhân Viên  ");

        txt_maNV.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_maNVKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Mật Khẩu ");

        txt_macKhau.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_macKhauKeyPressed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Xác Nhận Mật Khẩu ");

        txt_xacNhanMacKhau.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_xacNhanMacKhauKeyPressed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Họ Tên ");

        txt_hoTen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_hoTenKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Vai Trò");

        buttonGroup1.add(rdo_truongPhong);
        rdo_truongPhong.setText("Trưởng Phòng");

        buttonGroup1.add(rdo_nhanVien);
        rdo_nhanVien.setSelected(true);
        rdo_nhanVien.setText("Nhân Viên");

        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_xoa.setText("Xoá");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_moi.setText("Mới");
        btn_moi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moiActionPerformed(evt);
            }
        });

        btn_dauTien.setText("|<");
        btn_dauTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dauTienActionPerformed(evt);
            }
        });

        btn_Sau.setText("<<");
        btn_Sau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SauActionPerformed(evt);
            }
        });

        btn_Truoc.setText(">>");
        btn_Truoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TruocActionPerformed(evt);
            }
        });

        btn_cuoiCung.setText(">|");
        btn_cuoiCung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cuoiCungActionPerformed(evt);
            }
        });

        lbl_showPassword.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/hide_Pass.png"))); // NOI18N
        lbl_showPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_showPasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_showPasswordMouseExited(evt);
            }
        });

        lbl_showPassword_2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/hide_Pass.png"))); // NOI18N
        lbl_showPassword_2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_showPassword_2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_showPassword_2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_showPassword_2MouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnl_editLayout = new javax.swing.GroupLayout(pnl_edit);
        pnl_edit.setLayout(pnl_editLayout);
        pnl_editLayout.setHorizontalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_maNV)
                    .addComponent(txt_hoTen)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_editLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_moi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(62, 62, 62)
                                .addComponent(btn_dauTien, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_Sau, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_Truoc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_cuoiCung, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_xacNhanMacKhau)
                            .addComponent(txt_macKhau, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(pnl_editLayout.createSequentialGroup()
                                        .addComponent(rdo_truongPhong, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(33, 33, 33)
                                        .addComponent(rdo_nhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(295, 295, 295)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_showPassword)
                            .addComponent(lbl_showPassword_2))
                        .addGap(8, 8, 8)))
                .addContainerGap())
        );
        pnl_editLayout.setVerticalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_maNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(28, 28, 28)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_showPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_macKhau))
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbl_showPassword_2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(txt_xacNhanMacKhau))
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_hoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdo_truongPhong)
                    .addComponent(rdo_nhanVien))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_moi))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_sua)
                    .addComponent(btn_xoa)
                    .addComponent(btn_dauTien)
                    .addComponent(btn_Sau)
                    .addComponent(btn_Truoc)
                    .addComponent(btn_cuoiCung))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabs_big.addTab("Câp Nhật", pnl_edit);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quản Lý Nhân Viên Quản Trị");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs_big)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs_big))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_QLNVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLNVMouseClicked
        if (evt.getClickCount() == 2) {
            index = tbl_QLNV.getSelectedRow();
            edit();
        }
    }//GEN-LAST:event_tbl_QLNVMouseClicked

    private void btn_moiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moiActionPerformed
        clearForm();
    }//GEN-LAST:event_btn_moiActionPerformed

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        if (check_input()) {
            if (kiemTraMaTrung()) {
                insert();
            }
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void txt_maNVKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_maNVKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_maNVKeyPressed

    private void txt_macKhauKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_macKhauKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_macKhauKeyPressed

    private void txt_xacNhanMacKhauKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_xacNhanMacKhauKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_xacNhanMacKhauKeyPressed

    private void txt_hoTenKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_hoTenKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_hoTenKeyPressed

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        if (check_input()) {
            update();
        }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        delete();
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void btn_dauTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dauTienActionPerformed
        first();
    }//GEN-LAST:event_btn_dauTienActionPerformed

    private void btn_SauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SauActionPerformed
        prev();
    }//GEN-LAST:event_btn_SauActionPerformed

    private void btn_TruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TruocActionPerformed
        next();
    }//GEN-LAST:event_btn_TruocActionPerformed

    private void btn_cuoiCungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cuoiCungActionPerformed
        last();
    }//GEN-LAST:event_btn_cuoiCungActionPerformed

    private void lbl_showPassword_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_showPassword_2MouseClicked
        if (evt.getClickCount() == 1) {
            ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/show_Pass.png"));
            Image img = imgIcon.getImage();
            img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
            lbl_showPassword_2.setIcon(imgIcon);
            txt_xacNhanMacKhau.setEchoChar((char) 0); //cho echochar = 0 để hiển thị 
        } else {
            txt_xacNhanMacKhau.setEchoChar('*'); // chọn ký tự ẩn dự liệu
            ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/hide_Pass.png"));
            Image img = imgIcon.getImage();
            img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
            lbl_showPassword_2.setIcon(imgIcon);
        }
    }//GEN-LAST:event_lbl_showPassword_2MouseClicked

    private void lbl_showPasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_showPasswordMouseEntered
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/show_Pass.png"));
        Image img = imgIcon.getImage();
        img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
        lbl_showPassword.setIcon(imgIcon);
        txt_macKhau.setEchoChar((char) 0); //cho echochar = 0 để hiển thị 
    }//GEN-LAST:event_lbl_showPasswordMouseEntered

    private void lbl_showPasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_showPasswordMouseExited
        txt_macKhau.setEchoChar('*'); // chọn ký tự ẩn dự liệu
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/hide_Pass.png"));
        Image img = imgIcon.getImage();
        img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
        lbl_showPassword.setIcon(imgIcon);
    }//GEN-LAST:event_lbl_showPasswordMouseExited

    private void lbl_showPassword_2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_showPassword_2MouseEntered
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/show_Pass.png"));
        Image img = imgIcon.getImage();
        img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
        lbl_showPassword_2.setIcon(imgIcon);
        txt_xacNhanMacKhau.setEchoChar((char) 0); //cho echochar = 0 để hiển thị 
    }//GEN-LAST:event_lbl_showPassword_2MouseEntered

    private void lbl_showPassword_2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_showPassword_2MouseExited
        txt_xacNhanMacKhau.setEchoChar('*'); // chọn ký tự ẩn dự liệu
        ImageIcon imgIcon = new ImageIcon(getClass().getResource("/com/edu/image/hide_Pass.png"));
        Image img = imgIcon.getImage();
        img.getScaledInstance(lbl_showPassword.getWidth(), lbl_showPassword.getY(), 0);
        lbl_showPassword_2.setIcon(imgIcon);
    }//GEN-LAST:event_lbl_showPassword_2MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLNV_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLNV_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLNV_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLNV_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLNV_Edusys dialog = new QLNV_Edusys(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Sau;
    private javax.swing.JButton btn_Truoc;
    private javax.swing.JButton btn_cuoiCung;
    private javax.swing.JButton btn_dauTien;
    private javax.swing.JButton btn_moi;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_showPassword;
    private javax.swing.JLabel lbl_showPassword_2;
    private javax.swing.JPanel pnl_edit;
    private javax.swing.JPanel pnl_list;
    private javax.swing.JRadioButton rdo_nhanVien;
    private javax.swing.JRadioButton rdo_truongPhong;
    private javax.swing.JTabbedPane tabs_big;
    private javax.swing.JTable tbl_QLNV;
    private javax.swing.JTextField txt_hoTen;
    private javax.swing.JTextField txt_maNV;
    private javax.swing.JPasswordField txt_macKhau;
    private javax.swing.JPasswordField txt_xacNhanMacKhau;
    // End of variables declaration//GEN-END:variables
}
