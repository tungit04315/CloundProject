/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Class_Edusys;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

/**
 *
 * @author tungt
 */
public class Icon_ShowPass {
    public static Image getImg() {
        URL url = Icon_ShowPass.class.getResource("/com/edu/image/show_Pass.png");
        return new ImageIcon(url).getImage();
    }
}
