/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.NguoiHoc_Dao;
import com.edu.Entity.NguoiHoc;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import com.edu.utils.XDate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLNH_Edusys1 extends javax.swing.JDialog {

    NguoiHoc_Dao dao = new NguoiHoc_Dao();
    int index = -1;

    /**
     * Creates new form QLNV_Edusys
     */
    public QLNH_Edusys1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
    }

    void init() {
        fill_TBL();
        index = -1;
        capNhat_CacNut();
    }

    void fill_TBL() {
        DefaultTableModel model = (DefaultTableModel) tbl_QLNH.getModel();
        model.setRowCount(0);
        try {
//            List<NguoiHoc> list = dao.selectALL();
            String key = txt_timKiem.getText();
            List<NguoiHoc> list = dao.selectByKeyWord(key);
            for (NguoiHoc nh : list) {
                Object[] row = {nh.getMaNH(), nh.getHoTen(), nh.isGioiTinh() ? "Nam" : "Nữ",
                    nh.getNgaySinh(), nh.getDienThoai(), nh.getEmail(), nh.getMaNV(), nh.getNgayDK()};
                model.addRow(row);
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    void edit_TBL() {
        String maNh = (String) tbl_QLNH.getValueAt(index, 0);
        NguoiHoc nh = dao.select_ById(maNh);
        set_Form(nh);
        tabs_big.setSelectedIndex(1);
        capNhat_CacNut();
    }

    void set_Form(NguoiHoc nh) {
        txt_maNH.setText(nh.getMaNH());
        txt_hoTen.setText(nh.getHoTen());
        txt_Email.setText(nh.getEmail());
        txt_NgaySinh.setText(String.valueOf(nh.getNgaySinh()));
        txt_sdt.setText(nh.getDienThoai());
        txt_ghiChu.setText(nh.getGhiChu());
        if (nh.isGioiTinh()) {
            rdo_Nam.setSelected(true);
        } else {
            rdo_Nu.setSelected(true);
        }
    }

    NguoiHoc get_Form() {
        NguoiHoc nh = new NguoiHoc();
        Date ngSinh = null;
        long millis = System.currentTimeMillis();
        java.sql.Date date = new java.sql.Date(millis);
//        System.out.println(date);
        try {
            ngSinh = new SimpleDateFormat("yyyy-MM-dd").parse(txt_NgaySinh.getText());
        } catch (ParseException ex) {
            Logger.getLogger(QLNH_Edusys1.class.getName()).log(Level.SEVERE, null, ex);
        }
        nh.setMaNH(txt_maNH.getText());
        nh.setHoTen(txt_hoTen.getText());
        nh.setDienThoai(txt_sdt.getText());
        nh.setNgaySinh(ngSinh);
        nh.setEmail(txt_Email.getText());
        nh.setGhiChu(txt_ghiChu.getText());
        nh.setGioiTinh(rdo_Nam.isSelected());
        nh.setGioiTinh(!rdo_Nu.isSelected());
        nh.setMaNV(Auth.user.getMaNV());
        nh.setNgayDK(date);
        return nh;
    }

    void lamMoi_Form() {
        NguoiHoc nh = new NguoiHoc();
        set_Form(nh);
        index = -1;
        capNhat_CacNut();
    }

    void capNhat_CacNut() {
        boolean edit = (index >= 0);
        boolean first = (index == 0);
        boolean last = (index == tbl_QLNH.getRowCount() - 1);
        // trạng thái form 
        txt_maNH.setEditable(!edit);
        btn_them.setEnabled(!edit);
        btn_sua.setEnabled(edit);
        btn_xoa.setEnabled(edit);

        // trạng thái điều hướng
        btn_dauTien.setEnabled(edit && !first);
        btn_Sau.setEnabled(edit && !first);
        btn_Truoc.setEnabled(edit && !last);
        btn_cuoiCung.setEnabled(edit && !last);
    }

    void them_NH() {
        NguoiHoc nh = get_Form();
        try {
            dao.insert(nh);
            fill_TBL();
            lamMoi_Form();
            MsgBox.alert(this, "Thêm người học thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Thêm người học thất bại");
            System.out.println(e);
        }
    }

    void sua_NH() {
        NguoiHoc nh = get_Form();
        try {
            dao.update(nh);
            fill_TBL();
            MsgBox.alert(this, "Cập Nhật người học thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Cập Nhật người học thất bại");
//            System.out.println(e);
        }
    }

    void xoa_NH() {
        String maNH = txt_maNH.getText();
        try {
            if (MsgBox.confirm(this, "Bạn có chắc chắn muốn xoá chuyên đề này không ?")) {
                dao.delete(maNH);
                fill_TBL();
                lamMoi_Form();
                MsgBox.alert(this, "Xoá Người Học thành công");
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Xoá Người Học thất bại");
        }
    }

    private void timKiem() {
        fill_TBL();
        index = -1;
        lamMoi_Form();
        capNhat_CacNut();
    }

    public void first() {
        index = 0;
        edit_TBL();
    }

    public void prev() {
        if (index > 0) {
            index--;
            edit_TBL();
        }
    }

    public void next() {
        if (index < tbl_QLNH.getRowCount() - 1) {
            index++;
            edit_TBL();
        }
    }

    public void last() {
        index = tbl_QLNH.getRowCount() - 1;
        edit_TBL();
    }

    public boolean check_input() {
        // phương thức kiểm tra email "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        // PTKT Email                 "^[A-Za-z0-9]+[A-Za-z0-9]*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)$";
        // viết gọn cái trên "^[\w]+[\w]*@[\w]+(\\.[\w]+)$";
        // kiểm tra sdt "0[98][0-9]{9};
        if (txt_maNH.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống mã người học");
            txt_maNH.requestFocus();
            return false;
        }
        if (txt_hoTen.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống họ tên người học");
            txt_hoTen.requestFocus();
            return false;
        }
        if (txt_NgaySinh.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống ngày sinh người học");
            txt_NgaySinh.requestFocus();
            return false;
        }
        Pattern pat_ngSinh = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2})");
        Matcher mat_ngSinh = pat_ngSinh.matcher(txt_NgaySinh.getText());

        if (!mat_ngSinh.matches()) {
            MsgBox.alert(this, "Ngày sinh nhập đúng định dạng ????- ?? - ?? (Năm - Tháng - Ngày)");
            txt_NgaySinh.requestFocus();
            return false;
        }
        if (txt_sdt.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống số điện thoại người học");
            txt_sdt.requestFocus();
            return false;
        }
        if (txt_Email.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống email người học");
            txt_Email.requestFocus();
            return false;
        }
        if (txt_ghiChu.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "không để trống ghi chú");
            txt_ghiChu.requestFocus();
            return false;
        }

        if(txt_maNH.getText().length() > 7 || txt_maNH.getText().length() < 7){
            MsgBox.alert(this, "Mã người học không được quá 7 ký tự hoặc ít hơn 7 ký tự");
            txt_maNH.requestFocus();
            return false;
        }
        
        try {
            Date today = XDate.toDate(txt_NgaySinh.getText(), "yyyy-MM-dd");

        } catch (Exception e) {
            MsgBox.alert(this, "Ngày Sinh không được nhập chữ và sai định dạng (yyyy-MM-dd)");
            txt_NgaySinh.requestFocus();
            return false;
        }


        try {
//            int sdt = Integer.parseInt(txt_sdt.getText());
//            if (sdt < 0) {
//                MsgBox.alert(this, "Số điện thoại không được phép âm !");
//                txt_sdt.requestFocus();
//                return false;
//            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Số điện thoại không được nhập chữ và số không được phép âm");
            txt_sdt.requestFocus();
            return false;
        }

        Pattern pattern = Pattern.compile("0[1-9][0-9]{8}");
        Matcher matcher = pattern.matcher(txt_sdt.getText());
        if (!matcher.matches()) {
            MsgBox.alert(this, "Số điện thoại sai định dạng");
            txt_sdt.requestFocus();
            return false;
        }
        Pattern pat_email = Pattern.compile("[A-Za-z0-9]+[A-Za-z0-9]*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)$");
        Matcher ma_email = pat_email.matcher(txt_Email.getText());
        if (!ma_email.matches()) {
            MsgBox.alert(this, "Email phải nhập đúng định dạng (abc123@gmail.com)");
            txt_Email.requestFocus();
            return false;
        }
        return true;
    }

    boolean maTrung() {
        boolean kq;

        List<NguoiHoc> list = dao.selectALL();
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaNH().equalsIgnoreCase(txt_maNH.getText());
            if (kq == true) {
                MsgBox.alert(this, "Mã người học không được phép trùng");
                return false;
            }
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tabs_big = new javax.swing.JTabbedPane();
        pnl_list = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLNH = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txt_timKiem = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        pnl_edit = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_maNH = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_sdt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_sua = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        btn_them = new javax.swing.JButton();
        btn_moi = new javax.swing.JButton();
        btn_dauTien = new javax.swing.JButton();
        btn_Sau = new javax.swing.JButton();
        btn_Truoc = new javax.swing.JButton();
        btn_cuoiCung = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txt_NgaySinh = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_ghiChu = new javax.swing.JTextArea();
        txt_hoTen = new javax.swing.JTextField();
        rdo_Nam = new javax.swing.JRadioButton();
        rdo_Nu = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                                  Quản Lý Người Học");
        setPreferredSize(new java.awt.Dimension(774, 604));

        tbl_QLNH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Người Học", "Họ Tên", "Giới Tính", "Ngày Sinh", "Số Điện Thoại", "Email", "Mã Nhân Viên", "Ngày Đăng Ký"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_QLNH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLNHMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLNH);
        if (tbl_QLNH.getColumnModel().getColumnCount() > 0) {
            tbl_QLNH.getColumnModel().getColumn(0).setMaxWidth(70);
            tbl_QLNH.getColumnModel().getColumn(1).setMinWidth(150);
            tbl_QLNH.getColumnModel().getColumn(2).setMaxWidth(60);
        }

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Tìm Kiếm ");

        jButton1.setText("Tìm");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txt_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnl_listLayout = new javax.swing.GroupLayout(pnl_list);
        pnl_list.setLayout(pnl_listLayout);
        pnl_listLayout.setHorizontalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 761, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_listLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(88, 88, 88))
        );
        pnl_listLayout.setVerticalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_listLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE))
        );

        tabs_big.addTab("Danh Sách", pnl_list);

        pnl_edit.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Mã Người Học");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Họ Tên");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Giới Tính ");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Số Điện Thoại");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Ghi Chú");

        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_xoa.setText("Xoá");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_moi.setText("Mới");
        btn_moi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moiActionPerformed(evt);
            }
        });

        btn_dauTien.setText("|<");
        btn_dauTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dauTienActionPerformed(evt);
            }
        });

        btn_Sau.setText("<<");
        btn_Sau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SauActionPerformed(evt);
            }
        });

        btn_Truoc.setText(">>");
        btn_Truoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TruocActionPerformed(evt);
            }
        });

        btn_cuoiCung.setText(">|");
        btn_cuoiCung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cuoiCungActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Ngày Sinh");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Email");

        txt_ghiChu.setColumns(20);
        txt_ghiChu.setRows(5);
        jScrollPane2.setViewportView(txt_ghiChu);

        buttonGroup1.add(rdo_Nam);
        rdo_Nam.setSelected(true);
        rdo_Nam.setText("Nam");

        buttonGroup1.add(rdo_Nu);
        rdo_Nu.setText("Nữ");

        javax.swing.GroupLayout pnl_editLayout = new javax.swing.GroupLayout(pnl_edit);
        pnl_edit.setLayout(pnl_editLayout);
        pnl_editLayout.setHorizontalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txt_hoTen)
                    .addComponent(jScrollPane2)
                    .addComponent(txt_maNH)
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addComponent(txt_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(txt_Email))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addComponent(rdo_Nam, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(rdo_Nu, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(60, 60, 60)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_NgaySinh)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_moi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
                        .addComponent(btn_dauTien, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_Sau, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_Truoc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_cuoiCung, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pnl_editLayout.setVerticalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_maNH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(txt_hoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7))
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(txt_NgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdo_Nam)
                            .addComponent(rdo_Nu))))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addGap(13, 13, 13)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_dauTien)
                    .addComponent(btn_Sau)
                    .addComponent(btn_Truoc)
                    .addComponent(btn_cuoiCung)
                    .addComponent(btn_moi)
                    .addComponent(btn_them)
                    .addComponent(btn_sua)
                    .addComponent(btn_xoa))
                .addContainerGap())
        );

        tabs_big.addTab("Câp Nhật", pnl_edit);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quản Lý Người Học");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs_big)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs_big)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_QLNHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLNHMouseClicked
        if (evt.getClickCount() == 2) {
            index = tbl_QLNH.getSelectedRow();
            edit_TBL();
        }
    }//GEN-LAST:event_tbl_QLNHMouseClicked

    private void btn_moiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moiActionPerformed
        lamMoi_Form();
    }//GEN-LAST:event_btn_moiActionPerformed

    private void btn_dauTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dauTienActionPerformed
        first();
    }//GEN-LAST:event_btn_dauTienActionPerformed

    private void btn_SauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SauActionPerformed
        prev();
    }//GEN-LAST:event_btn_SauActionPerformed

    private void btn_TruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TruocActionPerformed
        next();
    }//GEN-LAST:event_btn_TruocActionPerformed

    private void btn_cuoiCungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cuoiCungActionPerformed
        last();
    }//GEN-LAST:event_btn_cuoiCungActionPerformed

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        if (check_input()) {
            if (maTrung()) {
                them_NH();
            }
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        xoa_NH();
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        if (check_input()) {
            sua_NH();
        }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        timKiem();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLNH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLNH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLNH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLNH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLNH_Edusys1 dialog = new QLNH_Edusys1(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Sau;
    private javax.swing.JButton btn_Truoc;
    private javax.swing.JButton btn_cuoiCung;
    private javax.swing.JButton btn_dauTien;
    private javax.swing.JButton btn_moi;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pnl_edit;
    private javax.swing.JPanel pnl_list;
    private javax.swing.JRadioButton rdo_Nam;
    private javax.swing.JRadioButton rdo_Nu;
    private javax.swing.JTabbedPane tabs_big;
    private javax.swing.JTable tbl_QLNH;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_NgaySinh;
    private javax.swing.JTextArea txt_ghiChu;
    private javax.swing.JTextField txt_hoTen;
    private javax.swing.JTextField txt_maNH;
    private javax.swing.JTextField txt_sdt;
    private javax.swing.JTextField txt_timKiem;
    // End of variables declaration//GEN-END:variables
}
