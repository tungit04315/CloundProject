/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.ChuyenDe_Dao;
import com.edu.Edusys_Dao.KhoaHoc_Dao;
import com.edu.Entity.ChuyenDe;
import com.edu.Entity.KhoaHoc;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import com.edu.utils.XDate;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLKH_Edusys1 extends javax.swing.JDialog {

    Date ngTao = new Date();
    KhoaHoc_Dao dao = new KhoaHoc_Dao();
//    ChuyenDe_Dao cd_Dao = new ChuyenDe_Dao();
    int index = -1;
//    String model = null;

    /**
     * Creates new form QLNV_Edusys
     */
    public QLKH_Edusys1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
//
//        List<ChuyenDe> list_cd = cd_Dao.selectALL();
//        model = String.valueOf(list_cd);
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
    }

    void init() {
        fill_ComboBoxCD();
        fill_TBL();
        index = -1;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            txt_ngayTao.setText(dateFormat.format(ngTao));

            txt_nguoiTao.setText(Auth.user.getMaNV());
        } catch (Exception e) {
        }
        capNhat_CacNut();
    }

    void them_KH() {
        KhoaHoc kh = get_Form_add();
        try {

            dao.insert(kh);
            fill_TBL();
            lammoi_Form();
            MsgBox.alert(this, "Thêm khoá học thành công");
        } catch (Exception e) {
            e.printStackTrace();
            MsgBox.alert(this, "Thêm khoá học thất bại");
        }
    }

    void sua_KH() {
        KhoaHoc kh = get_Form();
        try {
            dao.update(kh);
            fill_TBL();
            MsgBox.alert(this, "Cập nhật khoá học thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Cập nhật khoá học thất bại");
        }
    }

    void xoa_KH() {
        int maKH = (Integer) tbl_QLKH.getValueAt(index, 0);
        KhoaHoc kh = dao.select_ById(String.valueOf(maKH));
        try {
            dao.delete(String.valueOf(maKH));
            fill_TBL();
            lammoi_Form();
            MsgBox.alert(this, "Xoá khoá học thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Xoá khoá học thất bại");
        }
    }

    boolean Check_input() {

        if (txt_ngayKG.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống ngày khai giảng");
            txt_ngayKG.requestFocus();
            return false;
        }
        if (txt_hocPhi.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống học phí");
            txt_hocPhi.requestFocus();
            return false;
        }
        if (txt_thoiLuong.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống Thời Lượng");
            txt_thoiLuong.requestFocus();
            return false;
        }
//        if (txt_ngayTao.getText().equalsIgnoreCase("")) {
//            MsgBox.alert(this, "Không để trống ngày Tạo");
//            txt_ngayTao.requestFocus();
//            return false;
//        }
//        if (txt_nguoiTao.getText().equalsIgnoreCase("")) {
//            MsgBox.alert(this, "Không để trống người tạo");
//            txt_nguoiTao.requestFocus();
//            return false;
//        }
        if (txt_ghiChu.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống ghi chú");
            txt_ghiChu.requestFocus();
            return false;
        }

        try {
            Date d = XDate.toDate(txt_ngayKG.getText(), "yyyy-MM-dd");
        } catch (Exception e) {
            MsgBox.alert(this, "Ngày khai giảng không được nhập chữ và sai định dạnh");
            txt_ngayKG.requestFocus();
            return false;
        }

        Pattern pat_ngSinh = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2})");
        Matcher mat_ngSinh = pat_ngSinh.matcher(txt_ngayKG.getText());

        if (!mat_ngSinh.matches()) {
            MsgBox.alert(this, "Ngày khai giảng nhập không đúng định dạng ???? - ?? - ?? (Năm - Tháng  - Ngày)");
            txt_ngayKG.requestFocus();
            return false;
        }

        try {
            double hoc_phi = Double.parseDouble(txt_hocPhi.getText());
            if (hoc_phi < 0) {
                MsgBox.alert(this, "Học phí không được bé hơn 0");
                txt_hocPhi.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Học phí không được nhập chữ");
            txt_hocPhi.requestFocus();
            return false;
        }

        try {
            int thLuong = Integer.parseInt(txt_thoiLuong.getText());
            if (thLuong < 0) {
                MsgBox.alert(this, "Thời lượng  không được bé hơn 0");
                txt_thoiLuong.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Thời lượng không được nhập chữ");
            txt_thoiLuong.requestFocus();
            return false;
        }

//        try {
//            Date ngTao = XDate.toDate(txt_ngayTao.getText(), "yyyy-MM-dd");
//        } catch (Exception e) {
//            MsgBox.alert(this, "Ngày tạo không được nhập chữ và sai định dạnh");
//            txt_ngayTao.requestFocus();
//            return false;
//        }
        return true;
    }

    KhoaHoc get_Form() {
        Date ngKG = null;
        try {
            ngKG = new SimpleDateFormat("yyyy-MM-dd").parse(txt_ngayKG.getText());
            ngTao = new SimpleDateFormat("yyyy-MM-dd").parse(txt_ngayTao.getText());
        } catch (ParseException ex) {
            Logger.getLogger(QLNH_Edusys1.class.getName()).log(Level.SEVERE, null, ex);
        }
        KhoaHoc kh = new KhoaHoc();
        ChuyenDe cd = (ChuyenDe) cbo_tenCD.getSelectedItem();
        kh.setThoiLuong(Integer.parseInt(txt_thoiLuong.getText()));
        kh.setHocPhi(Double.parseDouble(txt_hocPhi.getText()));
        kh.setNgayKG(ngKG);
        kh.setNgayTao(ngTao);
        kh.setMaNV(Auth.user.getMaNV());
        kh.setMaCD(cd.getMaCD());
        kh.setGhiChu(txt_ghiChu.getText());
        int maKH = (Integer) tbl_QLKH.getValueAt(index, 0);
        kh.setMaKH(maKH);
        return kh;
    }

    KhoaHoc get_Form_add() {
        Date ngKG = null;
        Date ngTao = null;
        try {
            ngKG = new SimpleDateFormat("yyyy-MM-dd").parse(txt_ngayKG.getText());
            ngTao = new SimpleDateFormat("yyyy-MM-dd").parse(txt_ngayTao.getText());
        } catch (ParseException ex) {
            Logger.getLogger(QLNH_Edusys1.class.getName()).log(Level.SEVERE, null, ex);
        }
        KhoaHoc kh = new KhoaHoc();
        ChuyenDe cd = (ChuyenDe) cbo_tenCD.getSelectedItem();
        kh.setThoiLuong(Integer.parseInt(txt_thoiLuong.getText()));
        kh.setHocPhi(Double.parseDouble(txt_hocPhi.getText()));
        kh.setNgayKG(ngKG);
        kh.setNgayTao(ngTao);
        kh.setMaNV(Auth.user.getMaNV());
        kh.setMaCD(cd.getMaCD());
        kh.setGhiChu(txt_ghiChu.getText());

        return kh;
    }

    void set_Form(KhoaHoc kh) {
        txt_ngayKG.setText(String.valueOf(kh.getNgayKG()));
        txt_hocPhi.setText(String.valueOf(kh.getHocPhi()));
        txt_thoiLuong.setText(String.valueOf(kh.getThoiLuong()));
        txt_ngayTao.setText(String.valueOf(kh.getNgayKG()));
        txt_nguoiTao.setText(kh.getMaNV());
        txt_ghiChu.setText(kh.getGhiChu());
    }

    void lammoi_Form() {
        KhoaHoc kh = new KhoaHoc();
//        set_Form(kh);
        txt_ngayKG.setText("");
        txt_hocPhi.setText("");
        txt_ghiChu.setText("");
        txt_thoiLuong.setText(" ");
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            txt_ngayTao.setText(dateFormat.format(ngTao));

            txt_nguoiTao.setText(Auth.user.getMaNV());
        } catch (Exception e) {
        }

        index = -1;
        capNhat_CacNut();
    }

    void edit_TBL() {
        int maKH = (Integer) tbl_QLKH.getValueAt(index, 0);
        KhoaHoc kh = dao.select_ById(String.valueOf(maKH));
        set_Form(kh);
        tabs_big.setSelectedIndex(1);
        capNhat_CacNut();
    }

    void capNhat_CacNut() {
        boolean edit = (index >= 0);
        boolean first = (index == 0);
        boolean last = (index == tbl_QLKH.getRowCount() - 1);
        // trạng thái form 
        cbo_tenCD.setEditable(!edit);
        btn_them.setEnabled(!edit);
        btn_sua.setEnabled(edit);
        btn_xoa.setEnabled(edit);
        txt_nguoiTao.setEditable(false);
        txt_ngayTao.setEditable(false);

        // trạng thái điều hướng
        btn_dauTien.setEnabled(edit && !first);
        btn_Sau.setEnabled(edit && !first);
        btn_Truoc.setEnabled(edit && !last);
        btn_cuoiCung.setEnabled(edit && !last);
    }
    ChuyenDe_Dao cdDao = new ChuyenDe_Dao();

    void fill_ComboBoxCD() {
        DefaultComboBoxModel Model = (DefaultComboBoxModel) cbo_tenCD.getModel();
        Model.removeAllElements();
        List<ChuyenDe> list = cdDao.selectALL();
        for (ChuyenDe cd : list) {
            Model.addElement(cd);
        }
    }

    void fill_TBL() {
        DefaultTableModel model = (DefaultTableModel) tbl_QLKH.getModel();
        model.setRowCount(0);
        try {
            ChuyenDe chuyende = (ChuyenDe) cbo_tenCD.getSelectedItem();
            if (cbo_tenCD.getSelectedItem() != null) {

                List<KhoaHoc> list = dao.selectByChuyenDe(chuyende.getMaCD());
                for (KhoaHoc kh : list) {
                    Object[] row = {kh.getMaKH(), kh.getThoiLuong(),
                        kh.getHocPhi(), kh.getNgayKG(), kh.getMaNV(), kh.getNgayTao(), kh.getMaCD()};
                    model.addRow(row);
                }
            } else {
                System.out.println("a");
            }
        } catch (Exception e) {
            e.printStackTrace();
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    void chon_ComboBox() {
        try {
            ChuyenDe cd = (ChuyenDe) cbo_tenCD.getSelectedItem();
            txt_thoiLuong.setText(String.valueOf(cd.getThoiLuong()));
            txt_hocPhi.setText(String.valueOf(cd.getHocPhi()));
            txt_ghiChu.setText(cd.getTenCD());
            fill_TBL();
            index = -1;
            capNhat_CacNut();
            tabs_big.setSelectedIndex(0);
        } catch (Exception e) {

        }

    }

    public void first() {
        index = 0;
        edit_TBL();
    }

    public void prev() {
        if (index > 0) {
            index--;
            edit_TBL();
        }
    }

    public void next() {
        if (index < tbl_QLKH.getRowCount() - 1) {
            index++;
            edit_TBL();
        }
    }

    public void last() {
        index = tbl_QLKH.getRowCount() - 1;
        edit_TBL();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tabs_big = new javax.swing.JTabbedPane();
        pnl_list = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLKH = new javax.swing.JTable();
        pnl_edit = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_ngayKG = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_sua = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        btn_them = new javax.swing.JButton();
        btn_moi = new javax.swing.JButton();
        btn_dauTien = new javax.swing.JButton();
        btn_Sau = new javax.swing.JButton();
        btn_Truoc = new javax.swing.JButton();
        btn_cuoiCung = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cbo_tenCD = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        txt_thoiLuong = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txt_nguoiTao = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_ghiChu = new javax.swing.JTextArea();
        txt_hocPhi = new javax.swing.JTextField();
        txt_ngayTao = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                                  Quản Lý Khoá Học");

        tbl_QLKH.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Khoá Học", "Thời Lượng", "Học Phí", "Khai Giảng", "Tạo Bởi", "Ngày Tạo", "MACD"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_QLKH.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLKHMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLKH);

        javax.swing.GroupLayout pnl_listLayout = new javax.swing.GroupLayout(pnl_list);
        pnl_list.setLayout(pnl_listLayout);
        pnl_listLayout.setHorizontalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 704, Short.MAX_VALUE)
        );
        pnl_listLayout.setVerticalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_listLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tabs_big.addTab("Danh Sách", pnl_list);

        pnl_edit.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Chuyên Đề");

        txt_ngayKG.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_ngayKGKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Học Phí");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Ngày Tạo");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Ghi Chú ");

        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_xoa.setText("Xoá");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_moi.setText("Mới");
        btn_moi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moiActionPerformed(evt);
            }
        });

        btn_dauTien.setText("|<");
        btn_dauTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dauTienActionPerformed(evt);
            }
        });

        btn_Sau.setText("<<");
        btn_Sau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SauActionPerformed(evt);
            }
        });

        btn_Truoc.setText(">>");
        btn_Truoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TruocActionPerformed(evt);
            }
        });

        btn_cuoiCung.setText(">|");
        btn_cuoiCung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cuoiCungActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Ngày Khai Giảng");

        cbo_tenCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_tenCDActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Thời Lượng (Giờ)");

        txt_thoiLuong.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_thoiLuongKeyPressed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Người Tạo");

        txt_nguoiTao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_nguoiTaoKeyPressed(evt);
            }
        });

        txt_ghiChu.setColumns(20);
        txt_ghiChu.setRows(5);
        txt_ghiChu.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_ghiChuKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(txt_ghiChu);

        txt_hocPhi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_hocPhiKeyPressed(evt);
            }
        });

        txt_ngayTao.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_ngayTaoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout pnl_editLayout = new javax.swing.GroupLayout(pnl_edit);
        pnl_edit.setLayout(pnl_editLayout);
        pnl_editLayout.setHorizontalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_editLayout.createSequentialGroup()
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbo_tenCD, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txt_hocPhi)
                            .addComponent(txt_ngayTao)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 275, Short.MAX_VALUE)))
                        .addGap(26, 26, 26)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_ngayKG)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_thoiLuong)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_nguoiTao, javax.swing.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_moi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_dauTien, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_Sau, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_Truoc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_cuoiCung, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pnl_editLayout.setVerticalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_ngayKG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbo_tenCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_thoiLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_hocPhi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nguoiTao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_ngayTao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_dauTien)
                        .addComponent(btn_Sau)
                        .addComponent(btn_Truoc)
                        .addComponent(btn_cuoiCung))
                    .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_them)
                        .addComponent(btn_moi)
                        .addComponent(btn_sua)
                        .addComponent(btn_xoa)))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        tabs_big.addTab("Câp Nhật", pnl_edit);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quản Lý Khoá Học");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(tabs_big)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs_big))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        if (Check_input()) {
            them_KH();
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        if (Check_input()) {
            sua_KH();
        }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
//        if (Check_input()) {
        xoa_KH();
//        }
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void txt_ngayKGKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_ngayKGKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_ngayKGKeyPressed

    private void txt_hocPhiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_hocPhiKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_hocPhiKeyPressed

    private void txt_thoiLuongKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_thoiLuongKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_thoiLuongKeyPressed

    private void txt_ngayTaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_ngayTaoKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_ngayTaoKeyPressed

    private void txt_nguoiTaoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_nguoiTaoKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_nguoiTaoKeyPressed

    private void txt_ghiChuKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_ghiChuKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Check_input();
        }
    }//GEN-LAST:event_txt_ghiChuKeyPressed

    private void cbo_tenCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_tenCDActionPerformed
        chon_ComboBox();
    }//GEN-LAST:event_cbo_tenCDActionPerformed

    private void tbl_QLKHMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLKHMouseClicked
        if (evt.getClickCount() == 2) {
            index = tbl_QLKH.getSelectedRow();
            edit_TBL();
        }

    }//GEN-LAST:event_tbl_QLKHMouseClicked

    private void btn_moiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moiActionPerformed
        lammoi_Form();
    }//GEN-LAST:event_btn_moiActionPerformed

    private void btn_dauTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dauTienActionPerformed
        first();
    }//GEN-LAST:event_btn_dauTienActionPerformed

    private void btn_SauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SauActionPerformed
        prev();
    }//GEN-LAST:event_btn_SauActionPerformed

    private void btn_TruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TruocActionPerformed
        next();
    }//GEN-LAST:event_btn_TruocActionPerformed

    private void btn_cuoiCungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cuoiCungActionPerformed
        last();
    }//GEN-LAST:event_btn_cuoiCungActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLKH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLKH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLKH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLKH_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLKH_Edusys1 dialog = new QLKH_Edusys1(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Sau;
    private javax.swing.JButton btn_Truoc;
    private javax.swing.JButton btn_cuoiCung;
    private javax.swing.JButton btn_dauTien;
    private javax.swing.JButton btn_moi;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbo_tenCD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pnl_edit;
    private javax.swing.JPanel pnl_list;
    private javax.swing.JTabbedPane tabs_big;
    private javax.swing.JTable tbl_QLKH;
    private javax.swing.JTextArea txt_ghiChu;
    private javax.swing.JTextField txt_hocPhi;
    private javax.swing.JTextField txt_ngayKG;
    private javax.swing.JTextField txt_ngayTao;
    private javax.swing.JTextField txt_nguoiTao;
    private javax.swing.JTextField txt_thoiLuong;
    // End of variables declaration//GEN-END:variables
}
