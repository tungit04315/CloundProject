/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.NhanVien_Dao;
import com.edu.Entity.NhanVien;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class Login_Edusys extends javax.swing.JDialog {

    boolean dx;

    public Login_Edusys(java.awt.Frame parent, boolean modal, boolean m) {
        super(parent, modal);
        dx = m;
        initComponents();
        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
        Dong_Cua_So();
    }

    public void Dong_Cua_So() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                System.exit(0);
            }

        });
    }

    public void init() {
        if (dx == true) {
            new Hi_Edusys(null, true).setVisible(true);
        }
    }
    NhanVien_Dao dao = new NhanVien_Dao();

    public void dangNhap() {
        String maNV = txt_Username.getText();
        String matKhau = txt_Password.getText();

        NhanVien nv = dao.select_ById(maNV);
        if (nv == null) {
            MsgBox.alert(this, "Sai tên đăng nhập !!!");
        } else if (!matKhau.equalsIgnoreCase(nv.getMatKhau())) {
            MsgBox.alert(this, "Sai mật khẩu đăng nhập !!!");
        } else {
            Auth.user = nv;
            this.dispose();
            Main_Form a = new Main_Form();
            a.setVisible(true);
        }
    }

    public boolean check_Input() {

        if (txt_Username.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Không để trống Tên đăng Nhập");
            txt_Username.requestFocus();
            txt_Username.setBackground(Color.red);
            return false;
        }

        if (txt_Password.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Không để trống mật khẩu");
            txt_Username.setBackground(Color.white);
            txt_Password.requestFocus();
            txt_Password.setBackground(Color.red);
            return false;
        } else {
            txt_Password.setBackground(Color.white);
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lbl_Icon_Login = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_Username = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_Password = new javax.swing.JPasswordField();
        lbl_quenMK = new javax.swing.JLabel();
        btn_DangNhap = new javax.swing.JButton();
        btn_KetThuc = new javax.swing.JButton();
        lbl_background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                           Hệ Thống Quản Lý Đào Tạo");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Đăng Nhập");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 20, 150, -1));

        lbl_Icon_Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/login (1).png"))); // NOI18N
        lbl_Icon_Login.setText("Icon_Login");
        getContentPane().add(lbl_Icon_Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 190, 220));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Tên Đăng Nhập  ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        txt_Username.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_UsernameKeyPressed(evt);
            }
        });
        getContentPane().add(txt_Username, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 350, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Mật Khẩu   ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 160, -1, -1));

        txt_Password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_PasswordKeyPressed(evt);
            }
        });
        getContentPane().add(txt_Password, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 350, -1));

        lbl_quenMK.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lbl_quenMK.setText("Quên Mật Khẩu ? ");
        lbl_quenMK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_quenMKMouseClicked(evt);
            }
        });
        getContentPane().add(lbl_quenMK, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 230, -1, -1));

        btn_DangNhap.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/locksmith.png"))); // NOI18N
        btn_DangNhap.setText("Đăng Nhập");
        btn_DangNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DangNhapActionPerformed(evt);
            }
        });
        getContentPane().add(btn_DangNhap, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 280, -1, -1));

        btn_KetThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/turn-off.png"))); // NOI18N
        btn_KetThuc.setText("Kết Thúc");
        btn_KetThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_KetThucActionPerformed(evt);
            }
        });
        getContentPane().add(btn_KetThuc, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 280, -1, -1));

        lbl_background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/Background-book.jpg"))); // NOI18N
        getContentPane().add(lbl_background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 330));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_KetThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_KetThucActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn thoát không", "Thoát", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else {

        }
    }//GEN-LAST:event_btn_KetThucActionPerformed

    private void btn_DangNhapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DangNhapActionPerformed

        if (check_Input()) {
            dangNhap();
        }
    }//GEN-LAST:event_btn_DangNhapActionPerformed

    private void lbl_quenMKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_quenMKMouseClicked
        this.dispose();
        QuenMacKhau_Edusys a = new QuenMacKhau_Edusys(new javax.swing.JFrame(), true);
        a.setVisible(true);
    }//GEN-LAST:event_lbl_quenMKMouseClicked

    private void txt_UsernameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_UsernameKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (check_Input()) {
                dangNhap();
            }
        }
    }//GEN-LAST:event_txt_UsernameKeyPressed

    private void txt_PasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_PasswordKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            if (check_Input()) {
                dangNhap();
            }
        }
    }//GEN-LAST:event_txt_PasswordKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Login_Edusys dialog = new Login_Edusys(new javax.swing.JFrame(), true, true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_DangNhap;
    private javax.swing.JButton btn_KetThuc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lbl_Icon_Login;
    private javax.swing.JLabel lbl_background;
    private javax.swing.JLabel lbl_quenMK;
    private javax.swing.JPasswordField txt_Password;
    private javax.swing.JTextField txt_Username;
    // End of variables declaration//GEN-END:variables
}
