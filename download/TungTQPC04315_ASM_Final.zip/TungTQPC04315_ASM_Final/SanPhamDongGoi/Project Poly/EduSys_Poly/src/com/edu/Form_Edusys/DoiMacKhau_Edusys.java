/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.NhanVien_Dao;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import java.awt.Color;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class DoiMacKhau_Edusys extends javax.swing.JDialog {

    /**
     * Creates new form DoiMacKhau_Edusys
     */
    public DoiMacKhau_Edusys(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        
          this.setIconImage(Icon_Logo_FPT.getImg());
    }

    public boolean check_input(){
        
        if(txt_tenDangNhap.getText().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(this, "Không để trống tên đăng nhập");
            txt_tenDangNhap.requestFocus();
            txt_tenDangNhap.setBackground(Color.red);
            return false;
        }
        if(txt_matKhauHT.getText().equalsIgnoreCase("")){
           JOptionPane.showMessageDialog(this, "Không để trống mật khẩu hiện tại");
            txt_matKhauHT.requestFocus();
            txt_tenDangNhap.setBackground(Color.white);
            txt_matKhauHT.setBackground(Color.red);
            return false; 
        }
         if(txt_matKhauMoi.getText().equalsIgnoreCase("")){
           JOptionPane.showMessageDialog(this, "Không để trống mật khẩu mới");
            txt_matKhauMoi.requestFocus();
            txt_matKhauHT.setBackground(Color.white);
            txt_matKhauMoi.setBackground(Color.red);
            return false; 
        }
         if(txt_xacNhanMKMoi.getText().equalsIgnoreCase("")){
           JOptionPane.showMessageDialog(this, "Không để trống xác nhận mật khẩu");
            txt_xacNhanMKMoi.requestFocus();
            txt_matKhauMoi.setBackground(Color.white);
            txt_xacNhanMKMoi.setBackground(Color.red);
            return false; 
        }
         
//         if(txt_tenDangNhap.getText().length() > 7 || txt_tenDangNhap.getText().length() < 7){
//             MsgBox.alert(this, "Tên đăng nhập không được quá 7 ký tự");
//             txt_tenDangNhap.requestFocus();
//             return false;
//         }
        return true;
    }
    
    NhanVien_Dao dao = new NhanVien_Dao();
    private void doiMatKhau(){
        String maNV = txt_tenDangNhap.getText();
        String matKhau = new String(txt_matKhauHT.getText());
        String matKhauMoi = new String(txt_matKhauMoi.getText());
        String xacNhanMKMoi = new String(txt_xacNhanMKMoi.getText());
        if(!maNV.equalsIgnoreCase(Auth.user.getMaNV())){
            MsgBox.alert(this, "Sai tên đăng nhập");
        }else if(!matKhau.equalsIgnoreCase(Auth.user.getMatKhau())){
            MsgBox.alert(this, "Sai mật khẩu");
        }else if(!matKhauMoi.equalsIgnoreCase(xacNhanMKMoi)){
            MsgBox.alert(this, "Xác nhận mật khẩu mới không trùng khớp");
        }else {
            Auth.user.setMatKhau(matKhauMoi);
            dao.update(Auth.user);
            MsgBox.alert(this, "Đổi mật khẩu thành công");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_tenDangNhap = new javax.swing.JTextField();
        btn_Ok = new javax.swing.JButton();
        btn_Ok1 = new javax.swing.JButton();
        txt_matKhauHT = new javax.swing.JPasswordField();
        txt_matKhauMoi = new javax.swing.JPasswordField();
        txt_xacNhanMKMoi = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Đổi Mặc Khẩu");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Đổi Mật Khẩu");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Tên Đăng Nhập ");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Mật Khẩu Hiện Tại ");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("Mật Khẩu Mới  ");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Xác Nhận Lại Mật Khẩu Mới ");

        btn_Ok.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/reset-password.png"))); // NOI18N
        btn_Ok.setText("OK");
        btn_Ok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_OkActionPerformed(evt);
            }
        });

        btn_Ok1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/back_login.png"))); // NOI18N
        btn_Ok1.setText("Huỷ");
        btn_Ok1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ok1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_tenDangNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(63, 63, 63)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_matKhauHT)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(196, 196, 196))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txt_matKhauMoi)
                                        .addGap(63, 63, 63)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(68, 68, 68))
                                    .addComponent(txt_xacNhanMKMoi)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btn_Ok, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(btn_Ok1, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(jLabel1)))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tenDangNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_matKhauHT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_matKhauMoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_xacNhanMKMoi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Ok)
                    .addComponent(btn_Ok1))
                .addGap(35, 35, 35))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_OkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_OkActionPerformed
       if(check_input()){
           doiMatKhau();
       }
    }//GEN-LAST:event_btn_OkActionPerformed

    private void btn_Ok1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ok1ActionPerformed
    int kq = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn huỷ ?","Huỷ",JOptionPane.YES_NO_OPTION);
    if(kq == JOptionPane.YES_OPTION){
        this.dispose();
    }else {
        
    }
    }//GEN-LAST:event_btn_Ok1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DoiMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DoiMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DoiMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DoiMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DoiMacKhau_Edusys dialog = new DoiMacKhau_Edusys(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Ok;
    private javax.swing.JButton btn_Ok1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPasswordField txt_matKhauHT;
    private javax.swing.JPasswordField txt_matKhauMoi;
    private javax.swing.JTextField txt_tenDangNhap;
    private javax.swing.JPasswordField txt_xacNhanMKMoi;
    // End of variables declaration//GEN-END:variables
}
