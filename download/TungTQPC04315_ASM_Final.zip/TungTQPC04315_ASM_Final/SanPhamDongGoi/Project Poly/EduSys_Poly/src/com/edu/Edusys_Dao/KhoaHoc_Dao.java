/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Entity.KhoaHoc;
import com.edu.Helper.JDBC_Helper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class KhoaHoc_Dao extends Edusys_Dao<KhoaHoc, String> {

    String insert_Sql = "insert into khoahoc values(?,?,?,?,?,?,?)";
    String update_Sql = "update khoahoc set MaCD = ?, hocphi = ?, thoiluong = ? "
            + ", ngayKG = ? , ghichu = ? ,MaNV = ?, ngaytao = ? where MaKH = ?";
    String delete_Sql = "delete from khoahoc where MaKH = ?";
    String select_ALL = "select * from khoahoc";
    String select_byid = "select * from khoahoc where MaKH = ?";

    @Override
    public void insert(KhoaHoc entity) {
        JDBC_Helper.update(insert_Sql, entity.getMaCD(), entity.getHocPhi(), entity.getThoiLuong(),
                entity.getNgayKG(), entity.getGhiChu(), entity.getMaNV(), entity.getNgayTao());
    }

    @Override
    public void update(KhoaHoc entity) {
        JDBC_Helper.update(update_Sql, entity.getMaCD(), entity.getHocPhi(), entity.getThoiLuong(),
                entity.getNgayKG(), entity.getGhiChu(), entity.getMaNV(), entity.getNgayTao(), entity.getMaKH());
    }

    @Override
    public void delete(String key) {
        JDBC_Helper.update(delete_Sql, key);
    }

    @Override
    public List<KhoaHoc> selectALL() {
        return this.Select_by_sql(select_ALL);
    }

    @Override
    public KhoaHoc select_ById(String key) {
        List<KhoaHoc> list = this.Select_by_sql(select_byid, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<KhoaHoc> Select_by_sql(String sql, Object... args) {
        List<KhoaHoc> list = new ArrayList<KhoaHoc>();
        try {
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {
                KhoaHoc e = new KhoaHoc();
                e.setMaKH(rs.getInt("MaKH"));
                e.setMaCD(rs.getString("MaCD"));
                e.setHocPhi(rs.getDouble("hocphi"));
                e.setThoiLuong(rs.getInt("thoiluong"));
                e.setNgayKG(rs.getDate("ngayKG"));
                e.setGhiChu(rs.getString("ghichu"));
                e.setMaNV(rs.getString("MaNV"));
                e.setNgayTao(rs.getDate("ngaytao"));
                list.add(e);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<KhoaHoc> selectByChuyenDe(String maCD) {
        String sql = "select * from khoahoc where MaCD = ?";
        return Select_by_sql(sql, maCD);
    }

    public List<Integer> selectYears() {
        String sql = "select distinct year(ngayKG) from khoahoc order by year(ngayKG) desc";
        List<Integer> list = new ArrayList<>();
        try {
            ResultSet rs = JDBC_Helper.query(sql);
            while (rs.next()) {                
                list.add(rs.getInt(1));
                
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    
}
