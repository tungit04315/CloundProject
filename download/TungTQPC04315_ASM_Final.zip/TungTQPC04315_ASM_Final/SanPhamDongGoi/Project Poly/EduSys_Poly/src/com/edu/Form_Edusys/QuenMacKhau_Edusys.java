/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.utils.MsgBox;
import java.awt.Color;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class QuenMacKhau_Edusys extends javax.swing.JDialog {

    
    public QuenMacKhau_Edusys(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        
         this.setIconImage(Icon_Logo_FPT.getImg());
    }

    public boolean check_input(){
        
        if(txt_User.getText().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(this, "Không để trống tên đăng nhập");
            txt_User.requestFocus();
            txt_User.setBackground(Color.red);
            return false;
        }
        if(txt_Email.getText().equalsIgnoreCase("")){
            JOptionPane.showMessageDialog(this, "Không để trống email");
            txt_User.setBackground(Color.white);
            txt_Email.requestFocus();
            txt_Email.setBackground(Color.red);
            return false;
        }else {
             txt_Email.setBackground(Color.white);
        }
         if(txt_User.getText().length() > 7 || txt_User.getText().length() < 7){
            MsgBox.alert(this, "Mã nhân viên không được quá 7 ký tự hoặc ít hơn 7");
            txt_User.requestFocus();
            return false;
        } 
        return true;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_User = new javax.swing.JTextField();
        txt_Email = new javax.swing.JTextField();
        btn_guiYeuCau = new javax.swing.JButton();
        btn_troLai = new javax.swing.JButton();
        lbl_BackGround = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quên Mặc Khẩu");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quên Mật Khẩu ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 200, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Tên Đăng Nhập  ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("Email ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));
        getContentPane().add(txt_User, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 90, 360, -1));
        getContentPane().add(txt_Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 360, -1));

        btn_guiYeuCau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/gmail-logo.png"))); // NOI18N
        btn_guiYeuCau.setText("Gửi yêu cầu");
        btn_guiYeuCau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guiYeuCauActionPerformed(evt);
            }
        });
        getContentPane().add(btn_guiYeuCau, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, -1, -1));

        btn_troLai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/back_login.png"))); // NOI18N
        btn_troLai.setText("Trở lại");
        btn_troLai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_troLaiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_troLai, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 230, -1, -1));

        lbl_BackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/background-QMK.jpg"))); // NOI18N
        getContentPane().add(lbl_BackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_guiYeuCauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guiYeuCauActionPerformed
        if(check_input()){
            
        }
    }//GEN-LAST:event_btn_guiYeuCauActionPerformed

    private void btn_troLaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_troLaiActionPerformed
        this.dispose();
        Login_Edusys a = new Login_Edusys(null, true,false);
        a.setVisible(true);
    }//GEN-LAST:event_btn_troLaiActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuenMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuenMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuenMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuenMacKhau_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuenMacKhau_Edusys dialog = new QuenMacKhau_Edusys(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_guiYeuCau;
    private javax.swing.JButton btn_troLai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lbl_BackGround;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_User;
    // End of variables declaration//GEN-END:variables
}
