/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.ChuyenDe_Dao;
import com.edu.Edusys_Dao.HocVien_Dao;
import com.edu.Edusys_Dao.KhoaHoc_Dao;
import com.edu.Edusys_Dao.NguoiHoc_Dao;
import com.edu.Entity.ChuyenDe;
import com.edu.Entity.HocVien;
import com.edu.Entity.KhoaHoc;
import com.edu.Entity.NguoiHoc;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLHV_Edusys1 extends javax.swing.JDialog {

    HocVien_Dao dao = new HocVien_Dao();
    NguoiHoc_Dao nhDao = new NguoiHoc_Dao();
    int index = -1;

    /**
     * Creates new form QLNV_Edusys
     */
    public QLHV_Edusys1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
    }

    public void init() {
        fill_comboBoxChuyenDe();
        locDiem();
    }
    ChuyenDe_Dao cd_Dao = new ChuyenDe_Dao();

    void fill_comboBoxChuyenDe() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_chuyenDe.getModel();
        model.removeAllElements();
        List<ChuyenDe> list = cd_Dao.selectALL();
        for (ChuyenDe cd : list) {
            model.addElement(cd);
        }
        fill_comboBoxKhoaHoc();
    }
    KhoaHoc_Dao kh_Dao = new KhoaHoc_Dao();

    void fill_comboBoxKhoaHoc() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_khoaHoc.getModel();
        model.removeAllElements();
        ChuyenDe cd = (ChuyenDe) cbo_chuyenDe.getSelectedItem();
        if (cd != null) {
            List<KhoaHoc> list = kh_Dao.selectByChuyenDe(cd.getMaCD());
            for (KhoaHoc kh : list) {
                model.addElement(kh);
            }
            fill_TBL_HV();
        }
        
    }

    void fill_tbl_NH() {
        DefaultTableModel model = (DefaultTableModel) tbl_nguoiHoc.getModel();
        model.setRowCount(0);
        try {
            KhoaHoc kh = (KhoaHoc) cbo_khoaHoc.getSelectedItem();
//            System.out.println(String.valueOf(kh.getMaKH()));
            if (kh != null);
            {
                String key = txt_timKiem.getText();

                List<NguoiHoc> list = nhDao.selectNotlnCourse(kh.getMaKH(), key);

                for (NguoiHoc nh : list) {
                    model.addRow(new Object[]{nh.getMaNH(), nh.getHoTen(), nh.isGioiTinh() ? "Nam" : "Nữ",
                        nh.getNgaySinh(), nh.getDienThoai(), nh.getEmail()});
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    void fill_TBL_HV() {
        DefaultTableModel model = (DefaultTableModel) tbl_QLHV.getModel();
        model.setRowCount(0);
        try {
            KhoaHoc kh = (KhoaHoc) cbo_khoaHoc.getSelectedItem();
            if (kh != null) {
                List<HocVien> list = dao.selectByKhoaHoc(kh.getMaKH());
//                System.out.println(String.valueOf(kh.getMaKH()));
                for (int i = 0; i < list.size(); i++) {
                    HocVien hv = list.get(i);
                    String hoTen = nhDao.select_ById(hv.getMaNH()).getHoTen();
                    model.addRow(new Object[]{hv.getMaHV(), hv.getMaNH(), hoTen, hv.getDiem()});
                }
                fill_tbl_NH();
            }
        } catch (Exception e) {
//            e.printStackTrace();
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    void add_HocVien() {
        KhoaHoc kh = (KhoaHoc) cbo_khoaHoc.getSelectedItem();
        for (int index : tbl_nguoiHoc.getSelectedRows()) {
            HocVien hv = new HocVien();
            hv.setMaKH(kh.getMaKH());
            hv.setDiem(0);
            hv.setMaNH((String) tbl_nguoiHoc.getValueAt(index, 0));
            dao.insert(hv);
        }
        fill_TBL_HV();
        tabs_big.setSelectedIndex(1);
    }

    void remove_HV() {
        if (!Auth.isManager()) {
            MsgBox.alert(this, "Bạn không có quyền xoá học viên");
        } else {
            if (MsgBox.confirm(this, "Bạn có muốn xoá các học viên được chọn ?")) {
                for (int row : tbl_QLHV.getSelectedRows()) {
                    int maHV = (Integer) tbl_QLHV.getValueAt(row, 0);
                    dao.delete(String.valueOf(maHV));

                }
                fill_TBL_HV();
            }
        }
    }

    void update_diem() {
        double diem = 0;
        index = tbl_QLHV.getSelectedRow();
        try {
            diem = Double.parseDouble(tbl_QLHV.getValueAt(index, 3).toString());
            if (diem < 0 || diem > 10) {
                MsgBox.alert(this, "Điểm không được bé hơn 0 hoặc lớn hơn 10");
            } else {
                for (int i = 0; i < tbl_QLHV.getRowCount(); i++) {
                    int mahv = (Integer) tbl_QLHV.getValueAt(i, 0);
                    HocVien hv = dao.select_ById(String.valueOf(mahv));
                    hv.setDiem(Double.parseDouble(tbl_QLHV.getValueAt(i, 3).toString()));
                    dao.update(hv);
                }
                MsgBox.alert(this, "Cập nhật thành công");
            }
        } catch (Exception e) {
        }

    }

    void timKiem() {
        fill_tbl_NH();

    }

    void locDiem() {
        if (rdo_all.isSelected() == true) {
            fill_TBL_HV();
        }
        if (rdo_not_input_score.isSelected() == true) {
            DefaultTableModel model = (DefaultTableModel) tbl_QLHV.getModel();
            model.setRowCount(0);
            try {
                int diem = -1;
                List<HocVien> list = dao.selectALLFromDiem(diem);

                for (int i = 0; i < list.size(); i++) {
                    HocVien hv = list.get(i);
                    String hoTen = nhDao.select_ById(hv.getMaNH()).getHoTen();
                    model.addRow(new Object[]{hv.getMaHV(), hv.getMaNH(), hoTen, hv.getDiem()});
                }

            } catch (Exception e) {
                MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
            }
        }
        if (rdo_input_score.isSelected() == true) {
            DefaultTableModel model = (DefaultTableModel) tbl_QLHV.getModel();
            model.setRowCount(0);
            try {

                List<HocVien> list = dao.selectALLFromDiemLonHon0();

                for (int i = 0; i < list.size(); i++) {
                    HocVien hv = list.get(i);
                    String hoTen = nhDao.select_ById(hv.getMaNH()).getHoTen();
                    model.addRow(new Object[]{hv.getMaHV(), hv.getMaNH(), hoTen, hv.getDiem()});
                }

            } catch (Exception e) {
                MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
            }
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tabs_big = new javax.swing.JTabbedPane();
        pnl_edit = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txt_timKiem = new javax.swing.JTextField();
        btn_timKiem = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_nguoiHoc = new javax.swing.JTable();
        btn_themKhoaHoc = new javax.swing.JButton();
        pnl_list = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLHV = new javax.swing.JTable();
        btn_capNhatDiem = new javax.swing.JButton();
        rdo_all = new javax.swing.JRadioButton();
        rdo_input_score = new javax.swing.JRadioButton();
        rdo_not_input_score = new javax.swing.JRadioButton();
        btn_xoaKH = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbo_chuyenDe = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cbo_khoaHoc = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                                  Quản Lý Học Viên");
        setPreferredSize(new java.awt.Dimension(650, 650));

        pnl_edit.setToolTipText("");

        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Tìm Kiếm ");

        btn_timKiem.setText("Tìm");
        btn_timKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txt_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE)
                .addComponent(btn_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timKiem))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        tbl_nguoiHoc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã Người Học", "Họ Tên", "Giới Tính", "Ngày Sinh", "Điện Thoại", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tbl_nguoiHoc);
        if (tbl_nguoiHoc.getColumnModel().getColumnCount() > 0) {
            tbl_nguoiHoc.getColumnModel().getColumn(0).setMaxWidth(150);
            tbl_nguoiHoc.getColumnModel().getColumn(1).setMinWidth(200);
            tbl_nguoiHoc.getColumnModel().getColumn(2).setMaxWidth(50);
        }

        btn_themKhoaHoc.setText("Thêm Vào Khoá Học");
        btn_themKhoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themKhoaHocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_editLayout = new javax.swing.GroupLayout(pnl_edit);
        pnl_edit.setLayout(pnl_editLayout);
        pnl_editLayout.setHorizontalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_editLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_themKhoaHoc)
                .addContainerGap())
        );
        pnl_editLayout.setVerticalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(btn_themKhoaHoc)
                .addContainerGap())
        );

        tabs_big.addTab("Người Học", pnl_edit);

        tbl_QLHV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"", "", "", ""},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã Học Viên", "Mã Người Học", "Họ Tên", "Điểm"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_QLHV);

        btn_capNhatDiem.setText("Cập Nhật Điểm");
        btn_capNhatDiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_capNhatDiemActionPerformed(evt);
            }
        });

        buttonGroup2.add(rdo_all);
        rdo_all.setSelected(true);
        rdo_all.setText("Tất Cả");
        rdo_all.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_allMouseClicked(evt);
            }
        });

        buttonGroup2.add(rdo_input_score);
        rdo_input_score.setText("Nhập Điểm");
        rdo_input_score.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_input_scoreMouseClicked(evt);
            }
        });

        buttonGroup2.add(rdo_not_input_score);
        rdo_not_input_score.setText("Chưa Nhập Điểm");
        rdo_not_input_score.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_not_input_scoreMouseClicked(evt);
            }
        });
        rdo_not_input_score.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_not_input_scoreActionPerformed(evt);
            }
        });

        btn_xoaKH.setText("Xoá Khỏi Khoá Học");
        btn_xoaKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaKHActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_listLayout = new javax.swing.GroupLayout(pnl_list);
        pnl_list.setLayout(pnl_listLayout);
        pnl_listLayout.setHorizontalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
            .addGroup(pnl_listLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(rdo_all, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(rdo_input_score, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rdo_not_input_score)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_xoaKH)
                .addGap(18, 18, 18)
                .addComponent(btn_capNhatDiem, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnl_listLayout.setVerticalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_listLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_capNhatDiem)
                    .addComponent(rdo_all)
                    .addComponent(rdo_input_score)
                    .addComponent(rdo_not_input_score)
                    .addComponent(btn_xoaKH))
                .addGap(19, 19, 19))
        );

        tabs_big.addTab("Học Viên", pnl_list);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quản Lý Học Viên");

        jPanel2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 102, 0));
        jLabel2.setText("Chuyên Đề");

        cbo_chuyenDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_chuyenDeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 176, Short.MAX_VALUE))
                    .addComponent(cbo_chuyenDe, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(cbo_chuyenDe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 0));
        jLabel3.setText("Khoá Học");

        cbo_khoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_khoaHocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 191, Short.MAX_VALUE))
                    .addComponent(cbo_khoaHoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(cbo_khoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs_big)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(tabs_big, javax.swing.GroupLayout.PREFERRED_SIZE, 432, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rdo_not_input_scoreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_not_input_scoreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdo_not_input_scoreActionPerformed

    private void btn_themKhoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themKhoaHocActionPerformed
        add_HocVien();
    }//GEN-LAST:event_btn_themKhoaHocActionPerformed

    private void btn_xoaKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaKHActionPerformed
        remove_HV();
    }//GEN-LAST:event_btn_xoaKHActionPerformed

    private void btn_capNhatDiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_capNhatDiemActionPerformed
        update_diem();
    }//GEN-LAST:event_btn_capNhatDiemActionPerformed

    private void btn_timKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timKiemActionPerformed
        timKiem();
    }//GEN-LAST:event_btn_timKiemActionPerformed

    private void rdo_allMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_allMouseClicked
        locDiem();
    }//GEN-LAST:event_rdo_allMouseClicked

    private void rdo_input_scoreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_input_scoreMouseClicked
        locDiem();
    }//GEN-LAST:event_rdo_input_scoreMouseClicked

    private void rdo_not_input_scoreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_not_input_scoreMouseClicked
        locDiem();
    }//GEN-LAST:event_rdo_not_input_scoreMouseClicked

    private void cbo_chuyenDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_chuyenDeActionPerformed
       fill_comboBoxKhoaHoc();
    }//GEN-LAST:event_cbo_chuyenDeActionPerformed

    private void cbo_khoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_khoaHocActionPerformed
        fill_TBL_HV();
    }//GEN-LAST:event_cbo_khoaHocActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLHV_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLHV_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLHV_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLHV_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLHV_Edusys1 dialog = new QLHV_Edusys1(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_capNhatDiem;
    private javax.swing.JButton btn_themKhoaHoc;
    private javax.swing.JButton btn_timKiem;
    private javax.swing.JButton btn_xoaKH;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cbo_chuyenDe;
    private javax.swing.JComboBox<String> cbo_khoaHoc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pnl_edit;
    private javax.swing.JPanel pnl_list;
    private javax.swing.JRadioButton rdo_all;
    private javax.swing.JRadioButton rdo_input_score;
    private javax.swing.JRadioButton rdo_not_input_score;
    private javax.swing.JTabbedPane tabs_big;
    private javax.swing.JTable tbl_QLHV;
    private javax.swing.JTable tbl_nguoiHoc;
    private javax.swing.JTextField txt_timKiem;
    // End of variables declaration//GEN-END:variables
}
