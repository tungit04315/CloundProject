/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class GioiThieuSanPham extends javax.swing.JDialog {

    /**
     * Creates new form GioiThieuSanPham
     */
    public GioiThieuSanPham(java.awt.Frame parent, boolean modal) {
	super(parent, modal);
	initComponents();
	this.setIconImage(Icon_Logo_FPT.getImg());
init();
//	String CENTER = "\n\n\n"
//		+ "               Click Double Vào LOGO Ở Trên";
//
//	txt_noiDung.setEditable(false);
//	txt_noiDung.setText(CENTER);
    }

    void init() {
//        txt_noiDung.setText("Click Double Vào LOGO Ở Trên");
	gioiThieu();
    }

    void gioiThieu() {
	String nd = "\n"
		+ "    Polypro là dự án mẫu. Mục tiêu chính là huấn luyện sinh viên qui trình thực hiện dự án\n"
		+ "\n"
		+ "    Mục tiêu của dự án này là để rèn luyện kỹ năng IO (CDIO) tức không yêu cầu sinh viên phải thu thập\n"
		+ "    Phân tích mà chỉ thực hiện và vận hành một phần mềm chuẩn bị cho các dự án sau này. Các kỹ\n"
		+ "    năng CD (trong CDIO) sẽ được huấn luyện ở dự án 1 và 2\n"
		+ "\n"
		+ "    Yêu cầu Về Môi Trường : \n"
		+ "    1. Hệ Điều Hành Window 7+\n"
		+ "    2. JDK 17 trở lên\n"
		+ "    3. SQL Server 2019 trở lên.\n"
		+ "================================\n"
		+ "    CodeRelax\n"
		+ "    Version 1.7";
	txt_noiDung.setText(nd);
	txt_noiDung.setVisible(true);
	txt_noiDung.setEditable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbl_logoFPT = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_noiDung = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Giới Thiệu");
        setBackground(new java.awt.Color(255, 255, 255));

        lbl_logoFPT.setBackground(new java.awt.Color(255, 255, 255));
        lbl_logoFPT.setForeground(new java.awt.Color(255, 255, 255));
        lbl_logoFPT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/FPT_Polytechnic (1).png"))); // NOI18N
        lbl_logoFPT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_logoFPTMouseClicked(evt);
            }
        });

        txt_noiDung.setColumns(20);
        txt_noiDung.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        txt_noiDung.setRows(5);
        txt_noiDung.setText("\n");
        txt_noiDung.setBorder(null);
        txt_noiDung.setCaretColor(new java.awt.Color(204, 204, 204));
        jScrollPane1.setViewportView(txt_noiDung);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbl_logoFPT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lbl_logoFPT, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lbl_logoFPTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_logoFPTMouseClicked
//	if (evt.getClickCount() >= 2) {
//	    gioiThieu();
//	} else {
//	    String CENTER = "\n\n\n"
//		    + "               Click Double Vào LOGO Ở Trên";
//
//	    txt_noiDung.setEditable(false);
//	    txt_noiDung.setText(CENTER);
//	}
    }//GEN-LAST:event_lbl_logoFPTMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
	/* Set the Nimbus look and feel */
	//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	 */
	try {
	    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
		if ("Nimbus".equals(info.getName())) {
		    javax.swing.UIManager.setLookAndFeel(info.getClassName());
		    break;
		}
	    }
	} catch (ClassNotFoundException ex) {
	    java.util.logging.Logger.getLogger(GioiThieuSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (InstantiationException ex) {
	    java.util.logging.Logger.getLogger(GioiThieuSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (IllegalAccessException ex) {
	    java.util.logging.Logger.getLogger(GioiThieuSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (javax.swing.UnsupportedLookAndFeelException ex) {
	    java.util.logging.Logger.getLogger(GioiThieuSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	}
	//</editor-fold>

	/* Create and display the dialog */
	java.awt.EventQueue.invokeLater(new Runnable() {
	    public void run() {

		GioiThieuSanPham dialog = new GioiThieuSanPham(new javax.swing.JFrame(), true);

		dialog.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent e) {
			System.exit(0);
		    }
		});
		dialog.setVisible(true);
	    }
	});
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_logoFPT;
    private javax.swing.JTextArea txt_noiDung;
    // End of variables declaration//GEN-END:variables
}
