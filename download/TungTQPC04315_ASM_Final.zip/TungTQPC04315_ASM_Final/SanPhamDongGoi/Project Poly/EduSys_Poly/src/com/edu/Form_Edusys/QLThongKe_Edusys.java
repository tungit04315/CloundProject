/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.KhoaHoc_Dao;
import com.edu.Edusys_Dao.ThongKe_Dao;
import com.edu.Entity.KhoaHoc;
import com.edu.utils.Auth;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLThongKe_Edusys extends javax.swing.JDialog {

    ThongKe_Dao dao = new ThongKe_Dao();
    KhoaHoc_Dao kh_dao = new KhoaHoc_Dao();
//   string cboNamModel = null;

    public QLThongKe_Edusys(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        
        //cboNamModel
        //fill name 
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());

        init();
    }

    private void init() {
        fill_ComboBox_KhoaHoc();
        fill_ComboBox_Nam();
        fill_TBL_LuongNH();
        fill_TBL_BangDiem();

        fill_TBL_DiemCD();
        fill_TBL_DoanhThu();

        selectTab(0);
        if (!Auth.isManager()) {
            tabs_Big.remove(3);
        }
    }

    void selectTab(int i) {
        tabs_Big.setSelectedIndex(i);
//        System.out.println(i);
    }

    private void fill_TBL_BangDiem() {
        DefaultTableModel model = (DefaultTableModel) tbl_TK_Diem.getModel();
        model.setRowCount(0);
        KhoaHoc kh = (KhoaHoc) cbo_khoaHoc.getSelectedItem();
        if (kh != null) {
            List<Object[]> list = dao.getBangDiem(kh.getMaKH());
//            System.out.println("mã KH"+kh.getMaKH());
            for (Object[] row : list) {
                double diem = (double) row[2];
                model.addRow(new Object[]{row[0], row[1], diem, getXepLoai(diem)});
            }
        }
    }

    private void fill_TBL_LuongNH() {
        DefaultTableModel model = (DefaultTableModel) tbl_TK_NguoiHoc.getModel();
        model.setRowCount(0);
        List<Object[]> list = dao.getLuongNguoiHoc();
        for (Object[] row : list) {
            model.addRow(row);
        }
    }

    private void fill_TBL_DoanhThu() {
        DefaultTableModel model = (DefaultTableModel) tbl_TK_DoanhThu.getModel();
        model.setRowCount(0);
        if(cbo_Nam.getSelectedItem() != null){
        int nam = (Integer) cbo_Nam.getSelectedItem();
        
//        System.out.println("nam" + cbo_Nam.getSelectedItem());

        List<Object[]> list = dao.getDoanhThu(nam);
        for (Object[] row : list) {
            model.addRow(row);
        }
        }

    }

    private void fill_TBL_DiemCD() {
        DefaultTableModel model = (DefaultTableModel) tbl_TK_diemChuyenDe.getModel();
        model.setRowCount(0);
        List<Object[]> list = dao.getDiemChuyenDe();
        for (Object[] row : list) {
            model.addRow(new Object[]{row[0], row[1], row[2], row[3], String.format("%.1f", row[4])});
        }
    }

    private String getXepLoai(double diem) {
        if (diem < 5) {
            return "Chưa Đạt";
        }
        if (diem < 6.5) {
            return "Trung Bình";
        }
        if (diem < 7.5) {
            return "Khá";
        }
        if (diem < 9) {
            return "Giỏi";
        } else {
            return "Xuất Sắc";
        }
    }

    private void fill_ComboBox_Nam() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_Nam.getModel();
        model.removeAllElements();
        List<Integer> list = kh_dao.selectYears();
        for (Integer year : list) {
            model.addElement(year);
        }
    }

    private void fill_ComboBox_KhoaHoc() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_khoaHoc.getModel();
        model.removeAllElements();

        List<KhoaHoc> list = kh_dao.selectALL();
        for (KhoaHoc kh : list) {
            model.addElement(kh);
        }
        cbo_khoaHoc.setSelectedIndex(0);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabs_Big = new javax.swing.JTabbedPane();
        pnl_nguoiHoc = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_TK_NguoiHoc = new javax.swing.JTable();
        pnl_bangDiem = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_TK_Diem = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        cbo_khoaHoc = new javax.swing.JComboBox<>();
        pnl_tongHopDiem = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_TK_diemChuyenDe = new javax.swing.JTable();
        pnl_doanhThu = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbo_Nam = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_TK_DoanhThu = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Tổng Hợp Thống Kê");

        tbl_TK_NguoiHoc.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Năm", "Số Người Học", "Đầu Tiên ", "Sau Cùng"
            }
        ));
        jScrollPane1.setViewportView(tbl_TK_NguoiHoc);

        javax.swing.GroupLayout pnl_nguoiHocLayout = new javax.swing.GroupLayout(pnl_nguoiHoc);
        pnl_nguoiHoc.setLayout(pnl_nguoiHocLayout);
        pnl_nguoiHocLayout.setHorizontalGroup(
            pnl_nguoiHocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
        );
        pnl_nguoiHocLayout.setVerticalGroup(
            pnl_nguoiHocLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
        );

        tabs_Big.addTab("Người Học", pnl_nguoiHoc);

        tbl_TK_Diem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã Người Học", "Họ Tên", "Điểm ", "Xếp Loại"
            }
        ));
        jScrollPane2.setViewportView(tbl_TK_Diem);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Khoá Học ");

        cbo_khoaHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "PR03(2022/22/09)" }));
        cbo_khoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_khoaHocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_bangDiemLayout = new javax.swing.GroupLayout(pnl_bangDiem);
        pnl_bangDiem.setLayout(pnl_bangDiemLayout);
        pnl_bangDiemLayout.setHorizontalGroup(
            pnl_bangDiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
            .addGroup(pnl_bangDiemLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(cbo_khoaHoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnl_bangDiemLayout.setVerticalGroup(
            pnl_bangDiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_bangDiemLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_bangDiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbo_khoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE))
        );

        tabs_Big.addTab("Bảng Điểm", pnl_bangDiem);

        tbl_TK_diemChuyenDe.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Chuyên Đề", "Tổng Số HV ", "Cao Nhất", "Thấp Nhất", "Điểm TB"
            }
        ));
        jScrollPane3.setViewportView(tbl_TK_diemChuyenDe);

        javax.swing.GroupLayout pnl_tongHopDiemLayout = new javax.swing.GroupLayout(pnl_tongHopDiem);
        pnl_tongHopDiem.setLayout(pnl_tongHopDiemLayout);
        pnl_tongHopDiemLayout.setHorizontalGroup(
            pnl_tongHopDiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
        );
        pnl_tongHopDiemLayout.setVerticalGroup(
            pnl_tongHopDiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 492, Short.MAX_VALUE)
        );

        tabs_Big.addTab("Tổng Hợp Điểm", pnl_tongHopDiem);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Năm");

        cbo_Nam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2023" }));
        cbo_Nam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_NamActionPerformed(evt);
            }
        });

        tbl_TK_DoanhThu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Chuyên Đề", "Số Khoá", "Số HV", "Doanh Thu", "HP Cao Nhất", "HP Thấp Nhất", "HP Trung Bình"
            }
        ));
        jScrollPane4.setViewportView(tbl_TK_DoanhThu);

        javax.swing.GroupLayout pnl_doanhThuLayout = new javax.swing.GroupLayout(pnl_doanhThu);
        pnl_doanhThu.setLayout(pnl_doanhThuLayout);
        pnl_doanhThuLayout.setHorizontalGroup(
            pnl_doanhThuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_doanhThuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbo_Nam, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 669, Short.MAX_VALUE)
        );
        pnl_doanhThuLayout.setVerticalGroup(
            pnl_doanhThuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_doanhThuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_doanhThuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbo_Nam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE))
        );

        tabs_Big.addTab("Doanh Thu", pnl_doanhThu);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 0));
        jLabel3.setText("Tổng Hợp Thống Kê");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs_Big)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(tabs_Big, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cbo_khoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_khoaHocActionPerformed
        fill_TBL_BangDiem();
    }//GEN-LAST:event_cbo_khoaHocActionPerformed

    private void cbo_NamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_NamActionPerformed
        fill_TBL_DoanhThu();
    }//GEN-LAST:event_cbo_NamActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLThongKe_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLThongKe_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLThongKe_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLThongKe_Edusys.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLThongKe_Edusys dialog = new QLThongKe_Edusys(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbo_Nam;
    private javax.swing.JComboBox<String> cbo_khoaHoc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JPanel pnl_bangDiem;
    private javax.swing.JPanel pnl_doanhThu;
    private javax.swing.JPanel pnl_nguoiHoc;
    private javax.swing.JPanel pnl_tongHopDiem;
    private javax.swing.JTabbedPane tabs_Big;
    private javax.swing.JTable tbl_TK_Diem;
    private javax.swing.JTable tbl_TK_DoanhThu;
    private javax.swing.JTable tbl_TK_NguoiHoc;
    private javax.swing.JTable tbl_TK_diemChuyenDe;
    // End of variables declaration//GEN-END:variables
}
