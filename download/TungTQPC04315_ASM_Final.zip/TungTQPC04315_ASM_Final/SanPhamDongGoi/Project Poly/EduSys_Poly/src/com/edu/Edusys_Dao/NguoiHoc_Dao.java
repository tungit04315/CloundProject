/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Entity.NguoiHoc;
import com.edu.Helper.JDBC_Helper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class NguoiHoc_Dao extends Edusys_Dao<NguoiHoc, String> {

    String insert_Sql = "insert into nguoihoc values(?,?,?,?,?,?,?,?,?)";
    String update_Sql = "update nguoihoc set hoten = ?, ngaysinh = ?, gioitinh = ? "
            + ", dienthoai = ? , email = ?,ghichu = ? where MaNH = ?";
    String delete_Sql = "delete from nguoihoc where MaNH = ?";
    String select_ALL = "select * from nguoihoc";
    String select_byid = "select * from nguoihoc where MaNH = ?";

    @Override
    public void insert(NguoiHoc entity) {
        JDBC_Helper.update(insert_Sql, entity.getMaNH(), entity.getHoTen(),
                entity.getNgaySinh(), entity.isGioiTinh(),
                entity.getDienThoai(), entity.getEmail(), entity.getGhiChu(),
                entity.getMaNV(), entity.getNgayDK());
    }

    @Override
    public void update(NguoiHoc entity) {
        JDBC_Helper.update(update_Sql, entity.getHoTen(), entity.getNgaySinh(), entity.isGioiTinh(),
                entity.getDienThoai(), entity.getEmail(), entity.getGhiChu(), entity.getMaNH());
    }

    @Override
    public void delete(String key) {
        JDBC_Helper.update(delete_Sql, key);
    }

    @Override
    public List<NguoiHoc> selectALL() {
        return this.Select_by_sql(select_ALL);
    }

    @Override
    public NguoiHoc select_ById(String key) {
        List<NguoiHoc> list = this.Select_by_sql(select_byid, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<NguoiHoc> Select_by_sql(String sql, Object... args) {
        List<NguoiHoc> list = new ArrayList<NguoiHoc>();
        try {
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {
                NguoiHoc e = new NguoiHoc();
                e.setMaNH(rs.getString("MaNH"));
                e.setHoTen(rs.getString("hoten"));
                e.setNgaySinh(rs.getDate("ngaysinh"));
                e.setGioiTinh(rs.getBoolean("gioitinh"));
                e.setDienThoai(rs.getString("dienthoai"));
                e.setEmail(rs.getString("email"));
                e.setGhiChu(rs.getString("ghichu"));
                e.setMaNV(rs.getString("MaNV"));
                e.setNgayDK(rs.getDate("ngayDK"));
                list.add(e);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<NguoiHoc> selectByKeyWord(String key) {
        String sql = "select * from nguoihoc where hoten like ?";
        return this.Select_by_sql(sql, "%" + key + "%");
    }

    public List<NguoiHoc> selectNotlnCourse(int maKH, String key) {
        String sql = "select * from nguoihoc where hoten like ? AND MaNH not in (select MaNH from hocvien where MaKH = ?)";
        return this.Select_by_sql(sql, "%" + key + "%", maKH);
    }
}
