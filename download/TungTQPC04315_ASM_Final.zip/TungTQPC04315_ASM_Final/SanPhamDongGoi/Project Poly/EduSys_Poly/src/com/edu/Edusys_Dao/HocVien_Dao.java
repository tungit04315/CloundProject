/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.edu.Edusys_Dao;

import com.edu.Entity.HocVien;
import com.edu.Helper.JDBC_Helper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class HocVien_Dao extends Edusys_Dao<HocVien, String> {

    String insert_Sql = "insert into hocvien values(?,?,?)";
    String update_Sql = "update hocvien set diem = ? where MaHV = ?";
    String delete_Sql = "delete from hocvien where MaHV = ?";
    String select_ALL = "select * from hocvien";
    String select_byid = "select * from hocvien where MaHV = ?";
    String select_Diemzero = "select * from hocvien where diem = ?";
    String select_DiemLH = "select * from hocvien where diem > -1";

    @Override
    public void insert(HocVien entity) {
        JDBC_Helper.update(insert_Sql, entity.getMaKH(), entity.getMaNH(), entity.getDiem());
    }

    @Override
    public void update(HocVien entity) {
        JDBC_Helper.update(update_Sql, entity.getDiem(), entity.getMaHV());
    }

    @Override
    public void delete(String key) {
        JDBC_Helper.update(delete_Sql, key);
    }

   
    public List<HocVien> selectALLFromDiem(int key) {
        return this.Select_by_sql(select_Diemzero, key);
    }
    
      public List<HocVien> selectALLFromDiemLonHon0() {
        return this.Select_by_sql(select_DiemLH);
    }

    @Override
    public List<HocVien> selectALL() {
        return this.Select_by_sql(select_ALL);
    }

    @Override
    public HocVien select_ById(String key) {
        List<HocVien> list = this.Select_by_sql(select_byid, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<HocVien> Select_by_sql(String sql, Object... args) {
        List<HocVien> list = new ArrayList<HocVien>();
        try {
            ResultSet rs = JDBC_Helper.query(sql, args);
            while (rs.next()) {
                HocVien e = new HocVien();
                e.setMaHV(rs.getInt("MaHV"));
                e.setMaKH(rs.getInt("MaKH"));
                e.setMaNH(rs.getString("MaNH"));
                e.setDiem(rs.getFloat("diem"));

                list.add(e);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<HocVien> selectByKhoaHoc(int MaKH) {
        String sql = "select * from hocvien where MaKH = ?";
        return this.Select_by_sql(sql, MaKH);
    }
}
