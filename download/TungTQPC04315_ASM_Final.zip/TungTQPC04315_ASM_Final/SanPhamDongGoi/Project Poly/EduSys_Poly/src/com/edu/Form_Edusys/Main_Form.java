/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.NhanVien_Dao;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author tungt
 */
public class Main_Form extends javax.swing.JFrame {

    /**
     * Creates new form Main_Form
     */
    public Main_Form() {
        initComponents();
        this.setIconImage(Icon_Logo_FPT.getImg());
        
//        inti();
    }
    
    public void inti() {
//        new Hi_Edusys(this, true).setVisible(true);
//        new Login_Edusys(this, true).setVisible(true);

        new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date now = new Date();
                
                SimpleDateFormat format = new SimpleDateFormat("hh:mm aa");
                String txt = format.format(now);
                
                lbl_DongHo.setText(txt);
            }
        }).start();
        
        this.setResizable(false);
        lbl_maNV.setText("Mã Nhân Viên : "+Auth.user.getMaNV());
    }
    
    void open_Tk(int i){
        if(i == 3 && !Auth.isManager()){
            MsgBox.alert(this, "Bạn không có quyền xem doanh thu");
        }else {
            QLThongKe_Edusys tk = new QLThongKe_Edusys(new javax.swing.JFrame(), true);
            tk.selectTab(i);
            tk.setVisible(true);
            
        }
    }
    
    void openHuongDan(){
        try {
            Desktop.getDesktop().browse(new File("Help/index.html").toURI());
        } catch (Exception e) {
            MsgBox.alert(this, "Không tìm thấy File hướng dẫn !!!");
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        btn_dangXuat = new javax.swing.JButton();
        btn_ketThuc_out = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JToolBar.Separator();
        btn_QLCD = new javax.swing.JButton();
        btn_QLNH = new javax.swing.JButton();
        btn_QLKH = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        btn_huongDan = new javax.swing.JButton();
        pnl_trangThai = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lbl_DongHo = new javax.swing.JLabel();
        lbl_maNV = new javax.swing.JLabel();
        lbl_Background = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnu_heThong = new javax.swing.JMenu();
        mni_dangXuat = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        mni_doiMacKhau = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        mni_ketThuc = new javax.swing.JMenuItem();
        mnu_quanLy = new javax.swing.JMenu();
        mni_QLCD = new javax.swing.JMenuItem();
        mni_QLKH = new javax.swing.JMenuItem();
        mni_QLNH = new javax.swing.JMenuItem();
        mni_QLHV = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        mni_QLNV = new javax.swing.JMenuItem();
        mnu_thongKe = new javax.swing.JMenu();
        mni_nguoiHocTungNam = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        mni_bangDiemKhoaHoc = new javax.swing.JMenuItem();
        mni_diemTungKhoaHoc = new javax.swing.JMenuItem();
        jSeparator7 = new javax.swing.JPopupMenu.Separator();
        mni_doanhThu = new javax.swing.JMenuItem();
        mnu_troGiup = new javax.swing.JMenu();
        mni_huongDan = new javax.swing.JMenuItem();
        jSeparator8 = new javax.swing.JPopupMenu.Separator();
        mni_gioiThieu = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("                                                                   Hệ Thống Quản Lý Đào Tạo");
        setResizable(false);

        jToolBar1.setRollover(true);

        btn_dangXuat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/log-out_24.png"))); // NOI18N
        btn_dangXuat.setText("Đăng Xuất");
        btn_dangXuat.setFocusable(false);
        btn_dangXuat.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_dangXuat.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_dangXuat.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_dangXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dangXuatActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_dangXuat);

        btn_ketThuc_out.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/end_24.png"))); // NOI18N
        btn_ketThuc_out.setText("Kết Thúc");
        btn_ketThuc_out.setFocusable(false);
        btn_ketThuc_out.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_ketThuc_out.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_ketThuc_out.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_ketThuc_out.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ketThuc_outActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_ketThuc_out);
        jToolBar1.add(jSeparator1);

        btn_QLCD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/topic_24.png"))); // NOI18N
        btn_QLCD.setText("Chuyên Đề");
        btn_QLCD.setFocusable(false);
        btn_QLCD.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_QLCD.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_QLCD.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_QLCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QLCDActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_QLCD);

        btn_QLNH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/students_24.png"))); // NOI18N
        btn_QLNH.setText("Người Học");
        btn_QLNH.setFocusable(false);
        btn_QLNH.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_QLNH.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_QLNH.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_QLNH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QLNHActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_QLNH);

        btn_QLKH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/course_24.png"))); // NOI18N
        btn_QLKH.setText("Khoá Học");
        btn_QLKH.setFocusable(false);
        btn_QLKH.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_QLKH.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_QLKH.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_QLKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QLKHActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_QLKH);
        jToolBar1.add(jSeparator2);

        btn_huongDan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/user-guide_24.png"))); // NOI18N
        btn_huongDan.setText("Hướng Dẫn");
        btn_huongDan.setFocusable(false);
        btn_huongDan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_huongDan.setMaximumSize(new java.awt.Dimension(80, 49));
        btn_huongDan.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_huongDan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_huongDanActionPerformed(evt);
            }
        });
        jToolBar1.add(btn_huongDan);

        pnl_trangThai.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/information_16.png"))); // NOI18N
        jLabel1.setText("Hệ Quản Lý Đào Tạo");

        lbl_DongHo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/alarm-clock_16.png"))); // NOI18N
        lbl_DongHo.setText("1:10 PM");

        lbl_maNV.setText("Mã Nhân Viên");

        javax.swing.GroupLayout pnl_trangThaiLayout = new javax.swing.GroupLayout(pnl_trangThai);
        pnl_trangThai.setLayout(pnl_trangThaiLayout);
        pnl_trangThaiLayout.setHorizontalGroup(
            pnl_trangThaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_trangThaiLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(175, 175, 175)
                .addComponent(lbl_maNV)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_DongHo, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnl_trangThaiLayout.setVerticalGroup(
            pnl_trangThaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_trangThaiLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_trangThaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lbl_DongHo)
                    .addComponent(lbl_maNV))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lbl_Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/LogoFPT.png"))); // NOI18N

        mnu_heThong.setText("Hệ Thống");

        mni_dangXuat.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_dangXuat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/log-out_24_2.png"))); // NOI18N
        mni_dangXuat.setText("Đăng Xuất");
        mni_dangXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_dangXuatActionPerformed(evt);
            }
        });
        mnu_heThong.add(mni_dangXuat);
        mnu_heThong.add(jSeparator3);

        mni_doiMacKhau.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_T, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_doiMacKhau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/reset-password.png"))); // NOI18N
        mni_doiMacKhau.setText("Đổi Mặc Khẩu ");
        mni_doiMacKhau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_doiMacKhauActionPerformed(evt);
            }
        });
        mnu_heThong.add(mni_doiMacKhau);
        mnu_heThong.add(jSeparator4);

        mni_ketThuc.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F10, 0));
        mni_ketThuc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/stop.png"))); // NOI18N
        mni_ketThuc.setText("Kết Thúc");
        mni_ketThuc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_ketThucActionPerformed(evt);
            }
        });
        mnu_heThong.add(mni_ketThuc);

        jMenuBar1.add(mnu_heThong);

        mnu_quanLy.setText("Quản Lý");

        mni_QLCD.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_QLCD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/topic_24.png"))); // NOI18N
        mni_QLCD.setText("Chuyên Đề ");
        mni_QLCD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_QLCDActionPerformed(evt);
            }
        });
        mnu_quanLy.add(mni_QLCD);

        mni_QLKH.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_QLKH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/course_24.png"))); // NOI18N
        mni_QLKH.setText("Khoá Học");
        mni_QLKH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_QLKHActionPerformed(evt);
            }
        });
        mnu_quanLy.add(mni_QLKH);

        mni_QLNH.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_QLNH.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/students_24.png"))); // NOI18N
        mni_QLNH.setText("Người Học");
        mni_QLNH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_QLNHActionPerformed(evt);
            }
        });
        mnu_quanLy.add(mni_QLNH);

        mni_QLHV.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_QLHV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/graduated.png"))); // NOI18N
        mni_QLHV.setText("Học Viên");
        mni_QLHV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_QLHVActionPerformed(evt);
            }
        });
        mnu_quanLy.add(mni_QLHV);
        mnu_quanLy.add(jSeparator5);

        mni_QLNV.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_5, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        mni_QLNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/best-employee.png"))); // NOI18N
        mni_QLNV.setText("Nhân Viên");
        mni_QLNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_QLNVActionPerformed(evt);
            }
        });
        mnu_quanLy.add(mni_QLNV);

        jMenuBar1.add(mnu_quanLy);

        mnu_thongKe.setText("Thống Kê");

        mni_nguoiHocTungNam.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mni_nguoiHocTungNam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/student_statistical.png"))); // NOI18N
        mni_nguoiHocTungNam.setText("Người Học Từng Năm");
        mni_nguoiHocTungNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_nguoiHocTungNamActionPerformed(evt);
            }
        });
        mnu_thongKe.add(mni_nguoiHocTungNam);
        mnu_thongKe.add(jSeparator6);

        mni_bangDiemKhoaHoc.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_2, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mni_bangDiemKhoaHoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/letter.png"))); // NOI18N
        mni_bangDiemKhoaHoc.setText("Bảng Điểm Khoá Học");
        mni_bangDiemKhoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_bangDiemKhoaHocActionPerformed(evt);
            }
        });
        mnu_thongKe.add(mni_bangDiemKhoaHoc);

        mni_diemTungKhoaHoc.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_3, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mni_diemTungKhoaHoc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/poll.png"))); // NOI18N
        mni_diemTungKhoaHoc.setText("Điểm Từng Khoá Học");
        mni_diemTungKhoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_diemTungKhoaHocActionPerformed(evt);
            }
        });
        mnu_thongKe.add(mni_diemTungKhoaHoc);
        mnu_thongKe.add(jSeparator7);

        mni_doanhThu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_4, java.awt.event.InputEvent.SHIFT_DOWN_MASK));
        mni_doanhThu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/turnover.png"))); // NOI18N
        mni_doanhThu.setText("Doanh Thu Từng Chuyên Đề");
        mni_doanhThu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_doanhThuActionPerformed(evt);
            }
        });
        mnu_thongKe.add(mni_doanhThu);

        jMenuBar1.add(mnu_thongKe);

        mnu_troGiup.setText("Trợ Giúp");

        mni_huongDan.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        mni_huongDan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/user-guide_24.png"))); // NOI18N
        mni_huongDan.setText("Hướng Dẫn Sử Dụng");
        mni_huongDan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_huongDanActionPerformed(evt);
            }
        });
        mnu_troGiup.add(mni_huongDan);
        mnu_troGiup.add(jSeparator8);

        mni_gioiThieu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_1, 0));
        mni_gioiThieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/edu/image/presentation.png"))); // NOI18N
        mni_gioiThieu.setText("Giới Thiệu Sản Phẩm");
        mni_gioiThieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mni_gioiThieuActionPerformed(evt);
            }
        });
        mnu_troGiup.add(mni_gioiThieu);

        jMenuBar1.add(mnu_troGiup);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(pnl_trangThai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lbl_Background, javax.swing.GroupLayout.DEFAULT_SIZE, 701, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbl_Background, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnl_trangThai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void mni_QLNHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_QLNHActionPerformed
        QLNH_Edusys1 v = new QLNH_Edusys1(new javax.swing.JFrame(), true);
        v.setVisible(true);
    }//GEN-LAST:event_mni_QLNHActionPerformed

    private void mni_doanhThuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_doanhThuActionPerformed
        open_Tk(3);
    }//GEN-LAST:event_mni_doanhThuActionPerformed

    private void mni_gioiThieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_gioiThieuActionPerformed
        GioiThieuSanPham gt = new GioiThieuSanPham(new javax.swing.JFrame(), true);
        gt.setVisible(true);

    }//GEN-LAST:event_mni_gioiThieuActionPerformed

    private void mni_dangXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_dangXuatActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất không", "Đăng Xuất", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            dispose();
            Login_Edusys a = new Login_Edusys(new javax.swing.JFrame(), true, false);
            a.setVisible(true);
        } else {
            
        }
    }//GEN-LAST:event_mni_dangXuatActionPerformed

    private void mni_doiMacKhauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_doiMacKhauActionPerformed
        DoiMacKhau_Edusys b = new DoiMacKhau_Edusys(new javax.swing.JFrame(), true);
        b.setVisible(true);
    }//GEN-LAST:event_mni_doiMacKhauActionPerformed

    private void mni_ketThucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_ketThucActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn thoát không", "Thoát", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            System.exit(0);
        } else {
            
        }
    }//GEN-LAST:event_mni_ketThucActionPerformed

    private void mni_QLCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_QLCDActionPerformed
        QLCD_Edusys1 c = new QLCD_Edusys1(new javax.swing.JFrame(), true);
        c.setVisible(true);
    }//GEN-LAST:event_mni_QLCDActionPerformed

    private void mni_QLKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_QLKHActionPerformed
        QLKH_Edusys1 d = new QLKH_Edusys1(new javax.swing.JFrame(), true);
        d.setVisible(true);
    }//GEN-LAST:event_mni_QLKHActionPerformed

    private void mni_QLHVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_QLHVActionPerformed
        QLHV_Edusys1 n = new QLHV_Edusys1(new javax.swing.JFrame(), true);
        n.setVisible(true);
    }//GEN-LAST:event_mni_QLHVActionPerformed

    private void mni_QLNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_QLNVActionPerformed
        QLNV_Edusys nv = new QLNV_Edusys(new javax.swing.JFrame(), true);
        nv.setVisible(true);
    }//GEN-LAST:event_mni_QLNVActionPerformed

    private void btn_dangXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dangXuatActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất không", "Đăng Xuất", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            dispose();
            Login_Edusys a = new Login_Edusys(new javax.swing.JFrame(), true, false);
            a.setVisible(true);
        } else {
            
        }
    }//GEN-LAST:event_btn_dangXuatActionPerformed

    private void mni_nguoiHocTungNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_nguoiHocTungNamActionPerformed
        open_Tk(0);
    }//GEN-LAST:event_mni_nguoiHocTungNamActionPerformed

    private void mni_bangDiemKhoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_bangDiemKhoaHocActionPerformed
        open_Tk(1);
    }//GEN-LAST:event_mni_bangDiemKhoaHocActionPerformed

    private void mni_diemTungKhoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_diemTungKhoaHocActionPerformed
        open_Tk(2);
    }//GEN-LAST:event_mni_diemTungKhoaHocActionPerformed

    private void btn_ketThuc_outActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ketThuc_outActionPerformed
        if (MsgBox.confirm(this, "Bạn có chắc chắn muốn thoát không ?")) {
            System.exit(0);
        }
    }//GEN-LAST:event_btn_ketThuc_outActionPerformed

    private void btn_QLCDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QLCDActionPerformed
        QLCD_Edusys1 c = new QLCD_Edusys1(new javax.swing.JFrame(), true);
        c.setVisible(true);
    }//GEN-LAST:event_btn_QLCDActionPerformed

    private void btn_QLNHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QLNHActionPerformed
        QLNH_Edusys1 v = new QLNH_Edusys1(new javax.swing.JFrame(), true);
        v.setVisible(true);
    }//GEN-LAST:event_btn_QLNHActionPerformed

    private void btn_QLKHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QLKHActionPerformed
        QLKH_Edusys1 d = new QLKH_Edusys1(new javax.swing.JFrame(), true);
        d.setVisible(true);
    }//GEN-LAST:event_btn_QLKHActionPerformed

    private void mni_huongDanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mni_huongDanActionPerformed
        openHuongDan();
    }//GEN-LAST:event_mni_huongDanActionPerformed

    private void btn_huongDanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_huongDanActionPerformed
         openHuongDan();
    }//GEN-LAST:event_btn_huongDanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main_Form.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main_Form().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_QLCD;
    private javax.swing.JButton btn_QLKH;
    private javax.swing.JButton btn_QLNH;
    private javax.swing.JButton btn_dangXuat;
    private javax.swing.JButton btn_huongDan;
    private javax.swing.JButton btn_ketThuc_out;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JToolBar.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JPopupMenu.Separator jSeparator7;
    private javax.swing.JPopupMenu.Separator jSeparator8;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JLabel lbl_Background;
    private javax.swing.JLabel lbl_DongHo;
    private javax.swing.JLabel lbl_maNV;
    private javax.swing.JMenuItem mni_QLCD;
    private javax.swing.JMenuItem mni_QLHV;
    private javax.swing.JMenuItem mni_QLKH;
    private javax.swing.JMenuItem mni_QLNH;
    private javax.swing.JMenuItem mni_QLNV;
    private javax.swing.JMenuItem mni_bangDiemKhoaHoc;
    private javax.swing.JMenuItem mni_dangXuat;
    private javax.swing.JMenuItem mni_diemTungKhoaHoc;
    private javax.swing.JMenuItem mni_doanhThu;
    private javax.swing.JMenuItem mni_doiMacKhau;
    private javax.swing.JMenuItem mni_gioiThieu;
    private javax.swing.JMenuItem mni_huongDan;
    private javax.swing.JMenuItem mni_ketThuc;
    private javax.swing.JMenuItem mni_nguoiHocTungNam;
    private javax.swing.JMenu mnu_heThong;
    private javax.swing.JMenu mnu_quanLy;
    private javax.swing.JMenu mnu_thongKe;
    private javax.swing.JMenu mnu_troGiup;
    private javax.swing.JPanel pnl_trangThai;
    // End of variables declaration//GEN-END:variables
}
