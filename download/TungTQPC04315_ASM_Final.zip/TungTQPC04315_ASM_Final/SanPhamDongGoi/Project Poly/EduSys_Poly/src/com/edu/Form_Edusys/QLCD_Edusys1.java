/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.edu.Form_Edusys;

import com.edu.Class_Edusys.Icon_Logo_FPT;
import com.edu.Edusys_Dao.ChuyenDe_Dao;
import com.edu.Entity.ChuyenDe;
import com.edu.utils.Auth;
import com.edu.utils.MsgBox;
import com.edu.utils.XImage;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QLCD_Edusys1 extends javax.swing.JDialog {

    ChuyenDe_Dao dao = new ChuyenDe_Dao();
    int index = -1;

    /**
     * Creates new form QLNV_Edusys
     */
    public QLCD_Edusys1(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        this.setIconImage(Icon_Logo_FPT.getImg());
        init();
    }

    public void init() {
        fill_TBL();
        index = -1;
        capnhap_CacNut();
    }

    public void fill_TBL() {
        DefaultTableModel model = (DefaultTableModel) tbl_QLCD.getModel();
        model.setRowCount(0);
        try {
            List<ChuyenDe> list = dao.selectALL();
            for (ChuyenDe cd : list) {
                Object[] row = {cd.getMaCD(), cd.getTenCD(),
                    cd.getHocPhi(), cd.getThoiLuong(), cd.getHinh()};
                model.addRow(row);
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Lỗi truy vấn dữ liệu");
        }
    }

    public void set_Form(ChuyenDe cd) {
        txt_maCD.setText(cd.getMaCD());
        txt_tenCD.setText(cd.getTenCD());
        txt_thoiLuong.setText(String.valueOf(cd.getThoiLuong()));
        txt_hocPhi.setText(String.valueOf(cd.getHocPhi()));
        txt_ghiChu.setText(cd.getMoTa());
        if (cd.getHinh() != null) {
            lbl_hinhAnh.setToolTipText(cd.getHinh());
            lbl_hinhAnh.setIcon(XImage.read(cd.getHinh()));
        } else {
            lbl_hinhAnh.setIcon(null);
        }
    }

    public ChuyenDe get_Form() {
        ChuyenDe cd = new ChuyenDe();
        cd.setMaCD(txt_maCD.getText());
        cd.setTenCD(txt_tenCD.getText());
        cd.setThoiLuong(Integer.parseInt(txt_thoiLuong.getText()));
        cd.setHocPhi(Double.parseDouble(txt_hocPhi.getText()));
        cd.setMoTa(txt_ghiChu.getText());
        cd.setHinh(lbl_hinhAnh.getToolTipText());
        return cd;
    }

    public void lamMoi_Form() {
        ChuyenDe cd = new ChuyenDe();
        set_Form(cd);
        index = -1;
        capnhap_CacNut();
    }

    public void them_CD() {
        ChuyenDe cd = get_Form();
        try {
            dao.insert(cd);
            fill_TBL();
            lamMoi_Form();
            MsgBox.alert(this, "Thêm chuyên đề thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Thêm chuyên đề thất bại");
        }
    }

    public void sua_CD() {
        ChuyenDe cd = get_Form();
        try {
            dao.update(cd);
            fill_TBL();

            MsgBox.alert(this, "Cập Nhật chuyên đề thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Cập Nhật chuyên đề thất bại");
        }

    }

    public void xoa_CD() {
        String maCD = txt_maCD.getText();
        try {
            if (MsgBox.confirm(this, "Bạn có chắc chắn muốn xoá chuyên đề này không ?")) {
                dao.delete(maCD);
                fill_TBL();
                lamMoi_Form();
                MsgBox.alert(this, "Xoá chuyên đề thành công");
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Xoá chuyên đề thất bại");
        }
    }

    public boolean check_input() {

        if (txt_maCD.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống mã chuyên đề");
            txt_maCD.requestFocus();
            return false;
        }
        if (txt_tenCD.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống tên chuyên đề");
            txt_tenCD.requestFocus();
            return false;
        }
        if (txt_thoiLuong.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống thời lượng");
            txt_thoiLuong.requestFocus();
            return false;
        }
        if (txt_hocPhi.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống học phí");
            txt_hocPhi.requestFocus();
            return false;
        }
        if (txt_ghiChu.getText().equalsIgnoreCase("")) {
            MsgBox.alert(this, "Không để trống mô tả");
            txt_ghiChu.requestFocus();
            return false;
        }

        if (txt_maCD.getText().length() > 5 || txt_maCD.getText().length() < 5) {
            MsgBox.alert(this, "Mã chuyên đề không được ít hơn hay nhiều hơn 5 ký tự");
            txt_maCD.requestFocus();
            return false;
        }
        try {
            int thoiLuong = Integer.parseInt(txt_thoiLuong.getText());
            if (thoiLuong < 0) {
                MsgBox.alert(this, "Thời lượng không được phép âm");
                txt_thoiLuong.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Không được phép nhập chữ");
            txt_thoiLuong.requestFocus();
            return false;
        }
        try {
            double hcPhi = Double.parseDouble(txt_hocPhi.getText());
            if (hcPhi < 0) {
                MsgBox.alert(this, "Học phí không được phép âm");
                txt_hocPhi.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Không được phép nhập chữ");
            txt_hocPhi.requestFocus();
            return false;
        }
        if(lbl_hinhAnh.getIcon() == null){
            MsgBox.alert(this, "Bạn chưa chọn ảnh");
            return false;
        }
        return true;
    }

    boolean maTrung() {
        boolean kq;
        List<ChuyenDe> list = dao.selectALL();
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaCD().equalsIgnoreCase(txt_maCD.getText());
            if (kq == true) {
                MsgBox.alert(this, "Không được phép trùng mã chuyên đề");
                return false;
            }
        }
        return true;
    }

    public void edit_TBL() {
        String maCD = (String) tbl_QLCD.getValueAt(index, 0);
        ChuyenDe cd = dao.select_ById(maCD);
        set_Form(cd);
        tabs_big.setSelectedIndex(1);
        capnhap_CacNut();
    }

    public void capnhap_CacNut() {
        boolean edit = (index >= 0);
        boolean first = (index == 0);
        boolean last = (index == tbl_QLCD.getRowCount() - 1);
        // trạng thái form 
        txt_maCD.setEditable(!edit);
        btn_them.setEnabled(!edit);
        btn_sua.setEnabled(edit);
        btn_xoa.setEnabled(edit);

        // trạng thái điều hướng
        btn_dauTien.setEnabled(edit && !first);
        btn_Sau.setEnabled(edit && !first);
        btn_Truoc.setEnabled(edit && !last);
        btn_cuoiCung.setEnabled(edit && !last);
    }

    public void First() {
        index = 0;
        edit_TBL();
    }

    public void Prev() {
        if (index > 0) {
            index--;
            edit_TBL();
        }
    }

    public void Next() {
        if (index < tbl_QLCD.getRowCount() - 1) {
            index++;
            edit_TBL();
        }
    }

    public void Last() {
        index = tbl_QLCD.getRowCount() - 1;
        edit_TBL();
    }

    public void chonAnh() {
        JFileChooser fileChooser = new JFileChooser();

        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File f = fileChooser.getSelectedFile();
            XImage.save(f); // lưu hình vào thư mục logos 
            ImageIcon icon = XImage.read(f.getName()); // đọc hình từ thư mục logos 
            lbl_hinhAnh.setIcon(icon);
            lbl_hinhAnh.setToolTipText(f.getName());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        tabs_big = new javax.swing.JTabbedPane();
        pnl_list = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLCD = new javax.swing.JTable();
        pnl_edit = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_maCD = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_hocPhi = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        btn_sua = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        btn_them = new javax.swing.JButton();
        btn_moi = new javax.swing.JButton();
        btn_dauTien = new javax.swing.JButton();
        btn_Sau = new javax.swing.JButton();
        btn_Truoc = new javax.swing.JButton();
        btn_cuoiCung = new javax.swing.JButton();
        lbl_hinhAnh = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txt_ghiChu = new javax.swing.JTextArea();
        txt_tenCD = new javax.swing.JTextField();
        txt_thoiLuong = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("                                                                  Quản Lý Chuyên Đề\n");

        tbl_QLCD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Mã Chuyên Đề", "Tên Chuyên Đề", "Học Phí", "Thời Lượng", "Ảnh"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_QLCD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLCDMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLCD);

        javax.swing.GroupLayout pnl_listLayout = new javax.swing.GroupLayout(pnl_list);
        pnl_list.setLayout(pnl_listLayout);
        pnl_listLayout.setHorizontalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
        );
        pnl_listLayout.setVerticalGroup(
            pnl_listLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_listLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        tabs_big.addTab("Danh Sách", pnl_list);

        pnl_edit.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Mã Chuyên Đề");

        txt_maCD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_maCDKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Tên Chuyên Đề");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Thời Lượng (Giờ)");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Học Phí");

        txt_hocPhi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_hocPhiKeyPressed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Mô Tả Chuyên Đề");

        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_xoa.setText("Xoá");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_moi.setText("Mới");
        btn_moi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moiActionPerformed(evt);
            }
        });

        btn_dauTien.setText("|<");
        btn_dauTien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_dauTienActionPerformed(evt);
            }
        });

        btn_Sau.setText("<<");
        btn_Sau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SauActionPerformed(evt);
            }
        });

        btn_Truoc.setText(">>");
        btn_Truoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TruocActionPerformed(evt);
            }
        });

        btn_cuoiCung.setText(">|");
        btn_cuoiCung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cuoiCungActionPerformed(evt);
            }
        });

        lbl_hinhAnh.setText("Ảnh");
        lbl_hinhAnh.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lbl_hinhAnh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_hinhAnhMouseClicked(evt);
            }
        });

        txt_ghiChu.setColumns(20);
        txt_ghiChu.setRows(5);
        txt_ghiChu.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_ghiChuKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(txt_ghiChu);

        txt_tenCD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_tenCDKeyPressed(evt);
            }
        });

        txt_thoiLuong.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_thoiLuongKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout pnl_editLayout = new javax.swing.GroupLayout(pnl_edit);
        pnl_edit.setLayout(pnl_editLayout);
        pnl_editLayout.setHorizontalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(pnl_editLayout.createSequentialGroup()
                                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(pnl_editLayout.createSequentialGroup()
                                        .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pnl_editLayout.createSequentialGroup()
                                        .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_moi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(62, 62, 62)
                                .addComponent(btn_dauTien, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_Sau, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_Truoc, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_cuoiCung, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_editLayout.createSequentialGroup()
                                .addComponent(lbl_hinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_maCD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 340, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_hocPhi, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_tenCD)
                                    .addComponent(txt_thoiLuong)))
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        pnl_editLayout.setVerticalGroup(
            pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_editLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_maCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_tenCD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(txt_thoiLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(txt_hocPhi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnl_editLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(lbl_hinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_moi))
                .addGap(18, 18, 18)
                .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_dauTien)
                        .addComponent(btn_Sau)
                        .addComponent(btn_Truoc)
                        .addComponent(btn_cuoiCung))
                    .addGroup(pnl_editLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btn_sua)
                        .addComponent(btn_xoa)))
                .addContainerGap())
        );

        tabs_big.addTab("Câp Nhật", pnl_edit);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setText("Quản Lý Chuyên Đề");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs_big)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tabs_big))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lbl_hinhAnhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_hinhAnhMouseClicked
        chonAnh();
    }//GEN-LAST:event_lbl_hinhAnhMouseClicked

    private void btn_moiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moiActionPerformed
        lamMoi_Form();
    }//GEN-LAST:event_btn_moiActionPerformed

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        if (check_input()) {
            if (maTrung()) {
                them_CD();
            }
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void tbl_QLCDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLCDMouseClicked
        if (evt.getClickCount() == 2) {
            index = tbl_QLCD.getSelectedRow();
            edit_TBL();
        }
    }//GEN-LAST:event_tbl_QLCDMouseClicked

    private void btn_dauTienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_dauTienActionPerformed
        First();
    }//GEN-LAST:event_btn_dauTienActionPerformed

    private void btn_SauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SauActionPerformed
        Prev();
    }//GEN-LAST:event_btn_SauActionPerformed

    private void btn_TruocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TruocActionPerformed
        Next();
    }//GEN-LAST:event_btn_TruocActionPerformed

    private void btn_cuoiCungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cuoiCungActionPerformed
        Last();
    }//GEN-LAST:event_btn_cuoiCungActionPerformed

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        if (check_input()) {
            sua_CD();
        }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        if (check_input()) {
            xoa_CD();
        }
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void txt_maCDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_maCDKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_maCDKeyPressed

    private void txt_tenCDKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_tenCDKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_tenCDKeyPressed

    private void txt_thoiLuongKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_thoiLuongKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_thoiLuongKeyPressed

    private void txt_hocPhiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_hocPhiKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_hocPhiKeyPressed

    private void txt_ghiChuKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_ghiChuKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            check_input();
        }
    }//GEN-LAST:event_txt_ghiChuKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLCD_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLCD_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLCD_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLCD_Edusys1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QLCD_Edusys1 dialog = new QLCD_Edusys1(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Sau;
    private javax.swing.JButton btn_Truoc;
    private javax.swing.JButton btn_cuoiCung;
    private javax.swing.JButton btn_dauTien;
    private javax.swing.JButton btn_moi;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbl_hinhAnh;
    private javax.swing.JPanel pnl_edit;
    private javax.swing.JPanel pnl_list;
    private javax.swing.JTabbedPane tabs_big;
    private javax.swing.JTable tbl_QLCD;
    private javax.swing.JTextArea txt_ghiChu;
    private javax.swing.JTextField txt_hocPhi;
    private javax.swing.JTextField txt_maCD;
    private javax.swing.JTextField txt_tenCD;
    private javax.swing.JTextField txt_thoiLuong;
    // End of variables declaration//GEN-END:variables
}
