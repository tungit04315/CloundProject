/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;

/**
 *
 * @author tungt
 */
public class QL_LuongNhanVien {
   private int Thang, NgayLamViec;
   private String MaLuong,MaNV;
   private float GioLamViec, TienThuong,TienPhuCap,TienUngTruoc,LuongCoDinh;

    public QL_LuongNhanVien() {
    }

    public QL_LuongNhanVien(int Thang, int NgayLamViec, String MaLuong, String MaNV, float GioLamViec, float TienThuong, float TienPhuCap, float TienUngTruoc, float LuongCoDinh) {
        this.Thang = Thang;
        this.NgayLamViec = NgayLamViec;
        this.MaLuong = MaLuong;
        this.MaNV = MaNV;
        this.GioLamViec = GioLamViec;
        this.TienThuong = TienThuong;
        this.TienPhuCap = TienPhuCap;
        this.TienUngTruoc = TienUngTruoc;
        this.LuongCoDinh = LuongCoDinh;
    }

    public int getThang() {
        return Thang;
    }

    public void setThang(int Thang) {
        this.Thang = Thang;
    }

    public int getNgayLamViec() {
        return NgayLamViec;
    }

    public void setNgayLamViec(int NgayLamViec) {
        this.NgayLamViec = NgayLamViec;
    }

    public String getMaLuong() {
        return MaLuong;
    }

    public void setMaLuong(String MaLuong) {
        this.MaLuong = MaLuong;
    }

    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public float getGioLamViec() {
        return GioLamViec;
    }

    public void setGioLamViec(float GioLamViec) {
        this.GioLamViec = GioLamViec;
    }

    public float getTienThuong() {
        return TienThuong;
    }

    public void setTienThuong(float TienThuong) {
        this.TienThuong = TienThuong;
    }

    public float getTienPhuCap() {
        return TienPhuCap;
    }

    public void setTienPhuCap(float TienPhuCap) {
        this.TienPhuCap = TienPhuCap;
    }

    public float getTienUngTruoc() {
        return TienUngTruoc;
    }

    public void setTienUngTruoc(float TienUngTruoc) {
        this.TienUngTruoc = TienUngTruoc;
    }

    public float getLuongCoDinh() {
        return LuongCoDinh;
    }

    public void setLuongCoDinh(float LuongCoDinh) {
        this.LuongCoDinh = LuongCoDinh;
    }
   
   
   
   
}
