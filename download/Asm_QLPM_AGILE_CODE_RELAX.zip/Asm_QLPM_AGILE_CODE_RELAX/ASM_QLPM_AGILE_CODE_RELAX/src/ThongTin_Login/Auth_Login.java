/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;

/**
 *
 * @author tungt
 */
public class Auth_Login {
    public static Login_UserName userName = null;
    
    public static void clean(){
        Auth_Login.userName = null;
    }
    
    public static boolean isLogin(){
        return Auth_Login.userName != null;
    }
    
//    public static boolean isManger(){
//        return Auth_Login.isLogin() && userName.getRole();
//    }
}
