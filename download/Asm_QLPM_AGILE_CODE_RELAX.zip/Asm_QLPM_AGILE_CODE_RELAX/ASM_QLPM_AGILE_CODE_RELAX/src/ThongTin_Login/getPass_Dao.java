/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;




/**
 *
 * @author tungt
 */
public class getPass_Dao {
     public boolean checkUser(String username, String email) throws Exception {
        try {
            String sql = "SELECT * FROM Login WHERE TenDangNhap = ? and Email = ?";
            Connection conn = database_connection.openConn();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, email);
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
            }
            if (count == 1) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(getPass_Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updatePassword(String username, String email) throws Exception {
        try {
            String sql = "UPDATE Login SET MatKhau = ? WHERE TenDangNhap = ? and Email = ?";
            Connection conn = database_connection.openConn();
            PreparedStatement stmt = conn.prepareStatement(sql);
            String password = new Random_Pass().randomString(6);
            stmt.setString(1, password);
            stmt.setString(2, username);
            stmt.setString(3, email);
            send_Email s = new send_Email();
            s.sendEmail(email, password);
            return stmt.executeUpdate() >0;
        } catch (SQLException ex) {
            Logger.getLogger(getPass_Dao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
