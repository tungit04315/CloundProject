/*
   Lớp User lấy thông tin User
 */
package ThongTin_Login;

/*
    TUNGTQPC 04315
 */
public class Login_UserName {
    private String User, Pass;  // Tên và mặt khẩu đăng nhập 
    private String role;    // vai trò
    private String Email;

    public Login_UserName() {
    }

    public Login_UserName(String User, String Pass, String role,String Email) {
        this.User = User;
        this.Pass = Pass;
        this.role = role;
        this.Email = Email;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getUser() {
        return User;
    }

    public void setUser(String User) {
        this.User = User;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String Pass) {
        this.Pass = Pass;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    
}
