/*
    Phần xem xét đăng nhập login hệ thống
 */
package ThongTin_Login;

import Show_Form.QL_Tai_Khoan;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/*
   TUNGTQPC04315
 */
public class Login_User_Pass {

//    List<Login_UserName> list = new ArrayList<>();
//
//    public Login_User_Pass() {
//        list.add(new Login_UserName("admin", "123", true));
//        list.add(new Login_UserName("Lucas", "041001", true));
//    }
//
//    public boolean kiemUserPass(String user, String pass) {
//        for (Login_UserName a : list) {
//            if (a.getUser().equalsIgnoreCase(user) && a.getPass().equalsIgnoreCase(pass)) {
//                return true;
//            }
//        }
//        return false;
//    }
    public List<Login_UserName> getALL() {
        List<Login_UserName> list = new ArrayList<>();
//        String url = "jdbc:sqlserver://localhost:1433; databaseName=QL_NhaHang; encrypt=true; trustServerCertificate=true";
//        String name = "tung";
//        String passw = "123";
//        String url = "jdbc:sqlserver://localhost:1433" + "databaseName=QL_NhaHang; encrypt=false;";
        String user = "tung";
        String pass = "123";
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "select * from Login";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String TenDangNhap = rs.getString(1);
                String MatKhau = rs.getString(2);
                String VaiTro = rs.getString(3);
                String Email = rs.getString(4);
                list.add(new Login_UserName(TenDangNhap, MatKhau, VaiTro, Email));
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return list;
    }

//    public int Login(String name, String pasw) {
//
//        Login_User_Pass a = new Login_User_Pass();
//
//        for (Login_UserName tk : a.getALL()) {
//            if (tk.getUser().equalsIgnoreCase(name) && tk.getPass().equalsIgnoreCase(pasw)) {
//                if (tk.getRole().equalsIgnoreCase("ADMIN")) {
//                    return 1;
//                } else {
//                    return 2;
//                }
//            }
//        }
//        return 0;
//    }
    public Login_UserName Check_Login(String tenDangNhap, String MatKhau)
            throws Exception {
        String sql = "select TenDangNhap, MatKhau , VaiTro from Login"
                + " where TenDangNhap = ? and MatKhau = ?";
        try (
                 Connection con = database_connection.openConn();  PreparedStatement ps = con.prepareStatement(sql);) {
            ps.setString(1, tenDangNhap);
            ps.setString(2, MatKhau);

            try ( ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    Login_UserName lg = new Login_UserName();
                    lg.setUser(tenDangNhap);
                    lg.setRole(rs.getString("VaiTro"));
                    return lg;
                }
            }
        }
        return null;
    }
    
     public String Check(String tenDangNhap, String MatKhau)
            throws Exception {
        String sql = "select TenDangNhap, MatKhau , VaiTro from Login"
                + " where TenDangNhap = ? and MatKhau = ?";
        try (
                 Connection con = database_connection.openConn();  PreparedStatement ps = con.prepareStatement(sql);) {
            ps.setString(1, tenDangNhap);
            ps.setString(2, MatKhau);

            try ( ResultSet rs = ps.executeQuery();) {
                if (rs.next()) {
                    Login_UserName lg = new Login_UserName();
                    lg.setUser(tenDangNhap);
                    lg.setRole(rs.getString("VaiTro"));
                    return lg.getRole();
                }
            }
        }
        return null;
    }
}
