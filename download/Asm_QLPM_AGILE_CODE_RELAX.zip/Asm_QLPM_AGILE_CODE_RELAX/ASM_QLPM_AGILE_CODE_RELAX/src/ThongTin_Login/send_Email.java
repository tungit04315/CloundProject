/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;

import jakarta.activation.DataHandler;
import jakarta.activation.FileDataSource;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeBodyPart;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.internet.MimeMultipart;
import java.util.Properties;
import javax.swing.JOptionPane;
/**
 *
 * @author tungt
 */
//String username = "letung546546@gmail.com";
//String password = "oaarspyxxjvlhgwt";

public class send_Email {

    String emailSubject = "Lấy Mật Khẩu";

    public void sendEmail(String emailToAddress, String textMessage) {
         try {

                Properties p = new Properties();
                p.put("mail.smtp.auth", "true");
                p.put("mail.smtp.starttls.enable", "true");
                p.put("mail.smtp.host", "smtp.gmail.com");
                p.put("mail.smtp.ssl.trust", "smtp.gmail.com");
                p.put("mail.smtp.port", 587);
//mật khẩu : wtvjwnaxjldvrzym  tài khoản gmail : tungto753@gmail.com
                String user = "tungto753@gmail.com";
                String pas = "wtvjwnaxjldvrzym";

                Session s = Session.getInstance(p,
                        new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(user, pas);
                    }
                });
                Message msg = new MimeMessage(s);
                msg.setFrom(new InternetAddress(user));
                msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailToAddress));

                msg.setSubject(emailSubject);
//                msg.setText(textMessage);
                msg.setContent("Mật Khẩu Đăng Nhập Hệ Thống Quản Lý Nhà Hàng Là : " + textMessage, "text/html; charset=utf-8");
              
                Transport.send(msg);
                JOptionPane.showMessageDialog(null, "Gửi Thành Công Đến Email " + emailToAddress, emailToAddress, javax.swing.JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
                System.out.println(e);
            }

    }
}
