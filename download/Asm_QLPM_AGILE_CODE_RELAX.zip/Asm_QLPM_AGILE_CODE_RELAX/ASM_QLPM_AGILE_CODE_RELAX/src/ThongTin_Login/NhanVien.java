/*
    Biến Nhân viên
 */
package ThongTin_Login;

/*
 TUNGTQPC04315
 */
public class NhanVien {
    private String MaNV,TenNV,VaiTro,ViTri;
    private String sdt;
    private String GioiTinh,HinhAnh;

    public String getHinhAnh() {
        return HinhAnh;
    }

    public void setHinhAnh(String HinhAnh) {
        this.HinhAnh = HinhAnh;
    }

    public NhanVien(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }

    public NhanVien() {
    }

    public NhanVien(String MaNV, String TenNV, String VaiTro, String ViTri, String GioiTinh,String sdt,String HinhAnh) {
        this.MaNV = MaNV;
        this.TenNV = TenNV;
        this.VaiTro = VaiTro;
         this.GioiTinh = GioiTinh;
        this.ViTri = ViTri;
        this.sdt = sdt;
        this.HinhAnh = HinhAnh;
    }
    public String getGioiTinh() {
        return GioiTinh;
    }

    public void setGioiTinh(String GioiTinh) {
        this.GioiTinh = GioiTinh;
    }
    public String getMaNV() {
        return MaNV;
    }

    public void setMaNV(String MaNV) {
        this.MaNV = MaNV;
    }

    public String getTenNV() {
        return TenNV;
    }

    public void setTenNV(String TenNV) {
        this.TenNV = TenNV;
    }

    public String getVaiTro() {
        return VaiTro;
    }

    public void setVaiTro(String VaiTro) {
        this.VaiTro = VaiTro;
    }

   

    public String getViTri() {
        return ViTri;
    }

    public void setViTri(String ViTri) {
        this.ViTri = ViTri;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }
    
    
}
