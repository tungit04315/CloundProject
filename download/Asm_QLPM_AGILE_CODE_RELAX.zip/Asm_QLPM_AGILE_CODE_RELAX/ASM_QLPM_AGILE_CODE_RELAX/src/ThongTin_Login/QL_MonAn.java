/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;

/**
 *
 * @author tungt
 */
public class QL_MonAn {
    private String MaMon,TenMon;
    
    private double donGia;

    public QL_MonAn() {
    }

    public QL_MonAn(String MaMon, String TenMon, double donGia) {
        this.MaMon = MaMon;
        this.TenMon = TenMon;
       
        this.donGia = donGia;
    }

    public String getMaMon() {
        return MaMon;
    }

    public void setMaMon(String MaMon) {
        this.MaMon = MaMon;
    }

    public String getTenMon() {
        return TenMon;
    }

    public void setTenMon(String TenMon) {
        this.TenMon = TenMon;
    }

   
    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }
    
    
}
