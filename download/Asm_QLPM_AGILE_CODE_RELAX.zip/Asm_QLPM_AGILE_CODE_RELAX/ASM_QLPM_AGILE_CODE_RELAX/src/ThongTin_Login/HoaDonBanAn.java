/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThongTin_Login;

/**
 *
 * @author tungt
 */
public class HoaDonBanAn {
    String MaHoaDon, TenBan,MaMon,ThoiGian;
    int SoLuong;
    double donGia,TongTien;

    public HoaDonBanAn(String MaHoaDon, String TenBan, String MaMon, String ThoiGian, int SoLuong, double donGia, double TongTien) {
        this.MaHoaDon = MaHoaDon;
        this.TenBan = TenBan;
        this.MaMon = MaMon;
        this.ThoiGian = ThoiGian;
        this.SoLuong = SoLuong;
        this.donGia = donGia;
        this.TongTien = TongTien;
    }

    public HoaDonBanAn() {
    }

    public String getMaHoaDon() {
        return MaHoaDon;
    }

    public void setMaHoaDon(String MaHoaDon) {
        this.MaHoaDon = MaHoaDon;
    }

    public String getTenBan() {
        return TenBan;
    }

    public void setTenBan(String TenBan) {
        this.TenBan = TenBan;
    }

    public String getMaMon() {
        return MaMon;
    }

    public void setMaMon(String MaMon) {
        this.MaMon = MaMon;
    }

    public String getThoiGian() {
        return ThoiGian;
    }

    public void setThoiGian(String ThoiGian) {
        this.ThoiGian = ThoiGian;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double getTongTien() {
        return TongTien;
    }

    public void setTongTien(double TongTien) {
        this.TongTien = TongTien;
    }
    
    
}
