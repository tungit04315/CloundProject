/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Show_Form;

import ThongTin_Login.QL_LuongNhanVien;
import ThongTin_Login.QL_MonAn;
import java.awt.HeadlessException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QL_Menu_NhaHang extends javax.swing.JDialog {

    DefaultTableModel model;
    List<QL_MonAn> list = new ArrayList<>();
    String user = "tung";
    String pass = "123";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

    public QL_Menu_NhaHang(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        Load_Data();
        Open_DATA();
        Nut_Dong_PhanMem();
    }

    private void Nut_Dong_PhanMem() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
                int kq = JOptionPane.showConfirmDialog(e.getWindow(), "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
                if (kq == JOptionPane.YES_OPTION) {
                    DiaChi_Luu_DL();
                    dispose();
                } else {
                    dispose();
                }

            }
        });
    }

    public void DiaChi_Luu_DL() throws HeadlessException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
//                    fileChooser.setFileFilter(new FileTypeFilter(".txt", "Text File"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            Save_File(fileToSave.getAbsolutePath());
        }
    }

    public void Save_File(String s) {
        try {
            FileWriter myWriter = new FileWriter(s);
//            myWriter.write();
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }
    }

    public void Load_Data() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "Select * from Menu";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String maMon = rs.getString(1);
                String tenMon = rs.getString(2);

                double donGia = rs.getFloat(3);

                QL_MonAn m = new QL_MonAn(maMon, tenMon, donGia);
                list.add(m);
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Open_DATA() {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("Select * from Menu");

            ResultSet rs = (ResultSet) ps.executeQuery();
            model = (DefaultTableModel) tbl_Mon.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("MaMon"));
                v.add(rs.getString("TenMon"));
                v.add(rs.getString("DonGia"));
                model.addRow(v);
            }

            tbl_Mon.setModel(model);
            ct.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public boolean kiemTraMaTrung() {
        boolean kq;
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaMon().contains(txt_MaMon.getText());
            if (kq == true) {
                JOptionPane.showMessageDialog(this, "Do not duplicate dish code");
                return true;
            }
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Mon = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_MaMon = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_TenMon = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_DonGia = new javax.swing.JTextField();
        btn_SX_Ma = new javax.swing.JButton();
        btn_SX_Gia = new javax.swing.JButton();
        btn_them = new javax.swing.JButton();
        btn_Luu = new javax.swing.JButton();
        btn_CapNhat = new javax.swing.JButton();
        btn_Xoa = new javax.swing.JButton();
        btn_Thoat = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txt_TimKiem = new javax.swing.JTextField();
        btn_TimKiem = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản Lý Nhà Hàng");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Quản Lý Menu");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(198, 11, 145, -1));

        tbl_Mon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Mã Món", "Tên Món", "Đơn Giá"
            }
        ));
        tbl_Mon.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbl_Mon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_MonMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_Mon);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 562, 110));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Mã Món");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 60, -1));
        getContentPane().add(txt_MaMon, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 57, 332, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tên Món");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 60, -1));
        getContentPane().add(txt_TenMon, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 109, 332, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Đơn Giá");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 169, 60, -1));
        getContentPane().add(txt_DonGia, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 167, 332, -1));

        btn_SX_Ma.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/filter_Sort.png"))); // NOI18N
        btn_SX_Ma.setText("Sắp Xếp Theo Mã");
        btn_SX_Ma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SX_MaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_SX_Ma, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 329, -1, -1));

        btn_SX_Gia.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/filter_Sort.png"))); // NOI18N
        btn_SX_Gia.setText("Sắp Xếp Theo Giá");
        btn_SX_Gia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SX_GiaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_SX_Gia, new org.netbeans.lib.awtextra.AbsoluteConstraints(284, 329, -1, -1));

        btn_them.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new-document.png"))); // NOI18N
        btn_them.setText("Thêm ");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });
        getContentPane().add(btn_them, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 51, 105, -1));

        btn_Luu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        btn_Luu.setText("Lưu");
        btn_Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LuuActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Luu, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 103, 105, -1));

        btn_CapNhat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        btn_CapNhat.setText("Cập Nhật");
        btn_CapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CapNhatActionPerformed(evt);
            }
        });
        getContentPane().add(btn_CapNhat, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 162, -1, -1));

        btn_Xoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        btn_Xoa.setText("Xoá ");
        btn_Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_XoaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Xoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 211, 105, -1));

        btn_Thoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/power-off.png"))); // NOI18N
        btn_Thoat.setText("Thoát");
        btn_Thoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThoatActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Thoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 275, 105, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("Tìm Kiếm");

        btn_TimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_TimKiem.setText("Tìm Kiếm");
        btn_TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(0, 273, Short.MAX_VALUE)
                        .addComponent(btn_TimKiem))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_TimKiem)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_TimKiem)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 400, 90));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/back_QLMenu.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 510));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void hienLenForm(int index) {
        txt_MaMon.setText(list.get(index).getMaMon());
        txt_TenMon.setText(list.get(index).getTenMon());
        txt_DonGia.setText(String.valueOf(list.get(index).getDonGia()));
    }

    private void tbl_MonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_MonMouseClicked
        int index = tbl_Mon.getSelectedRow();
        hienLenForm(index);
        txt_MaMon.setEnabled(false);
    }//GEN-LAST:event_tbl_MonMouseClicked

    public void SapXepTheoMa() {

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM Menu\n"
                    + "ORDER BY MaMon DESC;";
            PreparedStatement st = ct.prepareStatement(sql);
//            st.setString(1, txt_MaMon.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_Mon.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("MaMon"));
                v.add(rs.getString("TenMon"));
                v.add(rs.getString("DonGia"));
                model.addRow(v);
            }

            tbl_Mon.setModel(model);
//            Open_DATA();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

    }

    private void btn_SX_MaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SX_MaActionPerformed

        SapXepTheoMa();

    }//GEN-LAST:event_btn_SX_MaActionPerformed

    public void SapXepTheoGia() {

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM Menu\n"
                    + "ORDER BY DonGia asc;";
            PreparedStatement st = ct.prepareStatement(sql);
//            st.setString(1, txt_MaMon.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_Mon.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("MaMon"));
                v.add(rs.getString("TenMon"));
                v.add(rs.getString("DonGia"));
                model.addRow(v);
            }

            tbl_Mon.setModel(model);
//            Open_DATA();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

    }

    private void btn_SX_GiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SX_GiaActionPerformed
        SapXepTheoGia();
    }//GEN-LAST:event_btn_SX_GiaActionPerformed

    private void btn_ThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThoatActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to escape ?", "Exit program", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            this.dispose();
        }
    }//GEN-LAST:event_btn_ThoatActionPerformed

    public void timKiem_Mon() {
        if (txt_TimKiem.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the search box empty ?");
            txt_TimKiem.requestFocus();
            return;
        }
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "select * from Menu where MaMon = ?";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_TimKiem.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_Mon.getModel();
            model.setRowCount(0);
            for (QL_MonAn sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("MaMon"));
                    v.add(rs.getString("TenMon"));
                    v.add(rs.getString("DonGia"));
                    model.addRow(v);
                }
            }
            tbl_Mon.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Them_Moi() {
        txt_MaMon.setText("");
        txt_TenMon.setText("");
        txt_DonGia.setText("");
        txt_MaMon.requestFocus();
        txt_MaMon.setEnabled(true);
    }

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        Them_Moi();
    }//GEN-LAST:event_btn_themActionPerformed

    public QL_MonAn read() {
        QL_MonAn mon = new QL_MonAn();
        mon.setMaMon(txt_MaMon.getText());
        mon.setTenMon(txt_TenMon.getText());
        mon.setDonGia(Double.parseDouble(txt_DonGia.getText()));
        return mon;
    }

    public void Luu_Mon(QL_MonAn mon) {
        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "insert into Menu values (?,?,?)";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_MaMon.getText());
            st.setString(2, txt_TenMon.getText());
            st.setString(3, txt_DonGia.getText());
            st.executeUpdate();
            JOptionPane.showMessageDialog(this, "More dish success");
            ct.close();
            Load_Data();
            Open_DATA();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public boolean check_Input() {
        if (txt_MaMon.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the item code blank");
            txt_MaMon.requestFocus();
            return false;
        }
        if (txt_TenMon.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the item name blank");
            txt_TenMon.requestFocus();
            return false;
        }
        if (txt_DonGia.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the price of the item blank");
            txt_DonGia.requestFocus();
            return false;
        }
        return true;
    }
    private void btn_LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LuuActionPerformed
        try {
            if (check_Input()) {
                Luu_Mon(read());
            }
        } catch (java.lang.NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Do not enter the wrong information format");
            txt_DonGia.requestFocus();
        }

    }//GEN-LAST:event_btn_LuuActionPerformed

    public void Xoa_Mon() {
        if (txt_MaMon.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave dish code blank");
            txt_MaMon.requestFocus();
            return;
        }
        try {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ?", "Delete dish", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                int row = 0;
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "delete from Menu where MaMon = ?";
                PreparedStatement st = ct.prepareStatement(sql);
                st.setString(1, txt_MaMon.getText());
                st.executeUpdate();
                if (row >= 0) {
                    JOptionPane.showMessageDialog(this, "Delete Staff Successful");
                } else {
                    JOptionPane.showMessageDialog(this, "Delete Staff Unsuccessful");
                }
                ct.close();
                Load_Data();
                Open_DATA();
                Them_Moi();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_XoaActionPerformed
        Xoa_Mon();
    }//GEN-LAST:event_btn_XoaActionPerformed

    public void CapNhat_Mon(QL_MonAn mon) {

        try {

            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to update again ?", "Update dish information", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "Update Menu set TenMon = ? , DonGia = ? where MaMon = ?";
                PreparedStatement st = ct.prepareStatement(sql);

                st.setString(1, mon.getTenMon());
                st.setDouble(2, mon.getDonGia());
                st.setString(3, mon.getMaMon());

                st.executeUpdate();
                JOptionPane.showMessageDialog(this, "Update Successful");
                ct.close();
                Load_Data();
                Open_DATA();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }


    private void btn_CapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CapNhatActionPerformed
        try {
            if (check_Input()) {
                CapNhat_Mon(read());
            }
        } catch (java.lang.NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Do not enter the wrong information format");
            txt_DonGia.requestFocus();
        }
    }//GEN-LAST:event_btn_CapNhatActionPerformed

    private void btn_TimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TimKiemActionPerformed
        if (txt_TimKiem.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter the code of the dish you want to find");
            Open_DATA();
        } else
            timKiem_Mon();
    }//GEN-LAST:event_btn_TimKiemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QL_Menu_NhaHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QL_Menu_NhaHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QL_Menu_NhaHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QL_Menu_NhaHang.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QL_Menu_NhaHang dialog = new QL_Menu_NhaHang(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_CapNhat;
    private javax.swing.JButton btn_Luu;
    private javax.swing.JButton btn_SX_Gia;
    private javax.swing.JButton btn_SX_Ma;
    private javax.swing.JButton btn_Thoat;
    private javax.swing.JButton btn_TimKiem;
    private javax.swing.JButton btn_Xoa;
    private javax.swing.JButton btn_them;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_Mon;
    private javax.swing.JTextField txt_DonGia;
    private javax.swing.JTextField txt_MaMon;
    private javax.swing.JTextField txt_TenMon;
    private javax.swing.JTextField txt_TimKiem;
    // End of variables declaration//GEN-END:variables
}
