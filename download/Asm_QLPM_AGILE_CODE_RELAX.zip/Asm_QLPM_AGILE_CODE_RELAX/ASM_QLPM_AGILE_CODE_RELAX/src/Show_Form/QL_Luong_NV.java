/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Show_Form;

import ThongTin_Login.NhanVien;
import ThongTin_Login.QL_LuongNhanVien;
import java.awt.HeadlessException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QL_Luong_NV extends javax.swing.JDialog {

    DefaultTableModel model;
    List<QL_LuongNhanVien> list = new ArrayList<>();
    String user = "tung";
    String pass = "123";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

    public QL_Luong_NV(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

        String Cot[] = {"Tháng Lãnh Lương", "Mã Lương", "Mã Nhân Viên", "Số Ngày Làm", "Số Giờ Làm Việc", "Tiền Thưởng", "Tiền Phụ Cấp", "Tiền Ứng Trước", "Lương Cứng"};

        model = new DefaultTableModel(null, Cot);
        tbl_QLLuong_NV.setModel(model);

        Load_Data();
        Open_DATA();
        Load_Data_cbo();
        Nut_Dong_PhanMem();

    }

    private void Nut_Dong_PhanMem() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
                int kq = JOptionPane.showConfirmDialog(e.getWindow(), "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
                if (kq == JOptionPane.YES_OPTION) {
                    DiaChi_Luu_DL();
                    dispose();
                } else {
                    dispose();
                }

            }
        });
    }

    public void DiaChi_Luu_DL() throws HeadlessException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
//                    fileChooser.setFileFilter(new FileTypeFilter(".txt", "Text File"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            Save_File(fileToSave.getAbsolutePath());
        }
    }

    public void Save_File(String s) {
        try {
            FileWriter myWriter = new FileWriter(s);
//            myWriter.write();
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }
    }

    public void Load_Data_cbo() {
        try {
            String user = "tung";
            String pass = "123";
            String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "select MaNV from NhanVien";
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String s = rs.getString(1);
                cbo_Ma_NV.addItem(s);
            }

            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Load_Data() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "Select * from Luong_NhanVien";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                int Thang = rs.getInt(1);
                String maLuong = rs.getString(2);
                String maNV = rs.getString(3);
                int ngayLamViec = rs.getInt(4);
                float soGioLam = rs.getFloat(5);
                float tienThuong = rs.getFloat(6);
                float phuCap = rs.getFloat(7);
                float tienUng = rs.getFloat(8);
                float luongCung = rs.getFloat(9);
                QL_LuongNhanVien nv = new QL_LuongNhanVien(Thang, ngayLamViec, maLuong, maNV, soGioLam, tienThuong, phuCap, tienUng, luongCung);
                list.add(nv);
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Open_DATA() {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("Select * from Luong_NhanVien");

            ResultSet rs = (ResultSet) ps.executeQuery();
            model = (DefaultTableModel) tbl_QLLuong_NV.getModel();
            model.setRowCount(0);
            for (QL_LuongNhanVien sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("Thang"));
                    v.add(rs.getString("MaLuong"));
                    v.add(rs.getString("MaNV"));
                    v.add(rs.getString("SoNgayLamViec"));
                    v.add(rs.getString("SoGioLamThem"));
                    v.add(rs.getString("TienThuong"));
                    v.add(rs.getString("TienPhuCap"));
                    v.add(rs.getString("TienUngTruoc"));
                    v.add(rs.getString("LuongCung"));
                    model.addRow(v);
                }
            }
            tbl_QLLuong_NV.setModel(model);
            ct.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public boolean kiemTraMaTrung() {
        boolean kq;
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaLuong().contains(txt_Ma_Luong.getText());
            if (kq == true) {
                JOptionPane.showMessageDialog(this, "Do not duplicate salary code");
                return true;
            }
        }
        return false;
    }

    public boolean check_input() {

        if (txt_Ma_Luong.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave salary code blank");
            txt_Ma_Luong.requestFocus();
            return false;
        }
        if (cbo_Ma_NV.getSelectedItem().equals("")) {
            JOptionPane.showMessageDialog(this, "Don't leave employee code blank");
            cbo_Ma_NV.requestFocus();
            return false;
        }

        if (txt_NgayLamViec.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave blank working day");
            txt_NgayLamViec.requestFocus();
            return false;
        }

        if (txt_GioLamThem.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave working hours blank");
            txt_GioLamThem.requestFocus();
            return false;
        }

        if (txt_TienThuong.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave the bonus empty");
            txt_TienThuong.requestFocus();
            return false;
        }

        if (txt_TienPhuCap.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave allowances empty");
            txt_TienPhuCap.requestFocus();
            return false;
        }

        if (txt_TienUngTruoc.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the deposit blank");
            txt_TienUngTruoc.requestFocus();
            return false;
        }

        if (txt_LuongCung.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave blank salary");
            txt_LuongCung.requestFocus();
            return false;
        }

//        Pattern pattern = Pattern.compile("[0-9]{9}");
//        Matcher matcher_GLT = pattern.matcher(txt_GioLamThem.getText());
//
//        if (!matcher_GLT.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_GioLamThem.requestFocus();
//            return false;
//        }
//
//        Matcher matcher_LC = pattern.matcher(txt_LuongCung.getText());
//
//        if (!matcher_LC.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_LuongCung.requestFocus();
//            return false;
//        }
//
//        Matcher matcher_NG = pattern.matcher(txt_NgayLamViec.getText());
//
//        if (!matcher_LC.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_NgayLamViec.requestFocus();
//            return false;
//        }
//
//        Matcher matcher_TT = pattern.matcher(txt_TienThuong.getText());
//
//        if (!matcher_LC.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_TienThuong.requestFocus();
//            return false;
//        }
//
//        Matcher matcher_PC = pattern.matcher(txt_TienPhuCap.getText());
//
//        if (!matcher_LC.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_TienPhuCap.requestFocus();
//            return false;
//        }
//
//        Matcher matcher_Ung = pattern.matcher(txt_TienUngTruoc.getText());
//
//        if (!matcher_LC.matches()) {
//            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
//            txt_TienUngTruoc.requestFocus();
//            return false;
//        }
        float gioLam = Float.parseFloat(txt_GioLamThem.getText());
        if (gioLam < 1) {
            JOptionPane.showMessageDialog(this, "Working hours must not be less than 1 hour or 12 hours");
            txt_GioLamThem.requestFocus();
            return false;
        }

        int ngayLV = Integer.parseInt(txt_NgayLamViec.getText());
        if (ngayLV < 1 || ngayLV > 31) {
            JOptionPane.showMessageDialog(this, "Working days should not be less than 1 day or 31 days");
            txt_NgayLamViec.requestFocus();
            return false;
        }

        float tienThuong = Float.parseFloat(txt_TienThuong.getText());
        if (tienThuong < 0) {
            JOptionPane.showMessageDialog(this, "The bonus cannot be less than 0");
            txt_TienThuong.requestFocus();
            return false;
        }

        float tienPC = Float.parseFloat(txt_TienPhuCap.getText());
        if (tienPC < 0) {
            JOptionPane.showMessageDialog(this, "Allowance should not be less than 0");
            txt_TienPhuCap.requestFocus();
            return false;
        }

        float tienUng = Float.parseFloat(txt_TienUngTruoc.getText());
        if (tienUng < 0) {
            JOptionPane.showMessageDialog(this, "Advance payment must not be less than 0");
            txt_TienUngTruoc.requestFocus();
            return false;
        }

        float tienLuong = Float.parseFloat(txt_LuongCung.getText());
        if (tienLuong < 0) {
            JOptionPane.showMessageDialog(this, "Salary must not be less than 0");
            txt_LuongCung.requestFocus();
            return false;
        }

        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cbo_ThangLuong = new javax.swing.JComboBox<>();
        txt_Ma_Luong = new javax.swing.JTextField();
        cbo_Ma_NV = new javax.swing.JComboBox<>();
        txt_NgayLamViec = new javax.swing.JTextField();
        txt_GioLamThem = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_TienThuong = new javax.swing.JTextField();
        txt_TienPhuCap = new javax.swing.JTextField();
        txt_TienUngTruoc = new javax.swing.JTextField();
        txt_LuongCung = new javax.swing.JTextField();
        btn_Them = new javax.swing.JButton();
        btn_Sua = new javax.swing.JButton();
        btn_Xoa = new javax.swing.JButton();
        btn_Luu = new javax.swing.JButton();
        btn_Thoat = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLLuong_NV = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txt_TimKiem = new javax.swing.JTextField();
        btn_TimKiem = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản Lý Lương Nhân Viên");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Quản Lý Lương Nhân Viên");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(376, 11, 246, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Tháng Lãnh Lương ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 53, 107, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Mã Lương");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 89, 67, 28));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Mã Nhân Viên");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 137, 85, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Số Ngày Làm Việc");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 173, 107, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel6.setText("Số Giờ Làm");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 216, 107, -1));

        cbo_ThangLuong.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        getContentPane().add(cbo_ThangLuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 51, 244, -1));
        getContentPane().add(txt_Ma_Luong, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 94, 244, -1));

        cbo_Ma_NV.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        getContentPane().add(cbo_Ma_NV, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 135, 244, -1));
        getContentPane().add(txt_NgayLamViec, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 173, 244, -1));
        getContentPane().add(txt_GioLamThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 214, 244, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel7.setText("Tiền Thưởng");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 53, 101, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Tiền Phụ Cấp");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 91, 88, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Tiền Ứng Trước");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 137, 100, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel10.setText("Lương Cứng");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 175, 83, -1));
        getContentPane().add(txt_TienThuong, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 51, 319, -1));
        getContentPane().add(txt_TienPhuCap, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 89, 319, -1));
        getContentPane().add(txt_TienUngTruoc, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 135, 319, -1));
        getContentPane().add(txt_LuongCung, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 173, 319, -1));

        btn_Them.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new-document.png"))); // NOI18N
        btn_Them.setText("Thêm");
        btn_Them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThemActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Them, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 269, 107, 41));

        btn_Sua.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        btn_Sua.setText("Sửa");
        btn_Sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SuaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Sua, new org.netbeans.lib.awtextra.AbsoluteConstraints(595, 269, 99, 41));

        btn_Xoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        btn_Xoa.setText("Xoá");
        btn_Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_XoaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Xoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(462, 269, 87, 41));

        btn_Luu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        btn_Luu.setText("Lưu");
        btn_Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LuuActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Luu, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 269, 107, 41));

        btn_Thoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/power-off.png"))); // NOI18N
        btn_Thoat.setText("Thoát");
        btn_Thoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThoatActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Thoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(825, 273, -1, -1));

        tbl_QLLuong_NV.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl_QLLuong_NV.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLLuong_NVMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLLuong_NV);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 442, 962, 118));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel11.setText("Tìm Kiếm");

        txt_TimKiem.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                txt_TimKiemCaretUpdate(evt);
            }
        });

        btn_TimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_TimKiem.setText("Tìm Kiếm");
        btn_TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addComponent(btn_TimKiem)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txt_TimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_TimKiem))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 328, -1, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Background_QL_LuongNhanVien.png"))); // NOI18N
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 580));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_ThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThoatActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to escape ?", "Exit program", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            this.dispose();
        }
    }//GEN-LAST:event_btn_ThoatActionPerformed

    public void New_Luong() {
        txt_GioLamThem.setText("");
        txt_LuongCung.setText("");
        txt_Ma_Luong.setText("");
        txt_NgayLamViec.setText("");
        txt_TienPhuCap.setText("");
        txt_TienThuong.setText("");
        txt_TienUngTruoc.setText("");
        cbo_Ma_NV.setSelectedIndex(0);
        cbo_ThangLuong.setSelectedIndex(0);
        txt_Ma_Luong.requestFocus();
        txt_Ma_Luong.setEnabled(true);
    }
    private void btn_ThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThemActionPerformed
        New_Luong();
    }//GEN-LAST:event_btn_ThemActionPerformed

    public QL_LuongNhanVien readNV() {
        QL_LuongNhanVien nv = new QL_LuongNhanVien();
        nv.setThang(cbo_ThangLuong.getSelectedIndex() + 1);
        nv.setMaLuong(txt_Ma_Luong.getText());
        nv.setMaNV(cbo_Ma_NV.getSelectedItem().toString());
        nv.setNgayLamViec(Integer.parseInt(txt_NgayLamViec.getText()));
        nv.setGioLamViec(Float.parseFloat(txt_GioLamThem.getText()));
        nv.setTienThuong(Float.parseFloat(txt_TienThuong.getText()));
        nv.setTienPhuCap(Float.parseFloat(txt_TienPhuCap.getText()));
        nv.setTienUngTruoc(Float.parseFloat(txt_TienUngTruoc.getText()));
        nv.setLuongCoDinh(Float.parseFloat(txt_LuongCung.getText()));
//        System.out.println(cbo_ThangLuong.getSelectedIndex());
        return nv;

    }

    public void hienThiKhachHangLenForm(int index) {
        cbo_ThangLuong.setSelectedIndex(list.get(index).getThang() - 1);
        txt_Ma_Luong.setText(list.get(index).getMaLuong());
        cbo_Ma_NV.setSelectedItem(list.get(index).getMaNV());
        txt_GioLamThem.setText(String.valueOf(list.get(index).getGioLamViec()));
        txt_NgayLamViec.setText(String.valueOf(list.get(index).getNgayLamViec()));
        txt_TienThuong.setText(String.valueOf(list.get(index).getTienThuong()));
        txt_TienPhuCap.setText(String.valueOf(list.get(index).getTienPhuCap()));
        txt_TienUngTruoc.setText(String.valueOf(list.get(index).getTienUngTruoc()));
        txt_LuongCung.setText(String.valueOf(list.get(index).getLuongCoDinh()));
//        System.out.println(list.get(index).getThang() - 1);
    }

    public void Them_NV(QL_LuongNhanVien nv) {
        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "insert into Luong_NhanVien values (?,?,?,?,?,?,?,?,?)";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setInt(1, nv.getThang());
            st.setString(2, nv.getMaLuong());
            st.setString(3, nv.getMaNV());
            st.setInt(4, nv.getNgayLamViec());

            st.setFloat(5, nv.getGioLamViec());
            st.setFloat(6, nv.getTienThuong());
            st.setFloat(7, nv.getTienPhuCap());
            st.setFloat(8, nv.getTienUngTruoc());
            st.setFloat(9, nv.getLuongCoDinh());
            st.executeUpdate();
            JOptionPane.showMessageDialog(this, "More Staff success");
            ct.close();
            Load_Data();
            Open_DATA();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Employee code does not exist !!!");
        } 
    }


    private void btn_LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LuuActionPerformed
        try {
            if (check_input()) {
                if (kiemTraMaTrung() == false) {
                    Them_NV(readNV());
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Do not enter the wrong format");
        }

    }//GEN-LAST:event_btn_LuuActionPerformed

    private void tbl_QLLuong_NVMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLLuong_NVMouseClicked
        int i = tbl_QLLuong_NV.getSelectedRow();
        hienThiKhachHangLenForm(i);
        txt_Ma_Luong.setEnabled(false);
    }//GEN-LAST:event_tbl_QLLuong_NVMouseClicked

    public void Xoa_NV() {
        if (txt_Ma_Luong.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave salary code blank");
            txt_Ma_Luong.requestFocus();
            return;
        }
        try {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ?", "Delete Staff", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                int row = 0;
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "delete from Luong_NhanVien where MaLuong = ?";
                PreparedStatement st = ct.prepareStatement(sql);
                st.setString(1, txt_Ma_Luong.getText());
                st.executeUpdate();
                if (row >= 0) {
                    JOptionPane.showMessageDialog(this, "Delete Staff Successful");
                } else {
                    JOptionPane.showMessageDialog(this, "Delete Staff Unsuccessful");
                }
                ct.close();
                Load_Data();
                Open_DATA();
                New_Luong();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_XoaActionPerformed
        Xoa_NV();
    }//GEN-LAST:event_btn_XoaActionPerformed

    public void Update_Data_NV(QL_LuongNhanVien nv) {

        try {

            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to update again ?", "Update employee information", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "Update Luong_NhanVien set Thang = ? , MaNV = ?, SoNgayLamViec = ?, SoGioLamThem = ?, TienThuong = ?, TienPhuCap = ? , TienUngTruoc = ? ,LuongCung = ? where MaLuong = ?";
                PreparedStatement st = ct.prepareStatement(sql);

                st.setInt(1, nv.getThang());
                st.setString(2, nv.getMaNV());
                st.setInt(3, nv.getNgayLamViec());
                st.setFloat(4, nv.getGioLamViec());
                st.setFloat(5, nv.getTienThuong());
                st.setFloat(6, nv.getTienPhuCap());
                st.setFloat(7, nv.getTienUngTruoc());
                st.setFloat(8, nv.getLuongCoDinh());
                st.setString(9, nv.getMaLuong());

                st.executeUpdate();
                JOptionPane.showMessageDialog(this, "Update Successful");
                ct.close();
                Load_Data();
                Open_DATA();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_SuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SuaActionPerformed
        Update_Data_NV(readNV());
    }//GEN-LAST:event_btn_SuaActionPerformed

    public void timKiem_NV() {
        if (txt_TimKiem.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the search box empty ?");
            txt_TimKiem.requestFocus();
            return;
        }
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "select * from Luong_NhanVien where MaLuong = ?";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_TimKiem.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_QLLuong_NV.getModel();
            model.setRowCount(0);
            for (QL_LuongNhanVien sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("Thang"));
                    v.add(rs.getString("MaLuong"));
                    v.add(rs.getString("MaNV"));
                    v.add(rs.getString("SoNgayLamViec"));
                    v.add(rs.getString("SoGioLamThem"));
                    v.add(rs.getString("TienThuong"));
                    v.add(rs.getString("TienPhuCap"));
                    v.add(rs.getString("TienUngTruoc"));
                    v.add(rs.getString("LuongCung"));
                    model.addRow(v);
                }
            }
            tbl_QLLuong_NV.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_TimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TimKiemActionPerformed
        timKiem_NV();
    }//GEN-LAST:event_btn_TimKiemActionPerformed

    private void txt_TimKiemCaretUpdate(javax.swing.event.CaretEvent evt) {//GEN-FIRST:event_txt_TimKiemCaretUpdate
//        timKiem_NV();
    }//GEN-LAST:event_txt_TimKiemCaretUpdate

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QL_Luong_NV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QL_Luong_NV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QL_Luong_NV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QL_Luong_NV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QL_Luong_NV dialog = new QL_Luong_NV(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Luu;
    private javax.swing.JButton btn_Sua;
    private javax.swing.JButton btn_Them;
    private javax.swing.JButton btn_Thoat;
    private javax.swing.JButton btn_TimKiem;
    private javax.swing.JButton btn_Xoa;
    private javax.swing.JComboBox<String> cbo_Ma_NV;
    private javax.swing.JComboBox<String> cbo_ThangLuong;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_QLLuong_NV;
    private javax.swing.JTextField txt_GioLamThem;
    private javax.swing.JTextField txt_LuongCung;
    private javax.swing.JTextField txt_Ma_Luong;
    private javax.swing.JTextField txt_NgayLamViec;
    private javax.swing.JTextField txt_TienPhuCap;
    private javax.swing.JTextField txt_TienThuong;
    private javax.swing.JTextField txt_TienUngTruoc;
    private javax.swing.JTextField txt_TimKiem;
    // End of variables declaration//GEN-END:variables
}
