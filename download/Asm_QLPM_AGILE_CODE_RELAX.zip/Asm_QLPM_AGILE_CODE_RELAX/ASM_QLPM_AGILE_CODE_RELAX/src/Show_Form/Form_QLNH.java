/*

 */
package Show_Form;

import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class Form_QLNH extends javax.swing.JFrame {
    
    /**
     * Creates new form Form_QLNH
     */
    public Form_QLNH(String vaiTRo) {
        initComponents();
        
        if(vaiTRo.equalsIgnoreCase("ADMIN")){
            btn_QLNV.setEnabled(true);
            btn_QL_LuongNV.setEnabled(true);
        }else {
            btn_QLNV.setEnabled(false);
            btn_QL_LuongNV.setEnabled(false);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        LOGO_Nha_Hang = new javax.swing.JLabel();
        btn_QLNV = new javax.swing.JButton();
        btn_QLDMA = new javax.swing.JButton();
        btn_QL_LuongNV = new javax.swing.JButton();
        btn_QL_Menu = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        Menu_Tro_Giup = new javax.swing.JMenu();
        Menu_Gioi_Thieu = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        menu_Item_DoiPass = new javax.swing.JMenuItem();
        Menu_Con_QL_Tk = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("HỆ THỐNG");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Hệ Thống Quản Lý Nhà Hàng");

        LOGO_Nha_Hang.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/restaurant-logo.png"))); // NOI18N

        btn_QLNV.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_QLNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/QL_NhanVien_Icon.png"))); // NOI18N
        btn_QLNV.setText("Quản lý nhân viên");
        btn_QLNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QLNVActionPerformed(evt);
            }
        });

        btn_QLDMA.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_QLDMA.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/restaurant_tbl.png"))); // NOI18N
        btn_QLDMA.setText("Quản lý Đặt Món Ăn");
        btn_QLDMA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QLDMAActionPerformed(evt);
            }
        });

        btn_QL_LuongNV.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_QL_LuongNV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/employee.png"))); // NOI18N
        btn_QL_LuongNV.setText("Quản Lý Lương Nhân Viên");
        btn_QL_LuongNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QL_LuongNVActionPerformed(evt);
            }
        });

        btn_QL_Menu.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btn_QL_Menu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/menu.png"))); // NOI18N
        btn_QL_Menu.setText("Quản Lý Menu");
        btn_QL_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_QL_MenuActionPerformed(evt);
            }
        });

        Menu_Tro_Giup.setText("Trợ Giúp");

        Menu_Gioi_Thieu.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Q, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        Menu_Gioi_Thieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/GioiThieu.png"))); // NOI18N
        Menu_Gioi_Thieu.setText("Giới Thiệu");
        Menu_Gioi_Thieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Menu_Gioi_ThieuActionPerformed(evt);
            }
        });
        Menu_Tro_Giup.add(Menu_Gioi_Thieu);

        jMenuBar1.add(Menu_Tro_Giup);

        jMenu2.setText("Cài Đặt");

        menu_Item_DoiPass.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        menu_Item_DoiPass.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/doi_MK.png"))); // NOI18N
        menu_Item_DoiPass.setText("Đổi Lại Mật Khẩu");
        menu_Item_DoiPass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_Item_DoiPassActionPerformed(evt);
            }
        });
        jMenu2.add(menu_Item_DoiPass);

        Menu_Con_QL_Tk.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        Menu_Con_QL_Tk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/QLTK.png"))); // NOI18N
        Menu_Con_QL_Tk.setText("Quản Lý Tài Khoản");
        Menu_Con_QL_Tk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Menu_Con_QL_TkActionPerformed(evt);
            }
        });
        jMenu2.add(Menu_Con_QL_Tk);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_QLNV, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_QL_LuongNV))
                .addGap(82, 82, 82)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_QL_Menu, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_QLDMA))
                .addGap(33, 33, 33))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(LOGO_Nha_Hang)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_QLNV)
                    .addComponent(btn_QLDMA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_QL_LuongNV)
                    .addComponent(btn_QL_Menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(LOGO_Nha_Hang, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_QLNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QLNVActionPerformed
        QL_NhanVien_NH nv = new QL_NhanVien_NH(this, true);
        nv.setVisible(true);
        nv.dispose();
    }//GEN-LAST:event_btn_QLNVActionPerformed

    private void menu_Item_DoiPassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_Item_DoiPassActionPerformed
        Change_Password a = new Change_Password(this, rootPaneCheckingEnabled);
        a.setVisible(true);
        a.dispose();
    }//GEN-LAST:event_menu_Item_DoiPassActionPerformed

    private void btn_QLDMAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QLDMAActionPerformed
        QL_Ban_An_NH a = new QL_Ban_An_NH(this, rootPaneCheckingEnabled);
        a.setVisible(true);
        a.dispose();
    }//GEN-LAST:event_btn_QLDMAActionPerformed


    private void Menu_Gioi_ThieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Menu_Gioi_ThieuActionPerformed

        String txt = "      🍹️ Software Founder 🍹️ ";
        txt += "\n 💖 Người Tạo : Tô Quốc Tùng";
        txt += "\n 💖 Mã Số Sinh Viên : PC04315";
        txt += "\n 💖 Sinh Ngày : 04/10/2001";
        txt += "\n 🍽 Phần Mềm Quản Lý Nhà Hàng 🍽";
        JOptionPane.showMessageDialog(this, txt, "Giới Thiệu", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_Menu_Gioi_ThieuActionPerformed

    private void Menu_Con_QL_TkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Menu_Con_QL_TkActionPerformed
        QL_Tai_Khoan a = new QL_Tai_Khoan(this, true);
        a.setVisible(true);
        a.dispose();
    }//GEN-LAST:event_Menu_Con_QL_TkActionPerformed

    private void btn_QL_LuongNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QL_LuongNVActionPerformed
       QL_Luong_NV a = new QL_Luong_NV(this, rootPaneCheckingEnabled);
       a.setVisible(true);
    }//GEN-LAST:event_btn_QL_LuongNVActionPerformed

    private void btn_QL_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_QL_MenuActionPerformed
        QL_Menu_NhaHang a = new QL_Menu_NhaHang(this, rootPaneCheckingEnabled);
        a.setVisible(true);
    }//GEN-LAST:event_btn_QL_MenuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Form_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Form_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Form_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Form_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Form_QLNH("ADMIN").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LOGO_Nha_Hang;
    private javax.swing.JMenuItem Menu_Con_QL_Tk;
    private javax.swing.JMenuItem Menu_Gioi_Thieu;
    private javax.swing.JMenu Menu_Tro_Giup;
    private javax.swing.JButton btn_QLDMA;
    private javax.swing.JButton btn_QLNV;
    private javax.swing.JButton btn_QL_LuongNV;
    private javax.swing.JButton btn_QL_Menu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem menu_Item_DoiPass;
    // End of variables declaration//GEN-END:variables
}
