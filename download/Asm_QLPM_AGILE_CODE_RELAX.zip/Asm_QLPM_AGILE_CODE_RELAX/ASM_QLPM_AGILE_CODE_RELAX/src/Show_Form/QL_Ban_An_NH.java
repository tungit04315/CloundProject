/*
  Quản lý bàn ăn nhà hàng
 */
package Show_Form;

import ThongTin_Login.HoaDonBanAn;
import ThongTin_Login.NhanVien;
import ThongTin_Login.QL_MonAn;
import ThongTin_Login.Random_Pass;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/*
   TungTQPC04315
 */
public class QL_Ban_An_NH extends javax.swing.JDialog {

    String ban_Duoc_Chon = "";
    JButton b = null;
    DefaultTableModel model, model1;
    List<QL_MonAn> list = new ArrayList<>();
    List<QL_MonAn> listz_order = new ArrayList<>();
    List<HoaDonBanAn> list_HD = new ArrayList<>();
    private String Ma, TenMon;
    private int soLuong;
    private double donGia;
    private String TaoHoaDon = "";

    Date date = new Date();

    String user = "tung";
    String pass = "123";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

    public QL_Ban_An_NH(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        duLieu_MonAn();
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
                int kq = JOptionPane.showConfirmDialog(e.getWindow(), "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
                if (kq == JOptionPane.YES_OPTION) {
                    DiaChi_Luu_DL();
                    dispose();
                } else {
                    dispose();
                }
            }
        });
        Load_Data();
        Open_DATA();
    }

    public void DiaChi_Luu_DL() throws HeadlessException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
//                    fileChooser.setFileFilter(new FileTypeFilter(".txt", "Text File"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            Save_File(fileToSave.getAbsolutePath());
        }
    }

    public void Save_File(String s) {
        try {
            FileWriter myWriter = new FileWriter(s);
//            myWriter.write();
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }
    }

    public void Load_Data() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "Select * from Menu";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String maMon = rs.getString(1);
                String tenMon = rs.getString(2);

                double thanhTien = rs.getDouble(3);

                QL_MonAn m = new QL_MonAn(maMon, tenMon, thanhTien);
                list.add(m);
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Open_DATA() {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("Select * from Menu");

            ResultSet rs = (ResultSet) ps.executeQuery();
            model = (DefaultTableModel) tbl_Menu.getModel();
            model.setRowCount(0);
            for (QL_MonAn sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("MaMon"));
                    v.add(rs.getString("TenMon"));
                    v.add(rs.getString("DonGia"));
                    model.addRow(v);

                }
            }
            tbl_Menu.setModel(model);
            ct.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

//    public void Open_Order() {
//        try {
//
//            Connection ct = DriverManager.getConnection(url, user, pass);
//
//             PreparedStatement ps = (PreparedStatement) ct.prepareStatement("select Menu.MaMon, Menu.TenMon,  COUNT(TenBan) as N'SoLuong' ,Menu.DonGia from Bang_Tam, Menu \n"
//                    + "where Menu.MaMon = Bang_Tam.MaMon and Bang_Tam.TenBan = ?\n"
//                    + "Group by Menu.MaMon, Menu.TenMon, Menu.DonGia");
//
//            ResultSet rs = (ResultSet) ps.executeQuery();
//            model1 = (DefaultTableModel) tbl_Order.getModel();
//            model1.setRowCount(0);
//            for (QL_MonAn sv : list) {
//                while (rs.next()) {
//                    Vector v = new Vector();
//                    v.add(rs.getString("MaMon"));
//                    v.add(rs.getString("TenMon"));
//                    v.add(rs.getString("SoLuong"));
//                    v.add(rs.getString("DonGia"));
//                    model.addRow(v);
//
//                }
//            }
//            tbl_Order.setModel(model1);
//            ct.close();
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(this, e);
//        }
//    }
    public void duLieu_MonAn() {
//        model = (DefaultTableModel) tbl_Menu.getModel();
//       
//        list.add(new QL_MonAn("M01", "Gà Sốt Thái",1,20));
//        list.add(new QL_MonAn("M09", "Gà Sốt Thái", 1, 20));
//        
//        model.setRowCount(0);
//        for (QL_MonAn m : list) {
//            model.addRow(new Object[]{m.getMaMon(), m.getTenMon(), m.getSoLuong(), m.getDonGia()});
//            tbl_Menu.setModel(model);
//        }
    }

    public void AddMOn(String Ma, String TenMon, double DonGia) {
        model1 = (DefaultTableModel) tbl_Order.getModel();

        this.Ma = Ma;
        this.TenMon = TenMon;
        this.donGia = DonGia;

        listz_order.add(new QL_MonAn(this.Ma, this.TenMon, this.donGia));
        model1.setRowCount(0);
        for (QL_MonAn M : listz_order) {
            model1.addRow(new Object[]{M.getMaMon(), M.getTenMon(), M.getDonGia()});
            tbl_Order.setModel(model1);
        }
    }

    public boolean Check_Ban() {

        if (ban_Duoc_Chon == "") {
            JOptionPane.showMessageDialog(this, "You have not selected a table ?");
            return false;
        }

        return true;
    }

    public void AddOrder(java.awt.event.ActionEvent evt) {

        Object o = evt.getSource();
        JButton b = null;
        int index = tbl_Menu.getSelectedRow();
        if (o instanceof JButton) {
            b = (JButton) o;
        }
        if (Check_Ban()) {
            if (index > -1) {
                try {
                    AddMOn(list.get(index).getMaMon(), list.get(index).getTenMon(), list.get(index).getDonGia());
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    Connection ct = DriverManager.getConnection(url, user, pass);
                    String sql = "insert into Bang_Tam values (?,?)";
                    PreparedStatement st = ct.prepareStatement(sql);
                    st.setString(1, ban_Duoc_Chon);
                    st.setString(2, list.get(index).getMaMon());

                    st.executeUpdate();
                    Load_Order(TenMon);
                    JOptionPane.showMessageDialog(this, "Successful");
                    ct.close();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, e);
                }

            }
        }

    }

    public void Load_Order(String tenBan) {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("select Menu.MaMon, Menu.TenMon,  COUNT(TenBan) as N'SoLuong' ,Menu.DonGia from Bang_Tam, Menu \n"
                    + "where Menu.MaMon = Bang_Tam.MaMon and Bang_Tam.TenBan = ?\n"
                    + "Group by Menu.MaMon, Menu.TenMon, Menu.DonGia");
            ps.setString(1, ban_Duoc_Chon);
            ResultSet rs = (ResultSet) ps.executeQuery();
            model1 = (DefaultTableModel) tbl_Order.getModel();
            model1.setRowCount(0);
            double thanhTien = 0;
            for (QL_MonAn mon : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("MaMon"));
                    v.add(rs.getString("TenMon"));
                    v.add(rs.getString("SoLuong"));
                    v.add(rs.getString("DonGia"));
                    model1.addRow(v);

                    thanhTien += Integer.parseInt(rs.getString("SoLuong")) * Double.parseDouble(rs.getString("DonGia"));
                }
            }
            tbl_Order.setModel(model1);
            txt_ThanhTien.setText(String.valueOf(thanhTien) + " VNĐ");
//            Open_Order();
            ct.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_Ban_1 = new javax.swing.JButton();
        btn_Ban_2 = new javax.swing.JButton();
        btn_Ban_3 = new javax.swing.JButton();
        btn_Ban_4 = new javax.swing.JButton();
        btn_Ban_5 = new javax.swing.JButton();
        btn_Ban_6 = new javax.swing.JButton();
        btn_Ban_7 = new javax.swing.JButton();
        btn_Ban_8 = new javax.swing.JButton();
        btn_Ban_9 = new javax.swing.JButton();
        btn_Ban_10 = new javax.swing.JButton();
        btn_Ban_11 = new javax.swing.JButton();
        btn_Ban_12 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Order = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_Menu = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btn_Add = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btn_Delete = new javax.swing.JButton();
        btn_Bill = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txt_ThanhTien = new javax.swing.JTextField();
        btn_Ban_Order = new javax.swing.JButton();
        btn_Thoat = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("QUẢN LÝ ĐẶT BÀN");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        btn_Ban_1.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_1.setText("Bàn 1");
        btn_Ban_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_1ActionPerformed(evt);
            }
        });

        btn_Ban_2.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_2.setText("Bàn 2");
        btn_Ban_2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_2ActionPerformed(evt);
            }
        });

        btn_Ban_3.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_3.setText("Bàn 3");
        btn_Ban_3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_3ActionPerformed(evt);
            }
        });

        btn_Ban_4.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_4.setText("Bàn 4");
        btn_Ban_4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_4ActionPerformed(evt);
            }
        });

        btn_Ban_5.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_5.setText("Bàn 5");
        btn_Ban_5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_5ActionPerformed(evt);
            }
        });

        btn_Ban_6.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_6.setText("Bàn 6");
        btn_Ban_6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_6ActionPerformed(evt);
            }
        });

        btn_Ban_7.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_7.setText("Bàn 7");
        btn_Ban_7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_7ActionPerformed(evt);
            }
        });

        btn_Ban_8.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_8.setText("Bàn 8");
        btn_Ban_8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_8ActionPerformed(evt);
            }
        });

        btn_Ban_9.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_9.setText("Bàn 9");
        btn_Ban_9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_9ActionPerformed(evt);
            }
        });

        btn_Ban_10.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_10.setText("Bàn 10");
        btn_Ban_10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_10ActionPerformed(evt);
            }
        });

        btn_Ban_11.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_11.setText("Bàn 11");
        btn_Ban_11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_11ActionPerformed(evt);
            }
        });

        btn_Ban_12.setBackground(new java.awt.Color(255, 255, 255));
        btn_Ban_12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Ban_An.png"))); // NOI18N
        btn_Ban_12.setText("Bàn 12");
        btn_Ban_12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_Ban_1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_11, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_Ban_2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_Ban_10, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                    .addComponent(btn_Ban_12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Ban_1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Ban_2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_Ban_3, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(btn_Ban_4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_Ban_5, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                    .addComponent(btn_Ban_6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Ban_7, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Ban_8, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Ban_9, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Ban_10, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_Ban_11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Ban_12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 39, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 0));
        jLabel1.setText("Quản Lý Bàn Ăn");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 158, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        tbl_Order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã Món", "Tên Món", "Số Lượng", "Đơn Giá"
            }
        ));
        jScrollPane1.setViewportView(tbl_Order);

        tbl_Menu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã Món", "Tên Món", "Đơn Giá"
            }
        ));
        jScrollPane2.setViewportView(tbl_Menu);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Menu");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Order");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(242, 242, 242)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                            .addComponent(jScrollPane1))))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(250, 250, 250)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 39, -1, -1));

        btn_Add.setForeground(new java.awt.Color(153, 0, 0));
        btn_Add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ThemMon.png"))); // NOI18N
        btn_Add.setText("Thêm Món");
        btn_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_AddActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 489, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 0, 0));
        jLabel5.setText("Quản Lý Món & Order");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 212, -1));

        btn_Delete.setForeground(new java.awt.Color(153, 0, 51));
        btn_Delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ThemMon.png"))); // NOI18N
        btn_Delete.setText("Xoá Món");
        btn_Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_DeleteActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(438, 489, 110, -1));

        btn_Bill.setForeground(new java.awt.Color(153, 0, 51));
        btn_Bill.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/tinhTien.png"))); // NOI18N
        btn_Bill.setText("Tính Tiền");
        btn_Bill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_BillActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Bill, new org.netbeans.lib.awtextra.AbsoluteConstraints(563, 489, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(153, 0, 0));
        jLabel4.setText("Tổng Tiền : ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 490, -1, 30));
        getContentPane().add(txt_ThanhTien, new org.netbeans.lib.awtextra.AbsoluteConstraints(757, 490, 148, -1));

        btn_Ban_Order.setForeground(new java.awt.Color(153, 0, 0));
        btn_Ban_Order.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/yes.png"))); // NOI18N
        btn_Ban_Order.setText("Xác Nhận Thanh Toán");
        btn_Ban_Order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_Ban_OrderActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Ban_Order, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 530, -1, -1));

        btn_Thoat.setForeground(new java.awt.Color(153, 0, 0));
        btn_Thoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/X.png"))); // NOI18N
        btn_Thoat.setText("Thoát");
        btn_Thoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThoatActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Thoat, new org.netbeans.lib.awtextra.AbsoluteConstraints(492, 530, 90, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/QL_BanAn.png"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 570));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_AddActionPerformed
        AddOrder(evt);

    }//GEN-LAST:event_btn_AddActionPerformed

    private void btn_BillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_BillActionPerformed
        if (Check_Ban()) {
            try {
                double donGia = 0;
                double SumTien = 0;
                int soLuong = 0;
                int stt = 0;
                Random ngau = new Random();
                for (int icou = 0; icou < 2; icou++) {
                    stt = ngau.nextInt(100);
                }
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
                simpleDateFormat.applyPattern("dd.MM.yyyy ss");
                String formatS = simpleDateFormat.format(date);
                TaoHoaDon = formatS + stt;

                simpleDateFormat.applyPattern("dd.MM.yyyy");
                String format_Ngay = simpleDateFormat.format(date);

//            System.out.println(TaoHoaDon);
//            System.out.println(ban_Duoc_Chon);
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "insert into HoaDon values (?,?,?,?,?,?,?)";
                PreparedStatement st = ct.prepareStatement(sql);

                model1 = (DefaultTableModel) tbl_Order.getModel();
                for (int i = 0; i < model1.getRowCount(); i++) {

                    st.setString(1, TaoHoaDon);
                    st.setString(2, ban_Duoc_Chon);
                    st.setString(3, tbl_Order.getValueAt(i, 0).toString());
                    st.setString(4, tbl_Order.getValueAt(i, 2).toString());
                    st.setString(5, tbl_Order.getValueAt(i, 3).toString());

                    SumTien = Float.parseFloat(tbl_Order.getValueAt(i, 2).toString()) * Float.parseFloat(tbl_Order.getValueAt(i, 3).toString());
                    st.setString(6, String.valueOf(SumTien));
                    st.setString(7, format_Ngay);
//                stt++;
//                TaoHoaDon += i;
                    st.executeUpdate();
                    Load_Data_HoaDon();
                    JOptionPane.showMessageDialog(this, "The information has been updated to the restaurant invoice");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, e);
//            System.out.println(e);
            }
        }
    }//GEN-LAST:event_btn_BillActionPerformed

    private void btn_DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_DeleteActionPerformed
        if (Check_Ban()) {
            int index = tbl_Order.getSelectedRow();

            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete the item?", "Delete Order", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                try {
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    Connection ct = DriverManager.getConnection(url, user, pass);
                    String sql = "delete Bang_Tam where MaMon = ?";
                    PreparedStatement st = ct.prepareStatement(sql);
                    st.setString(1, tbl_Order.getValueAt(index, 0).toString());

                    st.executeUpdate();
                    Load_Order(ban_Duoc_Chon);
                    JOptionPane.showMessageDialog(this, "Successful");
                    ct.close();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, e);
                }
            }
        }
    }//GEN-LAST:event_btn_DeleteActionPerformed

    private void btn_ThoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThoatActionPerformed
        dispose();
    }//GEN-LAST:event_btn_ThoatActionPerformed

    private void btn_Ban_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_1ActionPerformed
        ban_Duoc_Chon = btn_Ban_1.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_1.setBackground(Color.red);
        b = btn_Ban_1;
    }//GEN-LAST:event_btn_Ban_1ActionPerformed

    private void btn_Ban_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_2ActionPerformed
        ban_Duoc_Chon = btn_Ban_2.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_2.setBackground(Color.red);
        b = btn_Ban_2;
    }//GEN-LAST:event_btn_Ban_2ActionPerformed

    private void btn_Ban_3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_3ActionPerformed
        ban_Duoc_Chon = btn_Ban_3.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_3.setBackground(Color.red);
        b = btn_Ban_3;
    }//GEN-LAST:event_btn_Ban_3ActionPerformed

    private void btn_Ban_4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_4ActionPerformed
        ban_Duoc_Chon = btn_Ban_4.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_4.setBackground(Color.red);
        b = btn_Ban_4;
    }//GEN-LAST:event_btn_Ban_4ActionPerformed

    private void btn_Ban_5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_5ActionPerformed
        ban_Duoc_Chon = btn_Ban_5.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_5.setBackground(Color.red);
        b = btn_Ban_5;
    }//GEN-LAST:event_btn_Ban_5ActionPerformed

    private void btn_Ban_6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_6ActionPerformed
        ban_Duoc_Chon = btn_Ban_6.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_6.setBackground(Color.red);
        b = btn_Ban_6;
    }//GEN-LAST:event_btn_Ban_6ActionPerformed

    private void btn_Ban_7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_7ActionPerformed
        ban_Duoc_Chon = btn_Ban_7.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_7.setBackground(Color.red);
        b = btn_Ban_7;
    }//GEN-LAST:event_btn_Ban_7ActionPerformed

    private void btn_Ban_8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_8ActionPerformed
        ban_Duoc_Chon = btn_Ban_8.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_8.setBackground(Color.red);
        b = btn_Ban_8;
    }//GEN-LAST:event_btn_Ban_8ActionPerformed

    private void btn_Ban_9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_9ActionPerformed
        ban_Duoc_Chon = btn_Ban_9.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_9.setBackground(Color.red);
        b = btn_Ban_9;
    }//GEN-LAST:event_btn_Ban_9ActionPerformed

    private void btn_Ban_10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_10ActionPerformed
        ban_Duoc_Chon = btn_Ban_10.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_10.setBackground(Color.red);
        b = btn_Ban_10;
    }//GEN-LAST:event_btn_Ban_10ActionPerformed

    private void btn_Ban_11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_11ActionPerformed
        ban_Duoc_Chon = btn_Ban_11.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_11.setBackground(Color.red);
        b = btn_Ban_11;
    }//GEN-LAST:event_btn_Ban_11ActionPerformed

    private void btn_Ban_12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_12ActionPerformed
        ban_Duoc_Chon = btn_Ban_12.getText();
        Load_Order(ban_Duoc_Chon);
        btn_Ban_12.setBackground(Color.red);
        b = btn_Ban_12;
    }//GEN-LAST:event_btn_Ban_12ActionPerformed

    public void Load_Data_HoaDon() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);

            String sql = "Select MaHoaDon,TenBan,MaMon,SoLuong,DonGia,TongTien,ThoiGian from HoaDon where TenBan = ?";
            PreparedStatement st = con.prepareStatement(sql);
            st.setString(1, ban_Duoc_Chon);
            ResultSet rs = st.executeQuery();
            list_HD.clear();
            while (rs.next()) {
                String maHoaDon = rs.getString(1);
                String tenBan = rs.getString(2);
                String maMon = rs.getString(3);
                int soLuong = rs.getInt(4);
                double gia = rs.getDouble(5);
                double thanhTien = rs.getDouble(6);
                String thoiGian = rs.getString(7);
                HoaDonBanAn hd = new HoaDonBanAn(maHoaDon, tenBan, maMon, thoiGian, soLuong, gia, thanhTien);
                list_HD.add(hd);
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_Ban_OrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_Ban_OrderActionPerformed
        if (Check_Ban()) {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure to pay?", "Pay", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                try {
                    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                    Connection ct = DriverManager.getConnection(url, user, pass);
                    String sql = "delete Bang_Tam where TenBan = ?";
                    PreparedStatement st = ct.prepareStatement(sql);
                    st.setString(1, ban_Duoc_Chon);

                    // xử lý in ra file excel
                    XSSFWorkbook workbook = new XSSFWorkbook();
                    XSSFSheet sheet = workbook.createSheet("Hoá Đơn");
                    XSSFRow row = null;
                    Cell cell = null;

                    row = sheet.createRow(3);
                    cell = row.createCell(0, CellType.STRING);
                    cell.setCellValue("Mã Hoá Đơn");
                    cell = row.createCell(1, CellType.STRING);
                    cell.setCellValue("Tên Bàn");
                    cell = row.createCell(2, CellType.STRING);
                    cell.setCellValue("Mã Món");
                    cell = row.createCell(3, CellType.STRING);
                    cell.setCellValue("Số Lượng");
                    cell = row.createCell(4, CellType.STRING);
                    cell.setCellValue("Đơn Giá");
                    cell = row.createCell(5, CellType.STRING);
                    cell.setCellValue("Tổng Tiền");
                    cell = row.createCell(6, CellType.STRING);
                    cell.setCellValue("Thời Gian");

                    for (int i = 0; i < list_HD.size(); i++) {

                        row = sheet.createRow(4 + i);

                        cell = row.createCell(0, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getMaHoaDon());

                        cell = row.createCell(1, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getTenBan());

                        cell = row.createCell(2, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getMaMon());

                        cell = row.createCell(3, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getSoLuong());

                        cell = row.createCell(4, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getDonGia());

                        cell = row.createCell(5, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getTongTien());

                        cell = row.createCell(6, CellType.STRING);
                        cell.setCellValue(list_HD.get(i).getThoiGian());
                    }

                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Specify a file to save");
                    int userSelection = fileChooser.showSaveDialog(null);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        try {
                            FileOutputStream fis = new FileOutputStream(fileToSave);
                            workbook.write(fis);
                            fis.close();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                    st.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Payment success");
                    Load_Order(ban_Duoc_Chon);
                    b.setBackground(Color.white);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, e);
                }
            }
        }
    }//GEN-LAST:event_btn_Ban_OrderActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QL_Ban_An_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QL_Ban_An_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QL_Ban_An_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QL_Ban_An_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QL_Ban_An_NH dialog = new QL_Ban_An_NH(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_Add;
    private javax.swing.JButton btn_Ban_1;
    private javax.swing.JButton btn_Ban_10;
    private javax.swing.JButton btn_Ban_11;
    private javax.swing.JButton btn_Ban_12;
    private javax.swing.JButton btn_Ban_2;
    private javax.swing.JButton btn_Ban_3;
    private javax.swing.JButton btn_Ban_4;
    private javax.swing.JButton btn_Ban_5;
    private javax.swing.JButton btn_Ban_6;
    private javax.swing.JButton btn_Ban_7;
    private javax.swing.JButton btn_Ban_8;
    private javax.swing.JButton btn_Ban_9;
    private javax.swing.JButton btn_Ban_Order;
    private javax.swing.JButton btn_Bill;
    private javax.swing.JButton btn_Delete;
    private javax.swing.JButton btn_Thoat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbl_Menu;
    private javax.swing.JTable tbl_Order;
    private javax.swing.JTextField txt_ThanhTien;
    // End of variables declaration//GEN-END:variables
}
