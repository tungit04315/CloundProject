/*
    ASM Quản lý nhà hàng chức năng quản lý nhân viên
 */
package Show_Form;

import ThongTin_Login.NhanVien;
import java.awt.Color;
import java.awt.Container;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;

/*
   TungTQPC04315
 */
public class QL_NhanVien_NH extends javax.swing.JDialog {

    DefaultTableModel model;
    List<NhanVien> list = new ArrayList<>();
    private int index;
    String TrHinh_Anh = null;

    String user = "tung";
    String pass = "123";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

    public QL_NhanVien_NH(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
//        Load_Data();
//        Open_DATA();
        Cot_Table();
        Nut_Dong_PhanMem();

    }

    private void Nut_Dong_PhanMem() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
                int kq = JOptionPane.showConfirmDialog(e.getWindow(), "Are you sure you want to exit?", "Exit", JOptionPane.YES_NO_OPTION);
                if (kq == JOptionPane.YES_OPTION) {
                    DiaChi_Luu_DL();
                    dispose();
                } else {
                    dispose();
                }

            }
        });
    }

    public void Load_Data() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "Select * from NhanVien";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String manv = rs.getString(1);
                String hoten = rs.getString(2);
                String vaitro = rs.getString(3);
                String sdt = rs.getString(4);
                String gt = rs.getString(5);
                String vitri = rs.getString(6);
                String hinhanh = rs.getString(7);
                NhanVien sv = new NhanVien(manv, hoten, vaitro, vitri, gt, sdt, hinhanh);
                list.add(sv);
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Open_DATA() {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("Select * from NhanVien");

            ResultSet rs = (ResultSet) ps.executeQuery();
            model = (DefaultTableModel) tbl_NhanVien.getModel();
            model.setRowCount(0);
            for (NhanVien sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("MaNV"));
                    v.add(rs.getString("HoTen"));
                    v.add(rs.getString("VaiTro"));
                    v.add(rs.getString("Sdt"));
                    v.add(rs.getString("GioiTinh"));
                    v.add(rs.getString("ViTri"));
                    v.add(rs.getString("HinhAnh"));
                    model.addRow(v);
                }
            }
            tbl_NhanVien.setModel(model);
            ct.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void DiaChi_Luu_DL() throws HeadlessException {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Specify a file to save");
//                    fileChooser.setFileFilter(new FileTypeFilter(".txt", "Text File"));
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            Save_File(fileToSave.getAbsolutePath());
        }
    }

    public void Save_File(String s) {
        try {
            FileWriter myWriter = new FileWriter(s);
//            myWriter.write();
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException ex) {
            System.out.println("An error occurred.");
            ex.printStackTrace();
        }
    }

    public void Cot_Table() {
        model = (DefaultTableModel) tbl_NhanVien.getModel();
        model.setColumnIdentifiers(new String[]{"Mã Nhân Viên", "Họ và Tên", "Vai Trò", "Số Điện Thoại", "Giới Tính", "Vị Trí", "Hình Ảnh"});
    }

    public NhanVien readNV() {
        NhanVien nv = new NhanVien();
        nv.setMaNV(txt_MaNV.getText());
        nv.setTenNV(txt_HoVaTen.getText());
        nv.setVaiTro(txt_VaiTro.getText());
        nv.setSdt(txt_SDT.getText());
        nv.setGioiTinh(rdo_Nam.isSelected() ? "Nam" : "Nữ");
        nv.setViTri(txt_ViTri.getText());
        if (TrHinh_Anh == null) {
            nv.setHinhAnh("No Avatar");
        } else {
            nv.setHinhAnh(TrHinh_Anh);
        }
        return nv;
    }

    public void duLieuTable() {
        model = (DefaultTableModel) tbl_NhanVien.getModel();
        model.setRowCount(0);
        for (NhanVien nv : list) {
            model.addRow(new Object[]{nv.getMaNV(), nv.getTenNV(), nv.getVaiTro(), nv.getSdt(), nv.getGioiTinh(), nv.getViTri(), nv.getHinhAnh()});
            tbl_NhanVien.setModel(model);
        }
    }

//    public void add() {
//        list.add(readNV());
//        duLieuTable();
//    }
    public boolean kiemTra_TextField() {
        if (txt_MaNV.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "cannot be empty Employee code");
            txt_MaNV.requestFocus();
            return false;
        }
        if (txt_HoVaTen.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "First and Last name can't be left blank");
            txt_HoVaTen.requestFocus();
            return false;
        }
        if (txt_VaiTro.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Role can't be left blank");
            txt_VaiTro.requestFocus();
            return false;
        }
        if (txt_SDT.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Phone number can't be left blank");
            txt_SDT.requestFocus();
            return false;
        }
        if (txt_ViTri.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "The Employee position can't be left blank");
            txt_ViTri.requestFocus();
            return false;
        }

        if (txt_MaNV.getText().length() > 7 || txt_MaNV.getText().length() < 4) {
            JOptionPane.showMessageDialog(this, "Employee code must not be more than 4 char or more than 7 char");
            txt_MaNV.requestFocus();
            return false;
        }

        if (txt_SDT.getText().length() > 11 || txt_SDT.getText().length() < 11) {
            JOptionPane.showMessageDialog(this, "Phone number must not exceed 11 numbers");
            txt_SDT.requestFocus();
            return false;
        }

        Pattern pattern = Pattern.compile("0[234][0-9]{9}");
        Matcher matcher = pattern.matcher(txt_SDT.getText());

        if (!matcher.matches()) {
            JOptionPane.showMessageDialog(this, "The phone number you entered is not in the correct format");
            txt_SDT.requestFocus();
            return false;
        }

        return true;
    }

    public void hienThiKhachHangLenForm(int index) {
        txt_MaNV.setText(list.get(index).getMaNV());
        txt_HoVaTen.setText(list.get(index).getTenNV());
        txt_VaiTro.setText(list.get(index).getVaiTro());
        txt_SDT.setText(String.valueOf(list.get(index).getSdt()));
        if (list.get(index).getGioiTinh().equalsIgnoreCase("Nam")) {
            rdo_Nam.setSelected(true);
        } else {
            rdo_Nu.setSelected(true);
        }
        txt_ViTri.setText(list.get(index).getViTri());
        try {
            if (list.get(index).getHinhAnh().equalsIgnoreCase("No Avatar")) {
                HinhAnh.setText("No Avatar");
                HinhAnh.setIcon(null);
            } else {
                HinhAnh.setText("");
                ImageIcon imgIcon = new ImageIcon(getClass().getResource("/images/" + list.get(index).getHinhAnh()));
                Image img = imgIcon.getImage();
                img.getScaledInstance(HinhAnh.getWidth(), HinhAnh.getY(), 0);
                HinhAnh.setIcon(imgIcon);
            }
        } catch (NullPointerException e) {
        }

    }

    public void HangDauTien() {
        try {
            index = 0;
            tbl_NhanVien.setRowSelectionInterval(index, index);
            hienThiKhachHangLenForm(index);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "No data yet !!!");
        }

    }

    public void HangCuoiCung() {
        try {
            index = list.size() - 1;
            tbl_NhanVien.setRowSelectionInterval(index, index);
            hienThiKhachHangLenForm(index);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "No data yet !!!");
        }

    }

    public void quayLai() {
        try {
            if (index == 0 || index == -1) {
                HangCuoiCung();
            } else {
                index--;
            }
            tbl_NhanVien.setRowSelectionInterval(index, index);
            hienThiKhachHangLenForm(index);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "No data yet !!!");
        }

    }

    public void keTiep() {
        try {
            if (index == list.size() - 1) {
                HangDauTien();
            } else {
                index++;
            }
            tbl_NhanVien.setRowSelectionInterval(index, index);
            hienThiKhachHangLenForm(index);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "No data yet !!!");
        }

        // lỗi IllegalArgumentException
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txt_MaNV = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rdo_Nam = new javax.swing.JRadioButton();
        rdo_Nu = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        txt_HoVaTen = new javax.swing.JTextField();
        txt_VaiTro = new javax.swing.JTextField();
        txt_SDT = new javax.swing.JTextField();
        txt_ViTri = new javax.swing.JTextField();
        HinhAnh = new javax.swing.JLabel();
        btn_Clean = new javax.swing.JButton();
        btn_Save = new javax.swing.JButton();
        btn_Xoa = new javax.swing.JButton();
        btn_Update = new javax.swing.JButton();
        btn_Search = new javax.swing.JButton();
        btn_Exit = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_NhanVien = new javax.swing.JTable();
        btn_ViTriDau = new javax.swing.JButton();
        btn_Lui = new javax.swing.JButton();
        btn_TiepTheo = new javax.swing.JButton();
        btn_ViTriCuoi = new javax.swing.JButton();
        rdo_Tang = new javax.swing.JRadioButton();
        rdo_Giam = new javax.swing.JRadioButton();
        btn_SXTheoMa = new javax.swing.JButton();
        btn_Open = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("QUẢN LÝ NHÂN VIÊN NHÀ HÀNG");
        setPreferredSize(new java.awt.Dimension(756, 575));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ NHÂN VIÊN ");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(285, 11, 206, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setText("Họ Và Tên ");

        jLabel4.setText("Mã Nhân Viên");

        jLabel2.setText("Vai trò");

        jLabel5.setText("Số điện thoại");

        jLabel6.setText("Giới Tính");

        buttonGroup1.add(rdo_Nam);
        rdo_Nam.setSelected(true);
        rdo_Nam.setText("Nam");

        buttonGroup1.add(rdo_Nu);
        rdo_Nu.setText("Nữ");

        jLabel7.setText("Vị Trí");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(rdo_Nam, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(rdo_Nu, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(128, 128, 128))
                    .addComponent(txt_HoVaTen)
                    .addComponent(txt_MaNV)
                    .addComponent(txt_VaiTro)
                    .addComponent(txt_SDT)
                    .addComponent(txt_ViTri))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_MaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_HoVaTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_VaiTro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(rdo_Nam)
                    .addComponent(rdo_Nu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txt_ViTri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 51, -1, -1));

        HinhAnh.setText("Hình Ảnh");
        HinhAnh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        HinhAnh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HinhAnhMouseClicked(evt);
            }
        });
        getContentPane().add(HinhAnh, new org.netbeans.lib.awtextra.AbsoluteConstraints(497, 51, 234, 223));

        btn_Clean.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new-document.png"))); // NOI18N
        btn_Clean.setText("Làm mới");
        btn_Clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CleanActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Clean, new org.netbeans.lib.awtextra.AbsoluteConstraints(499, 285, 107, -1));

        btn_Save.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        btn_Save.setText("Lưu");
        btn_Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SaveActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Save, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 285, 111, -1));

        btn_Xoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        btn_Xoa.setText("Xoá");
        btn_Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_XoaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Xoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(499, 329, 107, 40));

        btn_Update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/update.png"))); // NOI18N
        btn_Update.setText("Cập nhật");
        btn_Update.setAlignmentY(1.0F);
        btn_Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 330, 111, 40));

        btn_Search.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_Search.setText("Tìm Kiếm");
        btn_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SearchActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 380, -1, -1));

        btn_Exit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/power-off.png"))); // NOI18N
        btn_Exit.setText("Thoát");
        btn_Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ExitActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 380, 111, -1));

        tbl_NhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã Nhân Viên", "Họ và Tên", "Vai Trò", "Số Điện Thoại", "Giới Tính", "Vị Trí"
            }
        ));
        tbl_NhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_NhanVienMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_NhanVien);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 419, 691, 101));

        btn_ViTriDau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/first.png"))); // NOI18N
        btn_ViTriDau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ViTriDauActionPerformed(evt);
            }
        });
        getContentPane().add(btn_ViTriDau, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 368, 73, -1));

        btn_Lui.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/left.png"))); // NOI18N
        btn_Lui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LuiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Lui, new org.netbeans.lib.awtextra.AbsoluteConstraints(119, 368, 73, 33));

        btn_TiepTheo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/right.png"))); // NOI18N
        btn_TiepTheo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TiepTheoActionPerformed(evt);
            }
        });
        getContentPane().add(btn_TiepTheo, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 368, 73, 33));

        btn_ViTriCuoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/last.png"))); // NOI18N
        btn_ViTriCuoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ViTriCuoiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_ViTriCuoi, new org.netbeans.lib.awtextra.AbsoluteConstraints(293, 368, 79, -1));

        buttonGroup2.add(rdo_Tang);
        rdo_Tang.setForeground(new java.awt.Color(255, 255, 255));
        rdo_Tang.setSelected(true);
        rdo_Tang.setText("Sắp xếp tăng");
        getContentPane().add(rdo_Tang, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 93, -1));

        buttonGroup2.add(rdo_Giam);
        rdo_Giam.setForeground(new java.awt.Color(255, 255, 255));
        rdo_Giam.setText("Sắp xếp giảm");
        getContentPane().add(rdo_Giam, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 330, 107, -1));

        btn_SXTheoMa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/filter_Sort.png"))); // NOI18N
        btn_SXTheoMa.setText("Sắp xếp theo Mã");
        btn_SXTheoMa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SXTheoMaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_SXTheoMa, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 320, -1, -1));

        btn_Open.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder.png"))); // NOI18N
        btn_Open.setText("Mở ");
        btn_Open.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_OpenActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Open, new org.netbeans.lib.awtextra.AbsoluteConstraints(412, 370, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/QL_NhanVien.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 540));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void HinhAnhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HinhAnhMouseClicked
        try {
            JFileChooser jfc = new JFileChooser("Asm_Java_3_GD1_TungTQPC04315\\ASM_Java_3_TungTQPC04315_IT17305\\src\\images");
            jfc.showOpenDialog(null);
            File file = jfc.getSelectedFile();
            Image img = ImageIO.read(file);
            TrHinh_Anh = file.getName();
            HinhAnh.setText("");
            int rong = HinhAnh.getWidth();
            int cao = HinhAnh.getHeight();
            HinhAnh.setIcon(new ImageIcon(img));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, ex);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "You have not successfully selected a photo");
        }
        //IllegalArgumentException
    }//GEN-LAST:event_HinhAnhMouseClicked

    public boolean kiemTraMaTrung() {
        boolean kq;
        for (int i = 0; i < list.size(); i++) {
            kq = list.get(i).getMaNV().contains(txt_MaNV.getText());
            if (kq == true) {
                JOptionPane.showMessageDialog(this, "Do not duplicate empolyee code");
                return true;
            }
        }
        return false;
    }

    private void btn_SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SaveActionPerformed
        if (kiemTra_TextField() && kiemTraMaTrung() == false) {
//            add();
            Them_NV(readNV());
        }
    }//GEN-LAST:event_btn_SaveActionPerformed

    public void Them_NV(NhanVien nv) {
        try {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want more ?", "More Staff", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "insert into NhanVien values (?,?,?,?,?,?,?)";
                PreparedStatement st = ct.prepareStatement(sql);
                st.setString(1, nv.getMaNV());
                st.setString(2, nv.getTenNV());
                st.setString(3, nv.getVaiTro());
                st.setString(4, nv.getSdt());
                String gt;
                if (nv.getGioiTinh().equalsIgnoreCase("Nam")) {
                    gt = "Nam";
                } else {
                    gt = "Nữ";
                }
                st.setString(5, gt);
                st.setString(6, nv.getViTri());
                st.setString(7, nv.getHinhAnh());
                st.executeUpdate();
                JOptionPane.showMessageDialog(this, "More Staff success");
                ct.close();
                Load_Data();
                Open_DATA();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_CleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CleanActionPerformed
        Clean_Form();
    }//GEN-LAST:event_btn_CleanActionPerformed

    public void Clean_Form() {
        txt_MaNV.setText("");
        txt_HoVaTen.setText("");
        txt_VaiTro.setText("");
        txt_SDT.setText("");
        txt_ViTri.setText("");
        txt_MaNV.requestFocus();
        HinhAnh.setText("Hình Ảnh");
        HinhAnh.setIcon(null);
        TrHinh_Anh = null;
        txt_MaNV.setEnabled(true);
        Open_DATA();
    }

    private void btn_ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ExitActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Do you want to save?", "Save", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            DiaChi_Luu_DL();
            dispose();
        } else
            dispose();
    }//GEN-LAST:event_btn_ExitActionPerformed

    public void Xoa_NV() {
        if (txt_MaNV.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter employee code");
            txt_MaNV.requestFocus();
            return;
        }
        try {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ?", "Delete Staff", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                int row = 0;
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "delete from NhanVien where MaNV = ?";
                PreparedStatement st = ct.prepareStatement(sql);
                st.setString(1, txt_MaNV.getText());
                st.executeUpdate();
                if (row >= 0) {
                    JOptionPane.showMessageDialog(this, "Delete Staff Successful");
                } else {
                    JOptionPane.showMessageDialog(this, "Delete Staff Unsuccessful");
                }
                ct.close();
                Load_Data();
                Open_DATA();
                Clean_Form();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't delete employee information because employee information still exists on the payroll !!!"); 
        }
    }
//delete from NhanVien where EXISTS (select * from Luong_NhanVien where Luong_NhanVien.MaNV = NhanVien.MaNV and Luong_NhanVien.MaNV = ?
    private void btn_XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_XoaActionPerformed
        if (kiemTra_TextField()) {
//            index = tbl_NhanVien.getSelectedRow();
//            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION);
//            if (kq == JOptionPane.YES_OPTION) {
//                list.remove(index);
//                JOptionPane.showMessageDialog(this, "successful delete");
//                Clean_Form();
//                duLieuTable();
//            }

            Xoa_NV();
        }
    }//GEN-LAST:event_btn_XoaActionPerformed

    public void Update_Data_NV(NhanVien nv) {
        if (txt_MaNV.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter the employee code to update ?");
            txt_MaNV.requestFocus();
            return;
        }
        try {

            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to update again ?", "Update employee information", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "Update NhanVien set HoTen = ? , VaiTro = ?, Sdt = ?, GioiTinh = ?, ViTri = ?, HinhAnh = ? where MaNV = ?";
                PreparedStatement st = ct.prepareStatement(sql);

                st.setString(1, nv.getTenNV());
                st.setString(2, nv.getVaiTro());
                st.setString(3, nv.getSdt());
                String gt;
                if (nv.getGioiTinh().equalsIgnoreCase("Nam")) {
                    gt = "Nam";
                } else {
                    gt = "Nữ";
                }
                st.setString(4, gt);
                st.setString(5, nv.getViTri());
                st.setString(6, nv.getHinhAnh());
                st.setString(7, nv.getMaNV());
                st.executeUpdate();
                JOptionPane.showMessageDialog(this, "Update Successful");
                ct.close();
                Load_Data();
                Open_DATA();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_UpdateActionPerformed
//        if (kiemTra_TextField()) {
//            index = tbl_NhanVien.getSelectedRow();
//            list.set(index, readNV());
//            duLieuTable();
//            JOptionPane.showMessageDialog(this, "Update successful");
//        }
        Update_Data_NV(readNV());

    }//GEN-LAST:event_btn_UpdateActionPerformed

    public void hienThiLenForm(NhanVien nv) {
        txt_MaNV.setText(nv.getMaNV());
        txt_HoVaTen.setText(nv.getTenNV());
        txt_VaiTro.setText(nv.getVaiTro());
        txt_SDT.setText(String.valueOf(nv.getSdt()));
        if (nv.getGioiTinh().equalsIgnoreCase("Nam")) {
            rdo_Nam.setSelected(true);
        } else {
            rdo_Nu.setSelected(true);
        }
        txt_ViTri.setText(nv.getViTri());
        try {
            if (nv.getHinhAnh().equalsIgnoreCase("No Avatar")) {
                HinhAnh.setText("No Avatar");
                HinhAnh.setIcon(null);
            } else {
                HinhAnh.setText("");
                ImageIcon imgIcon = new ImageIcon(getClass().getResource("/images/" + nv.getHinhAnh()));
                Image img = imgIcon.getImage();
                img.getScaledInstance(HinhAnh.getWidth(), HinhAnh.getY(), 0);
                HinhAnh.setIcon(imgIcon);
            }
            txt_MaNV.setEnabled(false);
        } catch (NullPointerException e) {
//            JOptionPane.showMessageDialog(this, e);
        }

    }

    public NhanVien timNV_Ma(String ma) {
        for (NhanVien nv : list) {
            if (nv.getMaNV().equalsIgnoreCase(ma)) {
                return nv;
            }
        }
        return null;
    }

//    public void TimKiemTheoMa() {
//        if (timNV_Ma(txt_MaNV.getText()) == null) {
//            JOptionPane.showMessageDialog(this, "Couldn't find employee by code");
//        } else {
//            hienThiLenForm(timNV_Ma(txt_MaNV.getText()));
//            list.set(index, readNV());
//            txt_MaNV.setEnabled(false);
//        }
//    }
    public boolean kiemTra_TrongMaNV() {
        if (txt_MaNV.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Do not leave the employee code blank");
            txt_MaNV.requestFocus();
            return false;
        }
        return true;
    }

    public void timKiem_NV() {
        if (txt_MaNV.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter the employee code to find information ?");
            txt_MaNV.requestFocus();
            return;
        }
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "select * from NhanVien where MaNV = ?";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_MaNV.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_NhanVien.getModel();
            model.setRowCount(0);
            for (NhanVien sv : list) {
                while (rs.next()) {
                    Vector v = new Vector();
                    v.add(rs.getString("MaNV"));
                    v.add(rs.getString("HoTen"));
                    v.add(rs.getString("VaiTro"));
                    v.add(rs.getString("Sdt"));
                    v.add(rs.getString("GioiTinh"));
                    v.add(rs.getString("ViTri"));
                    v.add(rs.getString("HinhAnh"));
                    model.addRow(v);
                }
            }
            tbl_NhanVien.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }


    private void btn_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SearchActionPerformed
        if (kiemTra_TrongMaNV()) {
//            TimKiemTheoMa();

            timKiem_NV();
        }
    }//GEN-LAST:event_btn_SearchActionPerformed

    private void btn_SXTheoMaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SXTheoMaActionPerformed
        Comparator<NhanVien> comp = new Comparator<NhanVien>() {
            @Override
            public int compare(NhanVien nv1, NhanVien nv2) {
                return nv1.getMaNV().compareTo(nv2.getMaNV());
            }
        };
        if (rdo_Tang.isSelected() == true) {
            Collections.sort(list, comp);
            model.setRowCount(0);
            duLieuTable();
        } else {
            Collections.sort(list, comp.reversed());
            model.setRowCount(0);
            duLieuTable();
        }
    }//GEN-LAST:event_btn_SXTheoMaActionPerformed

    private void btn_ViTriDauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ViTriDauActionPerformed
        HangDauTien();
    }//GEN-LAST:event_btn_ViTriDauActionPerformed

    private void btn_LuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LuiActionPerformed
        quayLai();
    }//GEN-LAST:event_btn_LuiActionPerformed

    private void btn_TiepTheoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TiepTheoActionPerformed
        keTiep();
    }//GEN-LAST:event_btn_TiepTheoActionPerformed

    private void btn_ViTriCuoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ViTriCuoiActionPerformed
        HangCuoiCung();
    }//GEN-LAST:event_btn_ViTriCuoiActionPerformed

    private void tbl_NhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_NhanVienMouseClicked

        try {
            index = tbl_NhanVien.getSelectedRow();
            hienThiKhachHangLenForm(index);
            
            
            int id = tbl_NhanVien.rowAtPoint(evt.getPoint());
            String ma = tbl_NhanVien.getValueAt(id, 0).toString();
            hienThiLenForm(timNV_Ma(ma));
        } catch (NullPointerException e) {
//            JOptionPane.showMessageDialog(this, e);
        }

    }//GEN-LAST:event_tbl_NhanVienMouseClicked

    private void btn_OpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_OpenActionPerformed
        Load_Data();
        Open_DATA();
        JOptionPane.showMessageDialog(this, "Open data successfully");
    }//GEN-LAST:event_btn_OpenActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QL_NhanVien_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QL_NhanVien_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QL_NhanVien_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QL_NhanVien_NH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QL_NhanVien_NH dialog = new QL_NhanVien_NH(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel HinhAnh;
    private javax.swing.JButton btn_Clean;
    private javax.swing.JButton btn_Exit;
    private javax.swing.JButton btn_Lui;
    private javax.swing.JButton btn_Open;
    private javax.swing.JButton btn_SXTheoMa;
    private javax.swing.JButton btn_Save;
    private javax.swing.JButton btn_Search;
    private javax.swing.JButton btn_TiepTheo;
    private javax.swing.JButton btn_Update;
    private javax.swing.JButton btn_ViTriCuoi;
    private javax.swing.JButton btn_ViTriDau;
    private javax.swing.JButton btn_Xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rdo_Giam;
    private javax.swing.JRadioButton rdo_Nam;
    private javax.swing.JRadioButton rdo_Nu;
    private javax.swing.JRadioButton rdo_Tang;
    private javax.swing.JTable tbl_NhanVien;
    private javax.swing.JTextField txt_HoVaTen;
    private javax.swing.JTextField txt_MaNV;
    private javax.swing.JTextField txt_SDT;
    private javax.swing.JTextField txt_VaiTro;
    private javax.swing.JTextField txt_ViTri;
    // End of variables declaration//GEN-END:variables
}
