/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Show_Form;

import ThongTin_Login.Login_UserName;
import ThongTin_Login.Login_User_Pass;
import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class Login_QLNH extends javax.swing.JDialog {

    /**
     * Creates new form Login_QLNH
     */
    public Login_QLNH(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    public boolean kiem_O_Nhap() {
        if (txt_Name.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave UserName blank");
            txt_Name.requestFocus();
            return false;
        }
        if (txt_Pass.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Don't leave Password blank");
            txt_Pass.requestFocus();
            return false;
        }
        return true;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        Logo_Login = new javax.swing.JLabel();
        txt_Name = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_Pass = new javax.swing.JPasswordField();
        btn_Login = new javax.swing.JButton();
        btn_Clean = new javax.swing.JButton();
        lbl_QuenMK = new javax.swing.JLabel();
        BackGround_Login = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ĐĂNG NHẬP");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 51));
        jLabel1.setText("Đăng Nhập Hệ Thống");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 270, 50));

        Logo_Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/login.png"))); // NOI18N
        getContentPane().add(Logo_Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, 130, 140));
        getContentPane().add(txt_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 130, 217, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Tên Đăng Nhập");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 130, -1, 20));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("Mật khẩu ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 170, 80, 20));
        getContentPane().add(txt_Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 217, -1));

        btn_Login.setForeground(new java.awt.Color(204, 0, 51));
        btn_Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Nut_Login.png"))); // NOI18N
        btn_Login.setText("Đăng nhập");
        btn_Login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LoginActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 230, -1, -1));

        btn_Clean.setForeground(new java.awt.Color(204, 0, 51));
        btn_Clean.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/power-off.png"))); // NOI18N
        btn_Clean.setText("Thoát");
        btn_Clean.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_CleanActionPerformed(evt);
            }
        });
        getContentPane().add(btn_Clean, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 230, 100, -1));

        lbl_QuenMK.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lbl_QuenMK.setForeground(new java.awt.Color(255, 255, 255));
        lbl_QuenMK.setText("Quên Mật Khẩu ");
        lbl_QuenMK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_QuenMKMouseClicked(evt);
            }
        });
        getContentPane().add(lbl_QuenMK, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 200, 200, 30));

        BackGround_Login.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/background_Login_1.png"))); // NOI18N
        getContentPane().add(BackGround_Login, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 590, 300));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_CleanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_CleanActionPerformed
        int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to escape ?", "Exit program", JOptionPane.YES_NO_OPTION);
        if (kq == JOptionPane.YES_OPTION) {
            //            JOptionPane.showMessageDialog(this, "Escaped");
            System.exit(0);
        }
    }//GEN-LAST:event_btn_CleanActionPerformed

    private void btn_LoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LoginActionPerformed
        if (kiem_O_Nhap()) {
            try {
                if (vaiTrro() != null) {
                    Form_QLNH F = new Form_QLNH(vaiTrro());
                    JOptionPane.showMessageDialog(this, "Logged in successfully");
                    F.setVisible(true);
                    this.dispose();
                }
//                vaiTrro();
            } catch (Exception ex) {

            }
        }
//        QuenMatKhau a = new QuenMatKhau();
//       a.setVisible(true);
//       dispose();
    }//GEN-LAST:event_btn_LoginActionPerformed

    public String vaiTrro() throws Exception {
        Login_User_Pass tk = new Login_User_Pass();
        Login_UserName nd = tk.Check_Login(txt_Name.getText(), new String(txt_Pass.getPassword()));
        if (nd == null) {
            JOptionPane.showMessageDialog(this, "Tên Đăng nhập hoặc mật khẩu sai");
            return nd.getRole();
        } else {
            return nd.getRole();
        }
    }

    private void lbl_QuenMKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_QuenMKMouseClicked
        QuenMatKhau a = new QuenMatKhau();
        a.setVisible(true);
        dispose();
    }//GEN-LAST:event_lbl_QuenMKMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login_QLNH.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Login_QLNH dialog = new Login_QLNH(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackGround_Login;
    private javax.swing.JLabel Logo_Login;
    private javax.swing.JButton btn_Clean;
    private javax.swing.JButton btn_Login;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lbl_QuenMK;
    private javax.swing.JTextField txt_Name;
    private javax.swing.JPasswordField txt_Pass;
    // End of variables declaration//GEN-END:variables
}
