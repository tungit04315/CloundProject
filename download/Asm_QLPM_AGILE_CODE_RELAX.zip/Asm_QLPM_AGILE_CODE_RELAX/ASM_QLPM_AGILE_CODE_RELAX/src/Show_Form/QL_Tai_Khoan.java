/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package Show_Form;

import ThongTin_Login.Login_UserName;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QL_Tai_Khoan extends javax.swing.JDialog {

//    List<Login_UserName> list = new ArrayList<>();
    DefaultTableModel model;
    int index = -1;

    public QL_Tai_Khoan(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();

//        Load_Data();
        Du_Lieu_DATA();
        getALL();
        Open_DATA();
    }
    String user = "tung";
    String pass = "123";
    String url = "jdbc:sqlserver://localhost:1433;databaseName=QL_NhaHang;encrypt=true;trustServerCertificate=true";

    public List<Login_UserName> getALL() {
        List<Login_UserName> list = new ArrayList<>();

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            String sql = "select * from Login";
            ResultSet rs = st.executeQuery(sql);
            list.clear();
            while (rs.next()) {
                String TenDangNhap = rs.getString(1);
                String MatKhau = rs.getString(2);
                String VaiTro = rs.getString(3);
                String Email = rs.getString(4);
                list.add(new Login_UserName(TenDangNhap, MatKhau, VaiTro,Email));
            }
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return list;
    }

    public void Open_DATA() {
        try {

            Connection ct = DriverManager.getConnection(url, user, pass);

            PreparedStatement ps = (PreparedStatement) ct.prepareStatement("Select * from Login");

            ResultSet rs = (ResultSet) ps.executeQuery();
            model = (DefaultTableModel) tbl_QLTK.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("TenDangNhap"));
                v.add(rs.getString("MatKhau"));
                v.add(rs.getString("VaiTro"));
                v.add(rs.getString("Email"));
                model.addRow(v);

            }
            tbl_QLTK.setModel(model);

            ct.close();
//            JOptionPane.showMessageDialog(this, "Thành Công");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    public void Du_Lieu_DATA() {
//        list.add(new Login_UserName("admin", "123", true));
//        list.add(new Login_UserName("Lucas", "041001", true));
//        Load_Data();
    }

    public Login_UserName Read_Data() {
        Login_UserName u = new Login_UserName();

        u.setUser(txt_TenDangNhap.getText());
        u.setPass(txt_MatKhauDangNhap.getText());
        u.setRole(rdo_Chu.isSelected() ? "Nam" : "Nữ");
        u.setEmail(txt_Email.getText());
        return u;
    }

//    public void Load_Data() {
//
//        model = (DefaultTableModel) tbl_QLTK.getModel();
//        model.setRowCount(0);
//        for (Login_UserName l : list) {
//            model.addRow(new Object[]{l.getUser(), l.getPass(), l.getRole()});
//            tbl_QLTK.setModel(model);
//        }
//    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_TenDangNhap = new javax.swing.JTextField();
        txt_MatKhauDangNhap = new javax.swing.JTextField();
        btn_Luu = new javax.swing.JButton();
        btn_LamMoi = new javax.swing.JButton();
        btn_Tim = new javax.swing.JButton();
        rdo_Chu = new javax.swing.JRadioButton();
        rdo_NV = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        txt_Email = new javax.swing.JTextField();
        btn_Xoa = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_QLTK = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("QUẢN LÝ TÀI KHOẢN");

        jPanel1.setBackground(new java.awt.Color(255, 255, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "TÀI KHOẢN", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

        jLabel1.setText("Tên Đăng Nhập ");

        jLabel2.setText("Mật Khẩu");

        jLabel3.setText("Vai Trò");

        btn_Luu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/save.png"))); // NOI18N
        btn_Luu.setText("Lưu");
        btn_Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LuuActionPerformed(evt);
            }
        });

        btn_LamMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/new-document.png"))); // NOI18N
        btn_LamMoi.setText("Làm Mới");
        btn_LamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LamMoiActionPerformed(evt);
            }
        });

        btn_Tim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/search.png"))); // NOI18N
        btn_Tim.setText("Tìm Kiếm");
        btn_Tim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TimActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdo_Chu);
        rdo_Chu.setText("ADMIN");

        buttonGroup1.add(rdo_NV);
        rdo_NV.setText("Nhân Viên");

        jLabel4.setText("Email");

        btn_Xoa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/delete.png"))); // NOI18N
        btn_Xoa.setText("Xoá");
        btn_Xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_XoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(rdo_Chu, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(rdo_NV, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                        .addComponent(btn_Tim))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txt_Email, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_TenDangNhap, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                            .addComponent(txt_MatKhauDangNhap, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(53, 53, 53)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btn_LamMoi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_Luu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_Xoa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_TenDangNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_Luu))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txt_MatKhauDangNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btn_LamMoi)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3)
                        .addComponent(rdo_Chu)
                        .addComponent(rdo_NV))
                    .addComponent(btn_Tim))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(txt_Email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btn_Xoa)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        tbl_QLTK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Tên Đăng Nhập", "Mật Khẩu", "Vai Trò", "Email"
            }
        ));
        tbl_QLTK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_QLTKMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_QLTK);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_LamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LamMoiActionPerformed
        LamMoi();
        Open_DATA();
    }//GEN-LAST:event_btn_LamMoiActionPerformed

    private void LamMoi() {
        txt_TenDangNhap.setText("");
        txt_MatKhauDangNhap.setText("");
        txt_Email.setText("");
        rdo_Chu.setSelected(true);
    }

    public void Them_Data() {
        try {

            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "insert into Login values (?,?,?,?)";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_TenDangNhap.getText());
            st.setString(2, txt_MatKhauDangNhap.getText());
            String gt;
            if (rdo_Chu.isSelected() == true) {
                gt = "ADMIN";
            } else {
                gt = "Nhân Viên";
            }
            st.setString(3, gt);
            st.setString(4, txt_Email.getText());
            st.executeUpdate();
            JOptionPane.showMessageDialog(this, "Successful");
            ct.close();

            Open_DATA();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LuuActionPerformed
//        list.add(Read_Data());
//        Load_Data();
        Them_Data();
    }//GEN-LAST:event_btn_LuuActionPerformed

    private void tbl_QLTKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_QLTKMouseClicked
        Show_Text();
    }//GEN-LAST:event_tbl_QLTKMouseClicked

//    public Login_UserName Tim_User(String us) {
//        for (Login_UserName l : list) {
//            if (l.getUser().equalsIgnoreCase(us)) {
//                return l;
//            }
//        }
//        return null;
//    }
//    public void TimKiemTheoTen() {
//        if (Tim_User(txt_TenDangNhap.getText()) == null) {
//            JOptionPane.showMessageDialog(this, "Couldn't find employee by code");
//        } else {
//            hienThiLenForm(Tim_User(txt_TenDangNhap.getText()));
//        }
//    }
    public void timKiem() {
        if (txt_TenDangNhap.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter the username you want to find ? ");
            txt_TenDangNhap.requestFocus();
            return;
        }
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection ct = DriverManager.getConnection(url, user, pass);
            String sql = "select * from Login where TenDangNhap = ?";
            PreparedStatement st = ct.prepareStatement(sql);
            st.setString(1, txt_TenDangNhap.getText());
            ResultSet rs = (ResultSet) st.executeQuery();

            model = (DefaultTableModel) tbl_QLTK.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("TenDangNhap"));
                v.add(rs.getString("MatKhau"));
                v.add(rs.getString("VaiTro"));
                v.add(rs.getString("Email"));
                model.addRow(v);

            }
            tbl_QLTK.setModel(model);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    private void btn_TimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TimActionPerformed
//        TimKiemTheoTen();
        timKiem();
    }//GEN-LAST:event_btn_TimActionPerformed

    public void Xoa_TK() {
        if (txt_TenDangNhap.getText().equalsIgnoreCase("")) {
            JOptionPane.showMessageDialog(this, "Enter username code");
            txt_TenDangNhap.requestFocus();
            return;
        }
        try {
            int kq = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ?", "Delete account", JOptionPane.YES_NO_OPTION);
            if (kq == JOptionPane.YES_OPTION) {
                int row = 0;
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
                Connection ct = DriverManager.getConnection(url, user, pass);
                String sql = "delete from Login where TenDangNhap = ?";
                PreparedStatement st = ct.prepareStatement(sql);
                st.setString(1, txt_TenDangNhap.getText());
                st.executeUpdate();
                if (row >= 0) {
                    JOptionPane.showMessageDialog(this, "Delete account Successful");
                } else {
                    JOptionPane.showMessageDialog(this, "Delete Staff Unsuccessful");
                }
                ct.close();
                getALL();
                Open_DATA();
                LamMoi();
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Can't delete employee information because employee information still exists on the payroll !!!"); 
        }
    }
    
    private void btn_XoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_XoaActionPerformed
       Xoa_TK();
    }//GEN-LAST:event_btn_XoaActionPerformed

    public void Show_Text() {
        try {
            int index = tbl_QLTK.getSelectedRow();
            txt_TenDangNhap.setText(tbl_QLTK.getValueAt(index, 0).toString());
            txt_MatKhauDangNhap.setText(tbl_QLTK.getValueAt(index, 1).toString());
            if (tbl_QLTK.getValueAt(index, 2).equals("ADMIN")) {
                rdo_Chu.setSelected(true);
            } else {
                rdo_NV.setSelected(true);
            }
            txt_Email.setText(tbl_QLTK.getValueAt(index, 3).toString());
        } catch (ArrayIndexOutOfBoundsException e) {

        }

    }

    public void hienThiLenForm(Login_UserName u) {
        txt_TenDangNhap.setText(u.getUser());
        txt_MatKhauDangNhap.setText(u.getPass());
//        if (u.getRole()) {
//            rdo_Chu.setSelected(true);
//        } else {
//            rdo_NV.setSelected(true);
//        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QL_Tai_Khoan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QL_Tai_Khoan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QL_Tai_Khoan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QL_Tai_Khoan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QL_Tai_Khoan dialog = new QL_Tai_Khoan(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_LamMoi;
    private javax.swing.JButton btn_Luu;
    private javax.swing.JButton btn_Tim;
    private javax.swing.JButton btn_Xoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rdo_Chu;
    private javax.swing.JRadioButton rdo_NV;
    private javax.swing.JTable tbl_QLTK;
    private javax.swing.JTextField txt_Email;
    private javax.swing.JTextField txt_MatKhauDangNhap;
    private javax.swing.JTextField txt_TenDangNhap;
    // End of variables declaration//GEN-END:variables
}
