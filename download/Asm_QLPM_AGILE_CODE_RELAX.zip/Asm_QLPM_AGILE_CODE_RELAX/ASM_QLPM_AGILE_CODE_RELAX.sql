﻿create database QL_NhaHang;

use QL_NhaHang;

-- bảng login

drop table Login
--1
create table Login(
	TenDangNhap nvarchar(30) primary key,
	MatKhau nvarchar(30),
	VaiTro nvarchar(15),
	Email varchar(30)
)

--drop table NhanVien
-- bang nhan vien
--2
create table NhanVien(
	MaNV nvarchar(9) primary key,
	HoTen nvarchar(25),
	VaiTro nvarchar(20),
	Sdt varchar(11),
	GioiTinh nvarchar(5),
	ViTri nvarchar(20),
	HinhAnh nvarchar(15)
)

drop table Menu

-- drop table Menu
-- bang menu 3
create table Menu(
     MaMon nvarchar(15) primary key,
	 TenMon nvarchar(30),
	 DonGia float
)

select * from Mon_Order

delete from Mon_Order where Ma_Order = '1'

drop table Mon_Order

--alter table Menu
--add 
-- bang mon order ban an
create table Mon_Order(
     TenBan nvarchar(15),
	 MaMon nvarchar(15),
	 TenMon nvarchar(30),
	 DonGia float
 )

 -- bang tam 4

 create table Bang_Tam(
     TenBan nvarchar(15),
	 MaMon nvarchar(15)
 )

 -- bang hoa don 5
 create table HoaDon(
    SoTT int identity(1,1) primary key,
    MaHoaDon varchar(30),
    TenBan nvarchar(15),
	
	MaMon nvarchar(15),
	SoLuong nvarchar(30),
	DonGia float,
	TongTien float,
	ThoiGian varchar(30)
 )
 select * from Bang_Tam
 select * from HoaDon
 drop table HoaDon
 delete from HoaDon 
 delete from Bang_Tam 
 alter table HoaDon add foreign key(Ma_Order) References Mon_Order(Ma_Order)  
 alter table HoaDon add foreign key(MaBanAn) References BanAn(MaBanAn)  
 alter table HoaDon add foreign key(MaMon) References Menu(MaMon)  
 alter table HoaDon add foreign key(MaNV) References NhanVien(MaNV) 

 Select MaHoaDon,TenBan,MaMon,SoLuong,DonGia,TongTien,ThoiGian from HoaDon where TenBan = 'bàn 1'
alter table LoaiMon add foreign key(MaLoaiMon) References Menu(MaMon)   

alter table BanAn add foreign key(MaMon) References Menu(MaMon) 

alter table Mon_Order add foreign key(MaNV) References NhanVien(MaNV) 
alter table Mon_Order add foreign key(MaBanAn) References BanAn(MaBanAn) 
alter table Bang_Tam add foreign key(MaMon) References Menu(MaMon) 

-- bang loai mon
create table LoaiMon(
	MaLoaiMon nvarchar(15) primary key,
	TenLoaiMon nvarchar(30)
)
-- bang ban an
create table BanAn(
	MaBanAn nvarchar(15),
	TenBan nvarchar(15),
	primary key(MaBanAn)
)
-- thêm dữ liệu phần login

select * from Login

Update Login set Email = 'tungtqpc04315@fpt.edu.vn'
Update Login set MatKhau = '123'
Update Login set TenDangNhap = 'admin'

insert into Login 
values(N'Admin',N'123',N'ADMIN','tungto753@gmail.com'),
      (N'Lucas',N'041001',N'Nhân Viên');

-- thêm dữ liệu vào bảng nhân viên
select * from NhanVien

insert into NhanVien 
values('NV01',N'Tô Quốc Tùng',N'Nhân Viên Phục Vụ','0838565542',N'Nam',N'Ngoài Quầy','No Avatar'),
	  ('NV02',N'Lê Thanh Tùng',N'Nhân Viên Pha Chế',0838565542,N'Nam',N'Ngoài Quầy','No Avatar'),
	  ('NV03',N'Nguyễn Thanh Tùng',N'Quản Lý',0838565542,N'Nam',N'Ngoài Quầy','No Avatar');

update NhanVien set ViTri = N'Trong Quầy' where MaNV = 'NV03'

-- thêm dữ liệu vào bảng menu
select * from Menu

insert into Menu 
values('MM01',N'Lẩu Hải Sản',120),
	  ('MM02',N'Lẩu Thái',135),
      ('MM03',N'Nướng Thịt Heo',120),
      ('MM04',N'Nước Coca',1,15),
      ('MM05',N'7 Up',1,12),
      ('MM06',N'Stting',1,15);

	  SELECT * FROM Menu ORDER BY MaMon DESC

-- thêm dữ liệu vào bảng bàn ăn 
select * from BanAn
select * from HoaDon
select * from Bang_Tam
delete Bang_Tam where TenBan = N'bàn 1';
insert into BanAn 
values ('B1',N'Bàn 1'),
	   ('B2',N'Bàn 2'),
	   ('B3',N'Bàn 3'),
	   ('B4',N'Bàn 4'),
	   ('B5',N'Bàn 5'),
	   ('B6',N'Bàn 6'),
	   ('B7',N'Bàn 7'),
	   ('B8',N'Bàn 8'),
	   ('B9',N'Bàn 9'),
	   ('B10',N'Bàn 10'),
	   ('B11',N'Bàn 11'),
	   ('B12',N'Bàn 12');

-- thêm dữ liệu vào bảng loại món
--select * from LoaiMon

--insert into LoaiMon
--values('ML1',N'Món Ăn'),
--       ('ML2',N'Đồ Uống');

select TenDangNhap, MatKhau , VaiTro from Login
               where TenDangNhap = 'Admin'  and MatKhau = '123'


use QLSV

select * from SinhVien_NEW
select * from ThongTin
delete from SinhVien where MASV = 'TTOQ'


create table Luong_NhanVien (
     Thang int null,
	 MaLuong nvarchar(30) primary key not null,
	 MaNV nvarchar(9) References NhanVien(MaNV) not null,
	 SoNgayLamViec int not null,
	 SoGioLamThem float not null,
	 TienThuong float not null,
	 TienPhuCap float not null,
	 TienUngTruoc float not null,
	 LuongCung float not null
)
select * from Bang_Tam
select Menu.MaMon, Menu.TenMon,  COUNT(TenBan) as N'SoLuong' ,Menu.DonGia from Bang_Tam, Menu 
where Menu.MaMon = Bang_Tam.MaMon 
Group by Menu.MaMon, Menu.TenMon, Menu.DonGia


delete from NhanVien where EXISTS (select * from Luong_NhanVien where Luong_NhanVien.MaNV = NhanVien.MaNV and Luong_NhanVien.MaNV = 'NV01' )
