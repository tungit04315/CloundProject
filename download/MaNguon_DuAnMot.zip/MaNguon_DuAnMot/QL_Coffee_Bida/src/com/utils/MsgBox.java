/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.utils;

import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author tungt
 */
public class MsgBox {

    // câu thông báo lỗi thường
    public static void alert(Component parent, String messager) {
        JOptionPane.showMessageDialog(parent, messager,
                "Quán Coffee Relax", JOptionPane.INFORMATION_MESSAGE);
    }

    // câu thông báo lỗi có lựa chọn
    public static boolean confirm(Component parent, String messager) {
        int kq = JOptionPane.showConfirmDialog(parent, messager,
                "Quán Coffee Relax", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return kq == JOptionPane.YES_OPTION;
    }

    public static int prompt(Component parent, String tenMon) {
        int kq = 0;
        while (true) {
            String a = JOptionPane.showInputDialog(parent, "Sản Phẩm Bạn Chọn Là: " + tenMon,
                    1);
            try {
                if (a == null) {
                    return 0;
                }
                kq = Integer.parseInt(a);
                if (kq > 0 || kq < 999) {
                    return kq;
                } else {
                    alert(parent, "Số phải lớn hơn không");
                }
            } catch (Exception e) {
                alert(parent, "Số lượng phải là số");
            }
        }
    }
}
