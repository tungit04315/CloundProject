/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.helper.JDBC;
import com.helper.ConnectionDatabase;
import com.utils.RandomSNN;
import com.utils.XEmail;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tungt
 */
public class PasswordDao {

    public boolean checkUser(String email) throws Exception {
        try {
            String sql = "select * from nhanvien where email like ?";
            Connection conn = ConnectionDatabase.openConn();
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
            }
            if (count == 1) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(PasswordDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updatePassword(String email) throws Exception {
        try {
            String sql = "update nhanvien set matKhau = ? where email like ?";
            Connection conn = ConnectionDatabase.openConn();
            PreparedStatement stmt = conn.prepareStatement(sql);
            String password = new RandomSNN().soNgauNhienString(7);
            stmt.setString(1, password);
            stmt.setString(2, email);

            XEmail e = new XEmail();
            e.sendEmail(email, password);
            return stmt.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(PasswordDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
