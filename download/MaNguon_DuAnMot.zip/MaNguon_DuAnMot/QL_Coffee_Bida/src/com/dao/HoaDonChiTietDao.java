/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.helper.JDBC;
import com.model.HoaDonChiTiet;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.util.Date;

/**
 *
 * @author tungt
 */
public class HoaDonChiTietDao extends EntityDao<HoaDonChiTiet, String> {

    String insert = "insert into ChiTietHoaDon values (?,?,?,?,?)";
    String select_byname = "select HoaDon.maHD,SanPham.loai, SanPham.tenSP, SanPham.gia, COUNT(SanPham.maSP) as 'SoLuong', SUM(SanPham.gia) as 'ThanhTien'\n"
            + "from Orders inner join SanPham on Orders.maMon = SanPham.maSP \n"
            + "inner join HoaDon on Orders.maBan = HoaDon.maBan\n"
            + "where Orders.maBan = ?\n"
            + "group by SanPham.loai, SanPham.tenSP, SanPham.gia,SanPham.maSP,HoaDon.maHD";
    String selectALL = "select b.maHD,b.ngayTao, a.maSP, SanPham.loai ,sum(a.soluong) as 'sl', a.thanhTien\n"
            + "from HoaDon b inner join ChiTietHoaDon a on a.maHD = b.maHD\n"
            + "inner join SanPham on a.maSP = SanPham.maSP\n"
            + "group by b.ngayTao , a.maSP,a.thanhTien ,a.soLuong,SanPham.loai,b.maHD";
    String selectTheoKhoang = "select b.maHD,b.ngayTao, a.maSP, SanPham.loai ,sum(a.soluong) as 'sl', a.thanhTien\n"
            + "            from HoaDon b inner join ChiTietHoaDon a on a.maHD = b.maHD\n"
            + "            inner join SanPham on a.maSP = SanPham.maSP\n"
            + "			where b.ngayTao between ? and ?\n"
            + "            group by b.ngayTao , a.maSP,a.thanhTien ,a.soLuong,SanPham.loai,b.maHD";

    @Override
    public void insert(HoaDonChiTiet entity) {
        JDBC.update(insert, entity.getMaHD(), entity.getMaSP(), entity.getGia(), entity.getSoLuong(), entity.getThanhTien());
    }

    @Override
    public void update(HoaDonChiTiet entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(String key) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<HoaDonChiTiet> selectAll() {
        return this.select_by_sql(selectALL);
    }

    @Override
    public HoaDonChiTiet select_byID(String key) {
        List<HoaDonChiTiet> list = this.select_by_sql(select_byname, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public List<HoaDonChiTiet> select_byID2(int key) {
        List<HoaDonChiTiet> list = this.select_by_sql(select_byname, key);
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }

    public List<HoaDonChiTiet> select_theoThoiGian(Date mot, Date hai) {
        List<HoaDonChiTiet> list = this.select_by_sql(selectTheoKhoang, mot, hai);
        if (list.isEmpty()) {
            return null;
        }
        return list;
    }

    public int getMaHDVuaThem() {
        int mahd = 0;
        ResultSet rs = JDBC.query("select top 1 maHD from hoadon order by maHD desc");
        try {
            while (rs.next()) {
                mahd = rs.getInt("maHD");
            }
            rs.getStatement().getConnection().close();
            return mahd;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    @Override
    protected List<HoaDonChiTiet> select_by_sql(String sql, Object... args) {
        List<HoaDonChiTiet> list = new ArrayList<>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                HoaDonChiTiet s = new HoaDonChiTiet();

                s.setMaHD(r.getInt("maHD"));
                s.setMaSP(r.getString("maSP"));
                s.setGia(r.getFloat("loai"));
                s.setSoLuong(r.getInt("sl"));
                s.setThanhTien(r.getFloat("ThanhTien"));

                list.add(s);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
