/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.model.LoaiSanPham;
import com.helper.JDBC;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class LoaiDao extends EntityDao<LoaiSanPham, String> {

    String insert = "insert into loainuoc values(?)";
    String update = "update loainuoc set tenloai = ? where maloai = ?";
    String delete = "delete loainuoc where maloai = ?";
    String select_ID = "select * from loainuoc where maLoai = ?";
    String selectAll = "select * from LoaiNuoc";
    String select_byname = "select * from loainuoc where tenloai like ?";

    @Override
    public void insert(LoaiSanPham entity) {
        JDBC.update(insert, entity.getTenSP());
    }

    @Override
    public void update(LoaiSanPham entity) {
        JDBC.update(update, entity.getTenSP(), entity.getMaSp());
    }

    @Override
    public void delete(String key) {
        JDBC.update(delete, key);
    }

    @Override
    public List<LoaiSanPham> selectAll() {
        return this.select_by_sql(selectAll);
    }

    @Override
    public LoaiSanPham select_byID(String key) {
        List<LoaiSanPham> list = this.select_by_sql(select_ID, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    protected List<LoaiSanPham> select_by_sql(String sql, Object... args) {
        List<LoaiSanPham> list = new ArrayList<LoaiSanPham>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                LoaiSanPham s = new LoaiSanPham();
                s.setMaSp(r.getInt("maLoai"));
                s.setTenSP(r.getString("tenLoai"));
                list.add(s);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    protected List<LoaiSanPham> select_by_sql2(String sql, Object... args) {
        List<LoaiSanPham> list = new ArrayList<LoaiSanPham>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                LoaiSanPham s = new LoaiSanPham();
                s.setTenSP(r.getString("tenLoai"));
                list.add(s);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<LoaiSanPham> searchLSP(String key) {
        return this.select_by_sql(select_byname, "%" + key + "%");
    }

//    public String searchTenSP(String key){
//        String sql = "select tenLoai from loainuoc inner join sanpham on loainuoc.maLoai = sanpham.loai where sanpham.loai = ?";
//        return this.select_by_sql(sql,  key);
//    }
//    
    public String toTenLoai(int ma) {
        String sql = "select tenLoai from loaiNuoc where maLoai = ?";
        String name;
        ResultSet rs = JDBC.query(sql, ma);
        List<String> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getString("tenLoai"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    public int toMaLoai(String ten) {
        String sql = "select maLoai from loaiNuoc where tenLoai like ?";
//        String name;
        ResultSet rs = JDBC.query(sql, "%" + ten + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getInt("maLoai"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
}
