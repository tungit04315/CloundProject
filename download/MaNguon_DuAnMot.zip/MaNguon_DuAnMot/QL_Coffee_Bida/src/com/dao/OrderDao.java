/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.model.Order;
import com.model.SanPham;
import com.helper.JDBC;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class OrderDao extends EntityDao<Order, String> {

    String insert = "insert into Orders values(?,?,?)";
    String update = "update Orders set maBan = ? where maBan = ?";
    String delete = "delete Orders where maOrder in( select top (?) maOrder from Orders where maMon like ?)";
    String select_byid = "select maBan from ban where tenBan like ?";
    String select_byidmon = "select maSP from sanpham where tenSP like ?";
    String sql_soLuongSP = "select mamon,COUNT(maMon) as sl  from Orders where maMon = ? and maBan=? group by maMon";
    String deleleOR = "delete Orders where maBan = ?";

    @Override
    public void insert(Order entity) {
        JDBC.update(insert, entity.getMaBan(), entity.getMaMon(), entity.getMaNV());
    }

    @Override
    public void update(Order entity) {
        JDBC.update(update, entity.getMaBan(), entity.getMaBan());
    }

    public void update2(int maBan1, int maBan2) {
        JDBC.update(update, maBan1, maBan2);
    }

    @Override
    public void delete(String key) {
        JDBC.update(deleleOR, key);
    }

    public void delete2(int SoLuong, String key) {
        JDBC.update(delete, SoLuong, key);
    }

    @Override
    public List<Order> selectAll() {
        return this.select_by_sql("select * from Orders where maBan = ?");
    }

    public List<Order> selectAll2(int maBan) {
        return this.select_by_sql("select * from Orders where maBan = ?", maBan);

    }

    @Override
    public Order select_byID(String key) {
        return null;
    }

    @Override
    protected List<Order> select_by_sql(String sql, Object... args) {
        List<Order> list = new ArrayList<>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                Order s = new Order();
                s.setMaOrder(r.getInt("maOrder"));
                s.setMaBan(r.getInt("maBan"));
                s.setMaMon(r.getString("maMon"));

                s.setMaNV(r.getString("maNV"));
                list.add(s);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public int toMaOrder(String maSP) {
        String sql = "select top 1 maOrder from Orders where maMon like ?";
        ResultSet rs = JDBC.query(sql, "%" + maSP + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getInt("maBan"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    public int toMaBan(String tenBan) {
        String sql = "select maBan from ban where tenBan like ?";
        ResultSet rs = JDBC.query(sql, "%" + tenBan + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getInt("maBan"));
            }
            return list.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public String toMaMon(String tenMon) {
        String sql = "select maSP from sanpham where tenSP like ?";
        ResultSet rs = JDBC.query(sql, "%" + tenMon + "%");
        List<String> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getString("maSP"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    public int timMaBan(int maBan) {
        String sql = "select maBan from ban where maBan = ?";
        ResultSet rs = JDBC.query(sql, maBan);
        List<Integer> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getInt("maBan"));
            }
            return list.get(0);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();

        }
    }

    public int soLuongMon(String maSP, int maBan) {
        ResultSet rs = JDBC.query(sql_soLuongSP, maSP, maBan);
        int soLuong = 0;
        try {
            while (rs.next()) {
                soLuong = rs.getInt("sl");
            }
            rs.getStatement().getConnection().close();
            return soLuong;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }
}
