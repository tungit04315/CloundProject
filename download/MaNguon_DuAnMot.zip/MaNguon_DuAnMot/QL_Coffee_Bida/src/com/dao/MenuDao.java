/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.model.SanPham;
import com.helper.JDBC;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class MenuDao extends EntityDao<SanPham, String> {

    String insert = "insert into sanpham values (?,?,?,?,?)";
    String updata = "update sanpham set tenSP = ?, loai = ?, gia = ?"
            + ",hinhAnh = ? where maSP = ?";
    String delete = "delete sanpham where maSP = ?";
    String selectAll = "select * from sanpham";
    String select_byID = "select * from sanpham where maSP = ?";
    String select_byname = "select * from sanpham where tenSP like ?";

    @Override
    public void insert(SanPham entity) {
        JDBC.update(insert, entity.getMaSP(), entity.getTenSP(),
                entity.getLoai(), entity.getGia(), entity.getHinhAnh());
    }

    @Override
    public void update(SanPham entity) {
        JDBC.update(updata, entity.getTenSP(),
                entity.getLoai(), entity.getGia(), entity.getHinhAnh(), entity.getMaSP());
    }

    @Override
    public void delete(String key) {
        JDBC.update(delete, key);
    }

    @Override
    public List<SanPham> selectAll() {
        return select_by_sql(selectAll);
    }

    @Override
    public SanPham select_byID(String key) {
        List<SanPham> list = this.select_by_sql(select_byID, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public SanPham select_byname(String key) {
        List<SanPham> list = this.select_by_sql(select_byname, key);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

//    public SanPham selectAll_byname(int key) {
//        List<SanPham> list = this.select_by_sql(selectAllname, key);
//        if (list.isEmpty()) {
//            return null;
//        }
//        return list.get(0);
//    }
    @Override
    protected List<SanPham> select_by_sql(String sql, Object... args) {
        List<SanPham> list = new ArrayList<>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                SanPham s = new SanPham();
                s.setMaSP(r.getString("maSP"));
                s.setTenSP(r.getString("tenSP"));
                s.setLoai(r.getInt("loai"));
                s.setGia(r.getFloat("gia"));
                s.setHinhAnh(r.getString("hinhAnh"));
                list.add(s);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String toMaMon(String tenMon) {
        String sql = "select maSP from sanpham where tenSP like ?";
        ResultSet rs = JDBC.query(sql, "%" + tenMon + "%");
        List<String> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getString("maSP"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    
    public String toTenMon(String maMon) {
        String sql = "select tenSP from sanpham where maSP like ?";
        ResultSet rs = JDBC.query(sql, "%" + maMon + "%");
        List<String> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getString("tenSP"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    

    public int toMaLoai(String maSP) {
        String sql = "select loai from sanpham where maSP like ?";
        ResultSet r = JDBC.query(sql, "%" + maSP + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (r.next()) {
                list.add(r.getInt("loai"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
  public float togia(String maSP) {
        String sql = "select gia from sanpham where maSP like ?";
        ResultSet r = JDBC.query(sql, "%" + maSP + "%");
        List<Float> list = new ArrayList<>();
        try {
            while (r.next()) {
                list.add(r.getFloat("gia"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }
    public List<SanPham> searchSP(String key) {
        return this.select_by_sql(select_byname, "%" + key + "%");
    }

    public List<SanPham> searchLSP(String key) {
        return this.select_by_sql(select_byname, "%" + key + "%");
    }

    public List<SanPham> searchTenSP(String key) {
        String sql = "select tenLoai from loainuoc inner join sanpham on loainuoc.maLoai = sanpham.loai where sanpham.loai = ?";
        return this.select_by_sql(sql, "%" + key + "%");
    }

    public List<SanPham> selectMaLoai(int maLoai) {
        String sql = "select * from sanpham where loai = ?";
        return this.select_by_sql(sql, maLoai);
    }
//    public String selectNameSP(String key) {
//        String sql = "select loai from sanpham where maSP = ?";
//        List<SanPham> list = select_by_sql(sql, key);
//        return;
//    }
}
