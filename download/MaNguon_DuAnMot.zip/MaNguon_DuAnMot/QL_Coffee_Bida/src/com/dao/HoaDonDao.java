/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.helper.JDBC;
import com.model.HoaDon;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author tungt
 */
public class HoaDonDao extends EntityDao<HoaDon, String> {

    String insert = "insert into hoadon values (?,?,?)";

    @Override
    public void insert(HoaDon entity) {
        JDBC.update(insert, entity.getMaBan(), entity.getNgayTao(), entity.getMaNV());
    }

    @Override
    public void update(HoaDon entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(String key) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<HoaDon> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public HoaDon select_byID(String key) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected List<HoaDon> select_by_sql(String sql, Object... args) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int toMaOrder(String maSP) {
        String sql = "select maOrder from Orders where maMon like ?";
        ResultSet rs = JDBC.query(sql, "%" + maSP + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getInt("maBan"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

    public Date toNgay(int maHD) {
        String sql = "select ngayTao from hoadon where maHD = ?";
        ResultSet rs = JDBC.query(sql, maHD);
        List<Date> list = new ArrayList<>();
        try {
            while (rs.next()) {
                list.add(rs.getDate("ngayTao"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

}
