/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.dao;

import com.helper.JDBC;
import com.model.Ban;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author tungt
 */
public class BanDao extends EntityDao<Ban, String> {

    String selectAll = "select * from ban";
    String selectAll2 = "select * from ban where tenBan not in (select tenBan from ban where tenBan like ?)";
    String updateBanOrders = "update orders set maBan =? where maBan=? ";
    String sql_maOrder = "select top 1 maOrder from Orders where maMon =? and maBan =? order by maOrder desc";
    String sql_TachBan = "update orders set maBan =? where maOrder=?";
    @Override
    public void insert(Ban entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Ban entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete(String key) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Ban> selectAll() {
        return this.select_by_sql(selectAll);
    }

    public List<Ban> selectAll2(String key) {
        return this.select_by_sql(selectAll2, key);
    }

    @Override
    public Ban select_byID(String key) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    protected List<Ban> select_by_sql(String sql, Object... args) {
        List<Ban> list = new ArrayList<Ban>();
        try {
            ResultSet r = JDBC.query(sql, args);
            while (r.next()) {
                Ban b = new Ban();
                b.setMaBan(r.getInt("maBan"));
                b.setTenBan(r.getString("tenBan"));
                list.add(b);
            }
            r.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
    public void chuyenBan(int maCu, int maMoi){
        JDBC.update(updateBanOrders, maMoi, maCu);
    }
    
    public void tachBan(int maBan, int maOrder){
        JDBC.update(sql_TachBan, maBan, maOrder);
    }
    
    public int toMaOrder(String maSP, int maBan){
        ResultSet rs = JDBC.query(sql_maOrder, maSP, maBan);
        int ma = -1;
        try {
            while(rs.next()){
                ma = rs.getInt("maOrder");
            }
            rs.getStatement().getConnection().close();
            return ma;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
    }

    public int toMaBan(String key) {
        String sql = "select maBan from ban where tenBan like ?";
        ResultSet r = JDBC.query(sql, "%" + key + "%");
        List<Integer> list = new ArrayList<>();
        try {
            while (r.next()) {
                list.add(r.getInt("maBan"));
            }
            return list.get(0);
        } catch (Exception e) {
            throw new RuntimeException();
        }
    }

}
