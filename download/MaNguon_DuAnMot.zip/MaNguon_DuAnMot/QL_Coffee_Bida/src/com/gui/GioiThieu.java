/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.utils.Ximg;
import java.awt.Color;

/**
 *
 * @author tungt
 */
public class GioiThieu extends javax.swing.JDialog {

    /**
     * Creates new form GioiThieu
     */
    public GioiThieu(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setIconImage(Ximg.getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblHome = new javax.swing.JLabel();
        lblVePhanMem = new javax.swing.JLabel();
        lblQuanLyNhanVien = new javax.swing.JLabel();
        lblQuanLySanPham = new javax.swing.JLabel();
        lblQuanLyGoiMon = new javax.swing.JLabel();
        lblThongKe = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblXemThem = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lblHinhNen = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Giới Thiệu");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("COFFEE RELAX");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("NƠI KHÔNG GIAN LÝ TƯỞNG CỦA BẠN");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 100, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/LogoGioiThieu.png"))); // NOI18N
        jLabel9.setText("jLabel9");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 130, 120));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));

        lblHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/home.png"))); // NOI18N
        lblHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHomeMouseClicked(evt);
            }
        });

        lblVePhanMem.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVePhanMem.setForeground(new java.awt.Color(255, 255, 255));
        lblVePhanMem.setText("VỀ PHẦN MỀM");
        lblVePhanMem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblVePhanMemMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblVePhanMemMouseExited(evt);
            }
        });

        lblQuanLyNhanVien.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblQuanLyNhanVien.setForeground(new java.awt.Color(255, 255, 255));
        lblQuanLyNhanVien.setText("QUẢN LÝ NHÂN VIÊN");
        lblQuanLyNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblQuanLyNhanVienMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblQuanLyNhanVienMouseExited(evt);
            }
        });

        lblQuanLySanPham.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblQuanLySanPham.setForeground(new java.awt.Color(255, 255, 255));
        lblQuanLySanPham.setText("QUẢN LÝ SẢN PHẨM");
        lblQuanLySanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblQuanLySanPhamMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblQuanLySanPhamMouseExited(evt);
            }
        });

        lblQuanLyGoiMon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblQuanLyGoiMon.setForeground(new java.awt.Color(255, 255, 255));
        lblQuanLyGoiMon.setText("QUẢN LÝ GỌI MÓN");
        lblQuanLyGoiMon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblQuanLyGoiMonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblQuanLyGoiMonMouseExited(evt);
            }
        });

        lblThongKe.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblThongKe.setForeground(new java.awt.Color(255, 255, 255));
        lblThongKe.setText("QUẢN LÝ THỐNG KÊ");
        lblThongKe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblThongKeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblThongKeMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblHome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblVePhanMem)
                .addGap(18, 18, 18)
                .addComponent(lblQuanLyNhanVien)
                .addGap(18, 18, 18)
                .addComponent(lblQuanLySanPham)
                .addGap(18, 18, 18)
                .addComponent(lblQuanLyGoiMon)
                .addGap(18, 18, 18)
                .addComponent(lblThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblVePhanMem)
                    .addComponent(lblQuanLyNhanVien)
                    .addComponent(lblQuanLySanPham)
                    .addComponent(lblQuanLyGoiMon)
                    .addComponent(lblThongKe))
                .addGap(21, 21, 21))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 150, 730, 60));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/guiphanhoi.png"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 450, 100, -1));

        lblXemThem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/xemthem.png"))); // NOI18N
        lblXemThem.setText("jLabel10");
        getContentPane().add(lblXemThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 390, 150, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Serif", 3, 14)); // NOI18N
        jLabel4.setText("KHƠI NGUỒN CẢM XÚC");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        jLabel5.setText("Trân trọng những hạt cà phê được lựa chọn tỷ mỹ cẩn thận từ ");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        jLabel6.setText("chính tay chủ quán. Và rất chỉnh chu trong từng công đoạn ");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        jLabel7.setText("rang - xay để có thể làm ra những tách cà phê có hương vị tuyệt");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        jLabel8.setText("vời đến cho khách hàng. ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 360, 150));

        lblHinhNen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/Nen_GioiThieu.png"))); // NOI18N
        getContentPane().add(lblHinhNen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblVePhanMemMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVePhanMemMouseEntered
        lblVePhanMem.setForeground(Color.red);
    }//GEN-LAST:event_lblVePhanMemMouseEntered
//Trân trọng những hạt cà phê được lựa chọn tỷ mỹ cẩn thận từ 
//chính tay chủ quán. Và rất chỉnh chu trong từng công đoạn 
//rang - xay để có thể làm ra những tách cà phê có hương vị tuyệt
//vời đến cho khách hàng. 
    private void lblVePhanMemMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblVePhanMemMouseExited
        lblVePhanMem.setForeground(Color.white);
    }//GEN-LAST:event_lblVePhanMemMouseExited

    private void lblQuanLyNhanVienMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLyNhanVienMouseEntered
        lblQuanLyNhanVien.setForeground(Color.red);
    }//GEN-LAST:event_lblQuanLyNhanVienMouseEntered

    private void lblQuanLyNhanVienMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLyNhanVienMouseExited
        lblQuanLyNhanVien.setForeground(Color.white);
    }//GEN-LAST:event_lblQuanLyNhanVienMouseExited

    private void lblQuanLySanPhamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLySanPhamMouseEntered
        lblQuanLySanPham.setForeground(Color.red);
    }//GEN-LAST:event_lblQuanLySanPhamMouseEntered

    private void lblQuanLySanPhamMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLySanPhamMouseExited
        lblQuanLySanPham.setForeground(Color.white);
    }//GEN-LAST:event_lblQuanLySanPhamMouseExited

    private void lblQuanLyGoiMonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLyGoiMonMouseEntered
        lblQuanLyGoiMon.setForeground(Color.red);
    }//GEN-LAST:event_lblQuanLyGoiMonMouseEntered

    private void lblQuanLyGoiMonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblQuanLyGoiMonMouseExited
        lblQuanLyGoiMon.setForeground(Color.white);
    }//GEN-LAST:event_lblQuanLyGoiMonMouseExited

    private void lblThongKeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThongKeMouseEntered
        lblThongKe.setForeground(Color.red);
    }//GEN-LAST:event_lblThongKeMouseEntered

    private void lblThongKeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblThongKeMouseExited
        lblThongKe.setForeground(Color.white);
    }//GEN-LAST:event_lblThongKeMouseExited

    private void lblHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHomeMouseClicked
        CuaSoChinh a = new CuaSoChinh();
        a.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_lblHomeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GioiThieu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GioiThieu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GioiThieu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GioiThieu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                GioiThieu dialog = new GioiThieu(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblHinhNen;
    private javax.swing.JLabel lblHome;
    private javax.swing.JLabel lblQuanLyGoiMon;
    private javax.swing.JLabel lblQuanLyNhanVien;
    private javax.swing.JLabel lblQuanLySanPham;
    private javax.swing.JLabel lblThongKe;
    private javax.swing.JLabel lblVePhanMem;
    private javax.swing.JLabel lblXemThem;
    // End of variables declaration//GEN-END:variables
}
