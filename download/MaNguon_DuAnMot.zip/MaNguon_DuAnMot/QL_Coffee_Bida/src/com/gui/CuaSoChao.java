/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.utils.Ximg;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/**
 *
 * @author tungt
 */
public class CuaSoChao extends javax.swing.JDialog {

    /**
     * Creates new form Hi_Interface
     */
    public CuaSoChao(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setIconImage(Ximg.getImage());
//        run_coffee();
        run_ThanhTienTrinh();

    }

    void run_coffee() {
        new Timer(-40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = lbl_icon_TienTrinh.getX();
                int y = lbl_icon_TienTrinh.getY();

                if (x == 800) {
                    x = 1200;
                } else {
                    x++;
                }

                lbl_icon_TienTrinh.setLocation(x, y);
            }
        }).start();
    }

    void run_ThanhTienTrinh() {
        new Timer(40, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = pgb_tienTrinh.getValue();

                if (x == 10) {
                    lblThongBaoTienTrinh.setText("Khởi Động...");
                }
                if (x == 20) {
                    lblThongBaoTienTrinh.setText("Đang Kết Nối Phần Mềm...");
                }
                if (x == 40) {
                    lblThongBaoTienTrinh.setText("Đang Kết Nối Với Dữ Liệu...");
                }
                if (x == 70) {
                    lblThongBaoTienTrinh.setText("Kết Nối Dữ Liệu Thành Công...");
                }
                if (x == 90) {
                    lblThongBaoTienTrinh.setText("Đang Khởi Động Phần Mềm...");
                }
                if (x < pgb_tienTrinh.getMaximum()) {
                    x++;
                    pgb_tienTrinh.setValue(x);
//                    lblPhanTram.setText(x + "%");
                } else {
                    dispose();
                }
            }
        }).start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblThongBaoTienTrinh = new javax.swing.JLabel();
        lbl_icon_TienTrinh = new javax.swing.JLabel();
        lbl_Logo = new javax.swing.JLabel();
        pgb_tienTrinh = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setForeground(new java.awt.Color(85, 60, 60));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblThongBaoTienTrinh.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblThongBaoTienTrinh.setForeground(new java.awt.Color(255, 255, 255));
        lblThongBaoTienTrinh.setText("Loading......");
        getContentPane().add(lblThongBaoTienTrinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 575, -1, 20));

        lbl_icon_TienTrinh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icon_TienTrinh.png"))); // NOI18N
        lbl_icon_TienTrinh.setText("jLabel1");
        getContentPane().add(lbl_icon_TienTrinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 570, 40, 30));

        lbl_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/Logo_hi.gif"))); // NOI18N
        getContentPane().add(lbl_Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, -1));

        pgb_tienTrinh.setBackground(new java.awt.Color(204, 166, 114));
        pgb_tienTrinh.setForeground(new java.awt.Color(204, 166, 114));
        pgb_tienTrinh.setStringPainted(true);
        getContentPane().add(pgb_tienTrinh, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 600, 750, 30));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CuaSoChao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CuaSoChao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CuaSoChao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CuaSoChao.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CuaSoChao dialog = new CuaSoChao(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lblThongBaoTienTrinh;
    private javax.swing.JLabel lbl_Logo;
    private javax.swing.JLabel lbl_icon_TienTrinh;
    private javax.swing.JProgressBar pgb_tienTrinh;
    // End of variables declaration//GEN-END:variables
}
