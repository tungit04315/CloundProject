/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.PasswordDao;
import com.utils.MsgBox;
import com.utils.RandomSNN;
import com.utils.Ximg;
import java.awt.Color;
import java.awt.Font;
import java.util.ServiceConfigurationError;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author tungt
 */
public class QuenMatKhau extends javax.swing.JDialog {

    /**
     * Creates new form Forgot_Password_Interface
     */
    public QuenMatKhau(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
    }

    void init() {
        this.setIconImage(Ximg.getImage());
        hienThiGoiY();
        maCapcha();
    }

    public void hienThiGoiY() {
        txt_email.setText("Email...");
        txt_email.setForeground(Color.gray);
        txt_capcha.setText("Capcha...");
        txt_capcha.setForeground(Color.gray);
        txt_maCapcha.setEditable(false);
        txt_maCapcha.requestFocus();
    }

    boolean kiemTraLoi() {

        if (txt_email.getText().equalsIgnoreCase("email...")) {
            txt_email.requestFocus();
            MsgBox.alert(this, "Không để trống Email");
            return false;
        }
        if (txt_capcha.getText().equalsIgnoreCase("capcha...")) {
            txt_capcha.requestFocus();
            MsgBox.alert(this, "Không để trống Capcha");
            return false;
        }
        if (txt_email.getText().equalsIgnoreCase("")) {
            txt_email.requestFocus();
            MsgBox.alert(this, "Không để trống Email");
            return false;
        }
        if (txt_capcha.getText().equalsIgnoreCase("")) {
            txt_capcha.requestFocus();
            MsgBox.alert(this, "Không để trống Capcha");
            return false;
        }

        if (!txt_capcha.getText().equalsIgnoreCase(txt_maCapcha.getText())) {
            txt_capcha.requestFocus();
            MsgBox.alert(this, "Mã capcha không khớp");
            maCapcha();
            return false;
        }
        return true;
    }

    void maCapcha() {
        String capcha = new RandomSNN().soNgauNhienString(5);
        txt_maCapcha.setText(capcha);
        txt_maCapcha.setFont(new Font(capcha, Font.HANGING_BASELINE, 14));
    }

    void lamMoi() {
//        txt_email.setText("");
//        txt_capcha.setText("");
        hienThiGoiY();
        maCapcha();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        txt_capcha = new javax.swing.JTextField();
        txt_maCapcha = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        btn_gui = new javax.swing.JButton();
        btn_troVe = new javax.swing.JButton();
        lbl_background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quên Mật Khẩu\n\n");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Quên Mật Khẩu ?");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 100, -1, -1));

        txt_email.setBorder(null);
        txt_email.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_emailFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_emailFocusLost(evt);
            }
        });
        txt_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_emailActionPerformed(evt);
            }
        });
        getContentPane().add(txt_email, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 290, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 290, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 290, 3));

        txt_capcha.setBorder(null);
        txt_capcha.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_capchaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_capchaFocusLost(evt);
            }
        });
        getContentPane().add(txt_capcha, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 170, -1));
        getContentPane().add(txt_maCapcha, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 200, 110, -1));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 170, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 220, 170, 3));

        btn_gui.setBackground(new java.awt.Color(255, 255, 255));
        btn_gui.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/send.png"))); // NOI18N
        btn_gui.setText("Gửi");
        btn_gui.setMaximumSize(new java.awt.Dimension(91, 33));
        btn_gui.setMinimumSize(new java.awt.Dimension(91, 33));
        btn_gui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guiActionPerformed(evt);
            }
        });
        getContentPane().add(btn_gui, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 240, 90, 30));

        btn_troVe.setBackground(new java.awt.Color(255, 255, 255));
        btn_troVe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/back.png"))); // NOI18N
        btn_troVe.setText("Trở về");
        btn_troVe.setBorderPainted(false);
        btn_troVe.setMargin(new java.awt.Insets(2, 2, 4, 2));
        btn_troVe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_troVeActionPerformed(evt);
            }
        });
        getContentPane().add(btn_troVe, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 70, 30));

        lbl_background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/padlock.png"))); // NOI18N
        getContentPane().add(lbl_background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 310));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_emailFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusGained

        if (txt_email.getText().equalsIgnoreCase("Email...")) {
            txt_email.setText("");
            txt_email.setForeground(Color.black);
        }
    }//GEN-LAST:event_txt_emailFocusGained

    private void txt_emailFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_emailFocusLost
        if (txt_email.getText().equalsIgnoreCase("")) {
            txt_email.setText("Email...");
            txt_email.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txt_emailFocusLost

    private void txt_capchaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_capchaFocusGained
        if (txt_capcha.getText().equalsIgnoreCase("Capcha...")) {
            txt_capcha.setText("");
            txt_capcha.setForeground(Color.black);
        }
    }//GEN-LAST:event_txt_capchaFocusGained

    private void txt_capchaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_capchaFocusLost
        if (txt_capcha.getText().equalsIgnoreCase("")) {
            txt_capcha.setText("Capcha...");
            txt_capcha.setForeground(Color.gray);
        }
    }//GEN-LAST:event_txt_capchaFocusLost

    private void btn_troVeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_troVeActionPerformed
        this.dispose();
        CuaSoDangNhap a = new CuaSoDangNhap(null, true, false);
        a.setVisible(true);
    }//GEN-LAST:event_btn_troVeActionPerformed

    private void btn_guiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guiActionPerformed
        if (kiemTraLoi()) {
            PasswordDao g = new PasswordDao();
            try {
                if (g.checkUser(txt_email.getText())) {
                    g.updatePassword(txt_email.getText());
                    lamMoi();
                    return;
                }

                MsgBox.alert(this, "Gửi yêu cầu thất bại");
                lamMoi();
                return;
            } catch (Exception ex) {
//                System.out.println(ex);
                Logger.getLogger(QuenMatKhau.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ServiceConfigurationError x) {
                System.out.println(x);
            }
        }
    }//GEN-LAST:event_btn_guiActionPerformed

    private void txt_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_emailActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuenMatKhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuenMatKhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuenMatKhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuenMatKhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuenMatKhau dialog = new QuenMatKhau(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_gui;
    private javax.swing.JButton btn_troVe;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbl_background;
    private javax.swing.JTextField txt_capcha;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_maCapcha;
    // End of variables declaration//GEN-END:variables
}
