/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.LoaiDao;
import com.dao.MenuDao;
import com.model.LoaiSanPham;
import com.model.SanPham;
import com.utils.MsgBox;
import com.utils.Ximg;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.File;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QuanLySanPham extends javax.swing.JDialog {

    /**
     * Creates new form Menu_Management_Interface
     */
    MenuDao dao = new MenuDao();
    int index = -1;

    int maLoai = 0;

    public QuanLySanPham(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
        goiYTimKiem(txt_timMon);
    }

    void init() {
        this.setIconImage(Ximg.getImage());
        fill_combo_Box();
        fill_tblSP();

        index = -1;
        trangThaiCacNut();

    }

    void goiYTimKiem(JTextField txt) {
        txt.setText("Tìm theo tên sản phẩm...");
        txt.setForeground(Color.GRAY);
        txt.setFont(new Font(txt_timMon.getText(), Font.HANGING_BASELINE, 11));
    }

    void xoaGoiYTimKiem(JTextField txt) {
        txt.setText("");
        txt.setForeground(Color.BLACK);
    }

    boolean kiemTraLoi() {

        if (txt_maMon.getText().equalsIgnoreCase("")) {
            txt_maMon.requestFocus();
            MsgBox.alert(this, "Không để trống mã sản phẩm");
            return false;
        }
        if (txt_tenMon.getText().equalsIgnoreCase("")) {
            txt_tenMon.requestFocus();
            MsgBox.alert(this, "Không để trống tên sản phẩm");
            return false;
        }

        if (txt_gia.getText().equalsIgnoreCase("")) {
            txt_gia.requestFocus();
            MsgBox.alert(this, "Không để trống giá sản phẩm");
            return false;
        }

        try {
            float donGia = Float.parseFloat(txt_gia.getText());
            if (donGia <= 0) {
                txt_gia.requestFocus();
                MsgBox.alert(this, "Đơn giá sản phẩm không được phép âm");
                return false;
            }
        } catch (NumberFormatException e) {
            txt_gia.requestFocus();
            MsgBox.alert(this, "Đơn giá sản phẩm không được phép nhập chữ");
            return false;
        }
//        if (lbl_hinhAnh.getText().equalsIgnoreCase("Ảnh Sản Phẩm")) {
//            lbl_hinhAnh.requestFocus();
//            MsgBox.alert(this, "Bạn chưa chọn ảnh sản phẩm");
//            return false;
//        }
        return true;
    }

    boolean kiemMaTrung() {
        List<SanPham> list = dao.selectAll();
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getMaSP().equalsIgnoreCase(txt_maMon.getText())) {
                txt_maMon.requestFocus();
                MsgBox.alert(this, "Mã sản phẩm bị trùng");
                return false;
            }

        }
        return true;
    }

    boolean kiemMaTrungCapNhat() {
        List<SanPham> list = dao.selectAll();
        for (int i = 0; i < list.size(); i++) {

            if (list.get(i).getMaSP().equalsIgnoreCase(txt_maMon.getText())) {
                if(index == i){
                    return true;
                }else {
                    txt_maMon.requestFocus();
                    MsgBox.alert(this, "Mã sản phẩm bị trùng");
                    return false;
                }
                
            }

        }
        return true;
    }

    void trangThaiCacNut() {
        boolean k = (this.index >= 0);

        txt_maMon.setEditable(!k);
        btn_capNhatMon.setEnabled(k);
        btn_xoaMon.setEnabled(k);

        btn_themMon.setEnabled(!k);

        btn_lui.setEnabled(k);
        btn_toi.setEnabled(k);
    }

    void fill_tblSP() {
        DefaultTableModel tblmd = (DefaultTableModel) tbl_SanPham.getModel();
        tblmd.setRowCount(0);
        try {
            List<SanPham> list = dao.selectAll();
            for (SanPham s : list) {
                Object[] row = {s.getMaSP(), s.getTenSP(), s.getLoai(),
                    s.getGia()};
                tblmd.addRow(row);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    LoaiDao loai_Dao = new LoaiDao();

    void fill_combo_Box() {
        DefaultComboBoxModel cbomd = (DefaultComboBoxModel) cbo_Loai.getModel();
        cbomd.removeAllElements();
        List<LoaiSanPham> list = loai_Dao.selectAll();
        for (LoaiSanPham s : list) {
            cbomd.addElement(s.getTenSP());
        }
    }

    void chonAnh() {
        try {
            JFileChooser fc = new JFileChooser(".\\src\\com\\img");
            fc.showOpenDialog(null);
            File f = fc.getSelectedFile();
            Ximg.save_img(f);
            ImageIcon icon = Ximg.read_img(f.getName());
//            Image img = icon.getImage();
//            Image newImg = img.getScaledInstance(lbl_hinhAnh.getWidth(), lbl_hinhAnh.getHeight(), Image.SCALE_SMOOTH);
//            ImageIcon newIcon = new ImageIcon(newImg);
            lbl_hinhAnh.setIcon(icon);
            lbl_hinhAnh.setToolTipText(f.getName());
            lbl_hinhAnh.setText("");
        } catch (IllegalArgumentException e) {
        } catch (NullPointerException e) {

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    SanPham getForm() {
//LoaiSanPham l = (LoaiSanPham) cbo_Loai.getSelectedItem();
        SanPham s = new SanPham();

        s.setMaSP(txt_maMon.getText());
        s.setTenSP(txt_tenMon.getText());
        maLoai = loai_Dao.toMaLoai((String) cbo_Loai.getSelectedItem());
        System.out.println(cbo_Loai.getSelectedItem());
        s.setLoai(maLoai);
        s.setGia(Float.parseFloat(txt_gia.getText()));
        s.setHinhAnh(lbl_hinhAnh.getToolTipText());
        return s;
    }

    void setForm(SanPham s) {

        txt_maMon.setText(s.getMaSP());
        txt_tenMon.setText(s.getTenSP());
        txt_gia.setText(String.valueOf(s.getGia()));
//        String sa = loai_Dao.toTenLoai(s.getLoai());
//        System.out.println(sa);
        String a = loai_Dao.toTenLoai(s.getLoai());
        cbo_Loai.setSelectedItem(a);
        if (s.getHinhAnh() == null) {
            lbl_hinhAnh.setIcon(null);
        } else {
            lbl_hinhAnh.setToolTipText(s.getHinhAnh());
            lbl_hinhAnh.setIcon(Ximg.read_img(s.getHinhAnh()));
        }
    }

    void themSP() {
        SanPham s = getForm();
        try {
            dao.insert(s);
            fill_tblSP();
            clear();
            MsgBox.alert(this, "Thêm sản phẩm thành công");
        } catch (Exception e) {
//            System.out.println(e);
            MsgBox.alert(this, "Thêm sản phẩm thất bại");
        }
    }

    void capNhatSP() {
        SanPham s = getForm();
        try {
            dao.update(s);
            fill_tblSP();
            clear();
            MsgBox.alert(this, "Cập nhật sản phẩm thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Cập nhật sản phẩm thất bại");
        }
    }

    void xoaSP() {
        String maSp = (String) tbl_SanPham.getValueAt(index, 0);
        try {
            if (MsgBox.confirm(this, "Bạn có chắc muốn xoá sản phẩm này không ?")) {
                dao.delete(maSp);
                fill_tblSP();
                clear();
                MsgBox.alert(this, "Xoá sản phẩm thành công");
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Xoá sản phẩm thất bại");
        }
    }

    void clear() {
        txt_maMon.setText("");
        txt_tenMon.setText("");
        txt_gia.setText("0");
        cbo_Loai.setSelectedIndex(0);
        lbl_hinhAnh.setIcon(null);
        index = -1;
        trangThaiCacNut();
    }

    void edit() {
        String masp = (String) tbl_SanPham.getValueAt(index, 0);
        SanPham s = dao.select_byID(masp);
        setForm(s);
        trangThaiCacNut();
    }

    void lui() {
        if (index == 0 || index < 0) {
            index = tbl_SanPham.getRowCount() - 1;
            tbl_SanPham.setRowSelectionInterval(index, index);
            edit();
        } else {
            index--;
            tbl_SanPham.setRowSelectionInterval(index, index);
            edit();
        }

    }

    void toi() {
        if (index < tbl_SanPham.getRowCount() - 1) {
            index++;
            tbl_SanPham.setRowSelectionInterval(index, index);
            edit();
        } else {
            index = 0;
            tbl_SanPham.setRowSelectionInterval(index, index);
            edit();
        }
    }

    void timKiem() {
        DefaultTableModel tblmd = (DefaultTableModel) tbl_SanPham.getModel();
        tblmd.setRowCount(0);
        try {
            if (txt_timMon.getText().equalsIgnoreCase("Tìm theo tên sản phẩm...")) {
                txt_timMon.setText("");
                String ten = txt_timMon.getText();
                List<SanPham> list = dao.searchLSP(ten);
                for (SanPham s : list) {
                    Object[] row = {s.getMaSP(), s.getTenSP(), s.getLoai(),
                        s.getGia()};
                    tblmd.addRow(row);
                }
                goiYTimKiem(txt_timMon);
            } else {
                String ten = txt_timMon.getText();
                List<SanPham> list = dao.searchLSP(ten);
                for (SanPham s : list) {
                    Object[] row = {s.getMaSP(), s.getTenSP(), s.getLoai(),
                        s.getGia()};
                    tblmd.addRow(row);
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_big = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_SanPham = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txt_maMon = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_tenMon = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cbo_Loai = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        lbl_hinhAnh = new javax.swing.JLabel();
        btn_themMon = new javax.swing.JButton();
        btn_lamMoi = new javax.swing.JButton();
        btn_capNhatMon = new javax.swing.JButton();
        btn_xoaMon = new javax.swing.JButton();
        btn_lui = new javax.swing.JButton();
        btn_toi = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        btn_loaiSP = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txt_gia = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txt_timMon = new javax.swing.JTextField();
        btn_tim = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản lý Sản Phẩm");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pnl_big.setBackground(new java.awt.Color(255, 255, 255));
        pnl_big.setPreferredSize(new java.awt.Dimension(704, 514));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ MENU");

        jPanel1.setBackground(new java.awt.Color(237, 237, 237));

        tbl_SanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã Món", "Tên Món", "Loại", "Đơn Giá"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_SanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_SanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_SanPham);
        if (tbl_SanPham.getColumnModel().getColumnCount() > 0) {
            tbl_SanPham.getColumnModel().getColumn(0).setMinWidth(130);
            tbl_SanPham.getColumnModel().getColumn(0).setMaxWidth(150);
        }

        jLabel2.setText("Mã Món");

        txt_maMon.setBackground(new java.awt.Color(237, 237, 237));
        txt_maMon.setBorder(null);

        jLabel3.setText("Tên Món");

        txt_tenMon.setBackground(new java.awt.Color(237, 237, 237));
        txt_tenMon.setBorder(null);

        jLabel4.setText("Loại");

        cbo_Loai.setBackground(java.awt.Color.pink);
        cbo_Loai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cà Phê", "Nước Ép", "Sinh Tố", " " }));

        jLabel5.setText("Hình Ảnh");

        lbl_hinhAnh.setBackground(new java.awt.Color(255, 255, 255));
        lbl_hinhAnh.setText("Ảnh Sản Phẩm");
        lbl_hinhAnh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lbl_hinhAnh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_hinhAnhMouseClicked(evt);
            }
        });

        btn_themMon.setBackground(new java.awt.Color(255, 255, 255));
        btn_themMon.setText("Thêm Món");
        btn_themMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themMonActionPerformed(evt);
            }
        });

        btn_lamMoi.setBackground(new java.awt.Color(255, 255, 255));
        btn_lamMoi.setText("Làm Mới");
        btn_lamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lamMoiActionPerformed(evt);
            }
        });

        btn_capNhatMon.setBackground(new java.awt.Color(255, 255, 255));
        btn_capNhatMon.setText("Cập Nhật Món");
        btn_capNhatMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_capNhatMonActionPerformed(evt);
            }
        });

        btn_xoaMon.setBackground(new java.awt.Color(255, 255, 255));
        btn_xoaMon.setText("Xoá Món");
        btn_xoaMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaMonActionPerformed(evt);
            }
        });

        btn_lui.setBackground(new java.awt.Color(255, 255, 255));
        btn_lui.setText("<");
        btn_lui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_luiActionPerformed(evt);
            }
        });

        btn_toi.setBackground(new java.awt.Color(255, 255, 255));
        btn_toi.setText(">");
        btn_toi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_toiActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        btn_loaiSP.setBackground(new java.awt.Color(255, 255, 255));
        btn_loaiSP.setText("Thêm loại sản phẩm");
        btn_loaiSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loaiSPActionPerformed(evt);
            }
        });

        jLabel6.setText("Giá");

        txt_gia.setBackground(new java.awt.Color(237, 237, 237));
        txt_gia.setBorder(null);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 260, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel7.setText("Tìm Món");

        txt_timMon.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_timMonFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_timMonFocusLost(evt);
            }
        });

        btn_tim.setBackground(new java.awt.Color(255, 255, 255));
        btn_tim.setText("Tìm");
        btn_tim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(243, 243, 243))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_maMon, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                                    .addComponent(txt_tenMon)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_gia))
                                .addGap(103, 103, 103)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbo_Loai, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl_hinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btn_loaiSP, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE)
                                    .addComponent(txt_timMon)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btn_tim, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(0, 0, Short.MAX_VALUE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(btn_themMon)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_lamMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(11, 11, 11)
                                        .addComponent(btn_capNhatMon)
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_xoaMon, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(70, 70, 70)
                                        .addComponent(btn_lui, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(31, 31, 31)
                                        .addComponent(btn_toi, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cbo_Loai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btn_loaiSP))
                    .addComponent(txt_maMon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(jLabel5))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(txt_tenMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txt_gia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbl_hinhAnh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(3, 3, 3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_timMon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_tim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_capNhatMon)
                    .addComponent(btn_xoaMon)
                    .addComponent(btn_themMon)
                    .addComponent(btn_lamMoi)
                    .addComponent(btn_lui)
                    .addComponent(btn_toi))
                .addContainerGap())
        );

        javax.swing.GroupLayout pnl_bigLayout = new javax.swing.GroupLayout(pnl_big);
        pnl_big.setLayout(pnl_bigLayout);
        pnl_bigLayout.setHorizontalGroup(
            pnl_bigLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_bigLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pnl_bigLayout.setVerticalGroup(
            pnl_bigLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_bigLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(pnl_big, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_loaiSPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loaiSPActionPerformed
        QuanLyLoaiSanPham a = new QuanLyLoaiSanPham(null, true);
        a.setVisible(true);
        fill_combo_Box();
    }//GEN-LAST:event_btn_loaiSPActionPerformed

    private void lbl_hinhAnhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_hinhAnhMouseClicked
        chonAnh();
    }//GEN-LAST:event_lbl_hinhAnhMouseClicked

    private void btn_luiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_luiActionPerformed
        lui();
    }//GEN-LAST:event_btn_luiActionPerformed

    private void btn_toiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_toiActionPerformed
        toi();
    }//GEN-LAST:event_btn_toiActionPerformed

    private void btn_timActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timActionPerformed
        timKiem();
    }//GEN-LAST:event_btn_timActionPerformed

    private void btn_themMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themMonActionPerformed
        if (kiemTraLoi()) {
            if (kiemMaTrung()) {
                themSP();
            }
        }
    }//GEN-LAST:event_btn_themMonActionPerformed

    private void tbl_SanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_SanPhamMouseClicked
        try {
            index = tbl_SanPham.getSelectedRow();
            edit();
        } catch (Exception e) {

        }
    }//GEN-LAST:event_tbl_SanPhamMouseClicked

    private void btn_lamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lamMoiActionPerformed
        clear();
    }//GEN-LAST:event_btn_lamMoiActionPerformed

    private void btn_capNhatMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_capNhatMonActionPerformed
        if (kiemTraLoi()) {
            if (kiemMaTrungCapNhat()) {
                capNhatSP();
            }

        }
    }//GEN-LAST:event_btn_capNhatMonActionPerformed

    private void btn_xoaMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaMonActionPerformed
        xoaSP();
    }//GEN-LAST:event_btn_xoaMonActionPerformed

    private void txt_timMonFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_timMonFocusGained
        if (txt_timMon.getText().equalsIgnoreCase("Tìm theo tên sản phẩm...")) {
            xoaGoiYTimKiem(txt_timMon);
        }
    }//GEN-LAST:event_txt_timMonFocusGained

    private void txt_timMonFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_timMonFocusLost
        if (txt_timMon.getText().equalsIgnoreCase("")) {
            goiYTimKiem(txt_timMon);
        }
    }//GEN-LAST:event_txt_timMonFocusLost

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuanLySanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuanLySanPham dialog = new QuanLySanPham(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_capNhatMon;
    private javax.swing.JButton btn_lamMoi;
    private javax.swing.JButton btn_loaiSP;
    private javax.swing.JButton btn_lui;
    private javax.swing.JButton btn_themMon;
    private javax.swing.JButton btn_tim;
    private javax.swing.JButton btn_toi;
    private javax.swing.JButton btn_xoaMon;
    private javax.swing.JComboBox<String> cbo_Loai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_hinhAnh;
    private javax.swing.JPanel pnl_big;
    private javax.swing.JTable tbl_SanPham;
    private javax.swing.JTextField txt_gia;
    private javax.swing.JTextField txt_maMon;
    private javax.swing.JTextField txt_tenMon;
    private javax.swing.JTextField txt_timMon;
    // End of variables declaration//GEN-END:variables
}
