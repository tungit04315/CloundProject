/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.NhanVienDao;
import com.model.NhanVien;
import com.utils.MsgBox;
import com.utils.XAuth;
import com.utils.Ximg;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author tungt
 */
public class CuaSoDangNhap extends javax.swing.JDialog {

    /**
     * Creates new form Login_Interface
     */
    NhanVienDao dao = new NhanVienDao();
    boolean kt;

    public CuaSoDangNhap(java.awt.Frame parent, boolean modal, boolean t) {
	super(parent, modal);
	initComponents();
	kt = t;
        init();
	this.setIconImage(Ximg.getImage());
	goiY_Username(txt_Username);
	goiY_Pass(txt_Password);
	
    }

    void init() {
	if (kt == true) {
	    CuaSoChao a = new CuaSoChao(null, true);
	    a.setVisible(true);
	}
        btn_login.requestFocus();
    }

    void login_Coffee() {
	String user = txt_Username.getText();
	String pass = txt_Password.getText();

	NhanVien nv = dao.select_byID(user);

	if (nv == null) {
	    MsgBox.alert(this, "Sai tên đăng nhập !!!");
            txt_Username.requestFocus();
	} else if (!nv.getMatKhau().equalsIgnoreCase(pass)) {
	    MsgBox.alert(this, "Sai mật khẩu !!!");
            txt_Password.requestFocus();
	} else {
	    XAuth.user = nv;
	    this.dispose();
	    CuaSoChinh a = new CuaSoChinh();
	    a.setVisible(true);
	}
    }

    boolean kiemTra_Input() {
	if (txt_Username.getText().equalsIgnoreCase("")) {
	    MsgBox.alert(this, "Không để trống tên đăng nhập");
	    txt_Username.requestFocus();
	    return false;
	}
	if (txt_Username.getText().equalsIgnoreCase("Tên Đăng Nhập...")) {
	    MsgBox.alert(this, "Không để trống tên đăng nhập");
	    txt_Username.requestFocus();
	    return false;
	}
	if (txt_Password.getText().equalsIgnoreCase("")) {
	    MsgBox.alert(this, "Không để trống mật khẩu");
	    txt_Password.requestFocus();
	    return false;
	}
	if (txt_Password.getText().equalsIgnoreCase("Mật khẩu...")) {
	    MsgBox.alert(this, "Không để trống mật khẩu");
	    txt_Password.requestFocus();
	    return false;
	}

	return true;
    }

    void goiY_Username(JTextField txt) {
	txt.setText("Tên Đăng Nhập...");
//        txt.setFont(Font.ITALIC);
	txt.setForeground(Color.white);
    }

    void xoaGoiY_Username(JTextField txt) {
	txt.setText("");
	txt.setForeground(Color.white);
    }

    void goiY_Pass(JPasswordField txt) {
	txt.setText("Mật Khẩu...");
	txt.setEchoChar((char) 0);
//        txt.setFont(Font.ITALIC);
	txt.setForeground(Color.white);
    }

    void xoaGoiY_Pass(JPasswordField txt) {
	txt.setText("");
            txt.setEchoChar('*');
            txt.setForeground(Color.white);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_login = new javax.swing.JButton();
        lbl_Icon_AvatarLogin = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        txt_Username = new javax.swing.JTextField();
        txt_Password = new javax.swing.JPasswordField();
        lbl_eye = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lbl_quenMK = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Đăng Nhập");
        setFocusTraversalPolicyProvider(true);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(134, 101, 101));

        btn_login.setBackground(new java.awt.Color(255, 255, 255));
        btn_login.setText("Đăng Nhập");
        btn_login.setAlignmentY(0.0F);
        btn_login.setBorderPainted(false);
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });

        lbl_Icon_AvatarLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/Ellipse 21coffee_bida.png"))); // NOI18N

        jPanel4.setBackground(new java.awt.Color(220, 204, 186));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/icon_login.gif"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe Print", 3, 22)); // NOI18N
        jLabel2.setText("WElCOME COFFEE - BIDA");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(28, 28, 28))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(134, 101, 101));

        txt_Username.setBackground(new java.awt.Color(134, 101, 101));
        txt_Username.setForeground(new java.awt.Color(255, 255, 255));
        txt_Username.setBorder(null);
        txt_Username.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_UsernameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_UsernameFocusLost(evt);
            }
        });
        txt_Username.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txt_UsernameMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txt_UsernameMouseExited(evt);
            }
        });
        txt_Username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_UsernameActionPerformed(evt);
            }
        });
        txt_Username.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_UsernameKeyPressed(evt);
            }
        });

        txt_Password.setBackground(new java.awt.Color(134, 101, 101));
        txt_Password.setForeground(new java.awt.Color(255, 255, 255));
        txt_Password.setBorder(null);
        txt_Password.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txt_PasswordFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txt_PasswordFocusLost(evt);
            }
        });
        txt_Password.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                txt_PasswordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                txt_PasswordMouseExited(evt);
            }
        });
        txt_Password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_PasswordKeyPressed(evt);
            }
        });

        lbl_eye.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/eyeshow.png"))); // NOI18N
        lbl_eye.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_eyeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_eyeMouseExited(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 302, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        lbl_quenMK.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        lbl_quenMK.setForeground(new java.awt.Color(255, 255, 255));
        lbl_quenMK.setText("Quên Mật Khẩu ?");
        lbl_quenMK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_quenMKMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_quenMKMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_quenMKMouseExited(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 302, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(txt_Password, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(lbl_eye))
                        .addComponent(txt_Username, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_quenMK, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txt_Username, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_eye, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_Password, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_quenMK)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/close_button.png"))); // NOI18N
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lbl_Icon_AvatarLogin)
                        .addGap(104, 104, 104))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_login)
                        .addGap(112, 112, 112))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel3)
                .addGap(21, 21, 21)
                .addComponent(lbl_Icon_AvatarLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_login)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txt_UsernameMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_UsernameMouseEntered
	int kq = MouseEvent.MOUSE_ENTERED;
	if (evt.getButton() != kq) {
	    jPanel2.setBackground(Color.ORANGE);
	}
    }//GEN-LAST:event_txt_UsernameMouseEntered

    private void txt_UsernameMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_UsernameMouseExited
	int kq = MouseEvent.MOUSE_EXITED;
	if (evt.getButton() != kq) {
	    jPanel2.setBackground(Color.white);
	}
    }//GEN-LAST:event_txt_UsernameMouseExited

    private void txt_PasswordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_PasswordMouseEntered
	int kq = MouseEvent.MOUSE_ENTERED;
	if (evt.getButton() != kq) {
	    jPanel3.setBackground(Color.ORANGE);
	}
    }//GEN-LAST:event_txt_PasswordMouseEntered

    private void txt_PasswordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txt_PasswordMouseExited
	int kq = MouseEvent.MOUSE_EXITED;
	if (evt.getButton() != kq) {
	    jPanel3.setBackground(Color.white);
	}
    }//GEN-LAST:event_txt_PasswordMouseExited

    private void txt_UsernameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_UsernameFocusGained
	if (txt_Username.getText().equalsIgnoreCase("Tên Đăng Nhập...")) {
	    xoaGoiY_Username(txt_Username);
	}
    }//GEN-LAST:event_txt_UsernameFocusGained

    private void txt_UsernameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_UsernameFocusLost
	if (txt_Username.getText().equalsIgnoreCase("")) {
	    goiY_Username(txt_Username);
	}
    }//GEN-LAST:event_txt_UsernameFocusLost

    private void txt_PasswordFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_PasswordFocusGained
	if (txt_Password.getText().equalsIgnoreCase("Mật Khẩu...")) {
	    xoaGoiY_Pass(txt_Password);
	}
    }//GEN-LAST:event_txt_PasswordFocusGained

    private void txt_PasswordFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txt_PasswordFocusLost
	if (txt_Password.getText().equalsIgnoreCase("")) {
	    goiY_Pass(txt_Password);
	}
    }//GEN-LAST:event_txt_PasswordFocusLost

    private void lbl_eyeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_eyeMouseEntered
	txt_Password.setEchoChar((char) 0);
	URL url = CuaSoDangNhap.class.getResource("/com/img/eyehide.png");
	lbl_eye.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lbl_eyeMouseEntered

    private void lbl_eyeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_eyeMouseExited
	txt_Password.setEchoChar('*');
	URL url = CuaSoDangNhap.class.getResource("/com/img/eyeshow.png");
	lbl_eye.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lbl_eyeMouseExited

    private void lbl_quenMKMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_quenMKMouseEntered
	lbl_quenMK.setForeground(Color.orange);
    }//GEN-LAST:event_lbl_quenMKMouseEntered

    private void lbl_quenMKMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_quenMKMouseExited
	lbl_quenMK.setForeground(Color.white);
    }//GEN-LAST:event_lbl_quenMKMouseExited

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed
	if (kiemTra_Input()) {
            login_Coffee();
	}
    }//GEN-LAST:event_btn_loginActionPerformed

    private void txt_UsernameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_UsernameKeyPressed
	if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
	    if (kiemTra_Input()) {

	    }
	}
    }//GEN-LAST:event_txt_UsernameKeyPressed

    private void txt_PasswordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_PasswordKeyPressed
	if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
	    if (kiemTra_Input()) {
		try {
		    login_Coffee();
		} catch (Exception ex) {
		    Logger.getLogger(CuaSoDangNhap.class.getName()).log(Level.SEVERE, null, ex);
		}
	    }
	}
    }//GEN-LAST:event_txt_PasswordKeyPressed

    private void lbl_quenMKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_quenMKMouseClicked
	this.dispose();
	QuenMatKhau a = new QuenMatKhau(null, true);
	a.setVisible(true);
    }//GEN-LAST:event_lbl_quenMKMouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
	// TODO add your handling code here:

	if (MsgBox.confirm(this, "Bạn có chắc chắn muốn thoát không ?")) {
	    System.exit(0);
	} else {

	}
    }//GEN-LAST:event_jLabel3MouseClicked

    private void txt_UsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_UsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_UsernameActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
	/* Set the Nimbus look and feel */
	//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	 */
	try {
	    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
		if ("Windows".equals(info.getName())) {
		    javax.swing.UIManager.setLookAndFeel(info.getClassName());
		    break;
		}
	    }
	} catch (ClassNotFoundException ex) {
	    java.util.logging.Logger.getLogger(CuaSoDangNhap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (InstantiationException ex) {
	    java.util.logging.Logger.getLogger(CuaSoDangNhap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (IllegalAccessException ex) {
	    java.util.logging.Logger.getLogger(CuaSoDangNhap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (javax.swing.UnsupportedLookAndFeelException ex) {
	    java.util.logging.Logger.getLogger(CuaSoDangNhap.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	}
	//</editor-fold>
	//</editor-fold>

	/* Create and display the dialog */
	java.awt.EventQueue.invokeLater(new Runnable() {
	    @Override
	    public void run() {
		CuaSoDangNhap dialog = new CuaSoDangNhap(new javax.swing.JFrame(), true, true);
		dialog.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent e) {
//                        if (Msg_Box.confirm(e.getWindow(), "Bạn có chắc chắn muốn thoát không?")) {
			System.exit(0);
//                        } else {
//                            dialog.setVisible(true);
//                        }
		    }
		});
		dialog.setVisible(true);
	    }
	});
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_login;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JLabel lbl_Icon_AvatarLogin;
    private javax.swing.JLabel lbl_eye;
    private javax.swing.JLabel lbl_quenMK;
    private javax.swing.JPasswordField txt_Password;
    private javax.swing.JTextField txt_Username;
    // End of variables declaration//GEN-END:variables
}
