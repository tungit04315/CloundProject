/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.NhanVienDao;
import com.model.NhanVien;
import com.utils.MsgBox;
import com.utils.XAuth;
import com.utils.Ximg;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
//import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Admin
 */
public class QuanLyNhanVien extends javax.swing.JDialog {

    /**
     * Creates new form Employee_Management_Interface
     */
    NhanVienDao nvdao = new NhanVienDao();
    private int index = -1;

    String hinhAnh = "";

    public QuanLyNhanVien(java.awt.Frame parent, boolean modal) {
	super(parent, modal);
	initComponents();
	this.setIconImage(Ximg.getImage());
	init();
    }

    void init() {
	fill_tblNhanVien();
	index = -1;
	trangThaiCacNut();
    }

    void fill_tblNhanVien() {
	DefaultTableModel tblmd = (DefaultTableModel) tblNhanVien.getModel();
	tblmd.setRowCount(0);

	TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tblNhanVien.getModel());
	tblNhanVien.setRowSorter(sorter);

	List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
//	sortKeys.add(new RowSorter.SortKey(4, SortOrder.ASCENDING));
	sortKeys.add(new RowSorter.SortKey(0, SortOrder.ASCENDING));
	sorter.setSortKeys(sortKeys);

	try {
	    List<NhanVien> list = nvdao.selectAll();
	    for (NhanVien nv : list) {
		Object[] row = {nv.getMaNV(), nv.getTenNV(), nv.getMatKhau(), nv.isVaiTro() ? "Quản Lý" : "Nhân Viên",
		    nv.getEmail(), nv.getSdt(), nv.getCccd(), nv.isGioiTinh() ? "Nam" : "Nữ", nv.isTrangThai() ? "Đang làm" : "Đã nghĩ",
		    nv.getNgaySinh(), nv.getDiaChi()};
		tblmd.addRow(row);
	    }
	} catch (Exception e) {
	}
    }

    void trangThaiCacNut() {
	boolean edit = (this.index >= 0);

	txtMaNV.setEditable(!edit);

	btnCapNhat.setEnabled(edit);
//	String maNV = txtMaNV.getText();
//	if (XAuth.user.getMaNV().equalsIgnoreCase(maNV)) {
//	    btnXoa.setEnabled(!edit);
//	} else {
//	    btnXoa.setEnabled(edit);
//	}

	btnThem.setEnabled(!edit);

	btnLui.setEnabled(edit);
	btnToi.setEnabled(edit);
    }

    void setForm(NhanVien nv) {
	txtMaNV.setText(nv.getMaNV());
	txtHoTen.setText(nv.getTenNV());
	txtMatKhau1.setText(nv.getMatKhau());
	txtMatKhau2.setText(nv.getMatKhau());
	txtCccd.setText(nv.getCccd());
	txtDiaChi.setText(nv.getDiaChi());
	txtEmail.setText(nv.getEmail());
	txtSdt.setText(nv.getSdt());

	if (nv.isGioiTinh() == true) {
	    rdoNam.setSelected(true);
	} else {
	    rdoNu.setSelected(true);
	}

	if (nv.isTrangThai() == true) {
	    rdodanglam.setSelected(true);
	} else {
	    rdodanghi.setSelected(true);
	}

	if (nv.isVaiTro() == true) {
	    rdoTruongPhong.setSelected(true);
	} else {
	    rdoNhanVien.setSelected(true);
	}
	try {
//            index = tbl_nhanVien.getSelectedRow();
//            Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String) tbl_nhanVien.getValueAt(index, 8));
	    dtcNgaySinh.setDate(nv.getNgaySinh());
	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
	if (nv.getHinhAnh() == null) {
	    lblHinhAnh.setIcon(null);
	} else {
	    lblHinhAnh.setToolTipText(nv.getHinhAnh());
	    lblHinhAnh.setIcon(Ximg.read_img(nv.getHinhAnh()));
	}
    }

    NhanVien getForm() {
	NhanVien nv = new NhanVien();
	nv.setMaNV(txtMaNV.getText());
	nv.setTenNV(txtHoTen.getText());
	nv.setMatKhau(txtMatKhau1.getText());
	nv.setVaiTro(rdoTruongPhong.isSelected());
	nv.setEmail(txtEmail.getText());
	nv.setSdt(txtSdt.getText());
	nv.setCccd(txtCccd.getText());
	nv.setDiaChi(txtDiaChi.getText());
	nv.setGioiTinh(rdoNam.isSelected());
	nv.setTrangThai(rdodanglam.isSelected());
	nv.setHinhAnh(lblHinhAnh.getToolTipText());
	nv.setNgaySinh(dtcNgaySinh.getDate());
	return nv;
    }

    void themNV() {
	NhanVien nv = getForm();
	try {
	    nvdao.insert(nv);
	    fill_tblNhanVien();
	    clearForm();
	    MsgBox.alert(this, "Thêm nhân viên thành công");
	} catch (Exception e) {
//            System.out.println(e);
	    MsgBox.alert(this, "Thêm nhân viên thất bại");
	}
    }

    void suaNV() {
	NhanVien nv = getForm();
	try {
	    nvdao.update(nv);
	    fill_tblNhanVien();
	    clearForm();
	    MsgBox.alert(this, "Cập nhật thông tin nhân viên thành công");
	} catch (Exception e) {
//            System.out.println(e);
	    MsgBox.alert(this, "Cập nhật nhân viên thất bại");
	}
    }

    void xoaNV() {
	try {
	    String maNV = txtMaNV.getText();
	    if (XAuth.user.getMaNV().equalsIgnoreCase(maNV)) {
		MsgBox.alert(this, "Bạn không thể xoá chính bạn");
	    } else if (MsgBox.confirm(this, "Bạn thực sự muốn xoá nhân viên này ?")) {
		nvdao.delete(maNV);
		fill_tblNhanVien();

		clearForm();
		MsgBox.alert(this, "Xoá nhân viên thành công");
	    }
	} catch (Exception e) {
	    System.out.println(e);
	    MsgBox.alert(this, "Xoá nhân viên thất bại");
	}
    }

    void timKiem() {
	DefaultTableModel tblmd = (DefaultTableModel) tblNhanVien.getModel();
	tblmd.setRowCount(0);
	try {
	    String tim = txtTimKiem.getText();
	    List<NhanVien> list = nvdao.searchNV(tim);
	    for (NhanVien nv : list) {
		Object[] row = {nv.getMaNV(), nv.getTenNV(), nv.getMatKhau(), nv.isVaiTro() ? "Quản Lý" : "Nhân Viên",
		    nv.getEmail(), nv.getSdt(), nv.getCccd(), nv.isGioiTinh() ? "Nam" : "Nữ",
		    nv.getNgaySinh(), nv.getDiaChi()};
		tblmd.addRow(row);
	    }
//	    if (tblNhanVien.getSelectedRow() == -1) {
//		MsgBox.alert(this, "Nhân viên Không tồn tại");
//	    }
	} catch (Exception e) {
//            System.out.println(e);
	    txtTimKiem.setText("");
	    MsgBox.alert(this, "Tìm nhân viên thất bại");
	}
    }

    void edit() {
	String maNV = (String) tblNhanVien.getValueAt(index, 0);
	NhanVien nv = nvdao.select_byID(maNV);
	setForm(nv);
	pnl_big.setSelectedIndex(1);
	trangThaiCacNut();
    }

    void lui() {
	if (index == 0 || index < 0) {
	    index = tblNhanVien.getRowCount() - 1;
	    tblNhanVien.setRowSelectionInterval(index, index);
	    edit();
	} else {
	    index--;
	    tblNhanVien.setRowSelectionInterval(index, index);
	    edit();

	}

    }

    void toi() {
	if (index < tblNhanVien.getRowCount() - 1) {
	    index++;
	    tblNhanVien.setRowSelectionInterval(index, index);
	    edit();
	} else {
	    index = 0;
	    tblNhanVien.setRowSelectionInterval(index, index);
	    edit();
	}
    }

    void clearForm() {
	NhanVien nv = new NhanVien();
	setForm(nv);
	index = -1;
	trangThaiCacNut();
    }

    boolean kiemTraMaTrung() {
	List<NhanVien> list = nvdao.selectAll();
	for (int i = 0; i < list.size(); i++) {
	    if (list.get(i).getMaNV().equalsIgnoreCase(txtMaNV.getText()) == true) {
		if (index != i) {
		    txtMaNV.requestFocus();
		    return false;
		}
	    }
	}
	return true;
    }

    boolean kiemTraLoi() {
//manv
	if (txtMaNV.getText().equalsIgnoreCase("")) {
	    txtMaNV.requestFocus();
	    MsgBox.alert(this, "Không để trống mã nhân viên");
	    return false;
	}

	if (txtMaNV.getText().length() > 5) {
	    txtMaNV.requestFocus();
	    MsgBox.alert(this, "Mã nhân viên đang nhiều hơn 5 ký tự");
	    return false;
	}

	if (txtMaNV.getText().length() < 5) {
	    txtMaNV.requestFocus();
	    MsgBox.alert(this, "Mã nhân viên đang ít 5 ký tự");
	    return false;
	}
	if (kiemTraMaTrung() == false) {
	    MsgBox.alert(this, "Không được trùng mã nhân viên");
	    return false;
	}

//mail
	if (txtEmail.getText().equalsIgnoreCase("")) {
	    txtEmail.requestFocus();
	    MsgBox.alert(this, "Không để trống email");
	    return false;
	}
	Pattern p_email = Pattern.compile("^\\w+[a-z0-9]*@\\w+(\\.[A-Za-z0-9]+)$");
	Matcher m_email = p_email.matcher(txtEmail.getText());
	if (!m_email.matches()) {
	    txtEmail.requestFocus();
	    MsgBox.alert(this, "Email chưa đúng địng dạng (abc123@gmail.com)");
	    return false;
	}

	List<NhanVien> list = nvdao.selectAll();
	for (int i = 0; i < list.size(); i++) {
	    if (txtEmail.getText().equalsIgnoreCase(list.get(i).getEmail())) {
		if (index != i) {
		    MsgBox.alert(this, "Email đã được đăng ký");
		    txtEmail.requestFocus();
		    return false;
		}
	    }
	}

//hoten
	if (txtHoTen.getText().equalsIgnoreCase("")) {
	    txtHoTen.requestFocus();
	    MsgBox.alert(this, "Không để trống họ tên nhân viên");
	    return false;
	}
	Pattern p = Pattern.compile("([0-9])");
	Matcher m = p.matcher(txtHoTen.getText());

	if (m.find()) {
//            MsgBox.alert(this, "KQ "+m.find());
	    txtHoTen.requestFocus();
	    MsgBox.alert(this, "Không được nhập số trong họ tên nhân viên");
	    return false;
	}
//	Pattern hotenPattern = Pattern.compile("^([A-VXYỲỌÁẦẢẤỜỄÀẠẰỆẾÝỘẬỐŨỨĨÕÚỮỊỖÌỀỂẨỚẶÒÙỒỢÃỤỦÍỸẮẪỰỈỎỪỶỞÓÉỬỴẲẸÈẼỔẴẺỠƠÔƯĂÊÂĐ]+)((\\S{1}[A-VXYỲỌÁẦẢẤỜỄÀẠẰỆẾÝỘẬỐŨỨĨÕÚỮỊỖÌỀỂẨỚẶÒÙỒỢÃỤỦÍỸẮẪỰỈỎỪỶỞÓÉỬỴẲẸÈẼỔẴẺỠƠÔƯĂÊÂĐ]+){1,})|^([A-ZỲỌÁẦẢẤỜỄÀẠẰỆẾÝỘẬỐŨỨĨÕÚỮỊỖÌỀỂẨỚẶÒÙỒỢÃỤỦÍỸẮẪỰỈỎỪỶỞÓÉỬỴẲẸÈẼỔẴẺỠƠÔƯĂÊÂĐ']){1,}$");
//	Matcher hotenMatcher = hotenPattern.matcher(txtHoTen.getText());
//	if (!hotenMatcher.matches()) {
//	    txtHoTen.requestFocus();
//	    MsgBox.alert(this, "Kiểm tra lại họ tên VD:'NGUYỄN VĂN A'");
//	    return false;
//	}
//sdt
	if (txtSdt.getText().equalsIgnoreCase("")) {
	    txtSdt.requestFocus();
	    MsgBox.alert(this, "Không để trống số điện thoại");
	    return false;
	}
	try {
	    int sdt = Integer.parseInt(txtSdt.getText());
	    if (sdt < 0) {
		txtSdt.requestFocus();
		MsgBox.alert(this, "Số điện thoại không được phép âm");
		return false;
	    }
	} catch (NumberFormatException e) {
	    txtSdt.requestFocus();
	    MsgBox.alert(this, "Số điện thoại không được phép có chữ cái");
	    return false;
	}
	Pattern p_sdt = Pattern.compile("0[1-9][0-9]{8}");
	Matcher m_sdt = p_sdt.matcher(txtSdt.getText());
	if (!m_sdt.matches()) {
	    txtSdt.requestFocus();
	    MsgBox.alert(this, "Số điện thoại chưa đúng");
	    return false;
	}
	if (txtSdt.getText().length() > 10) {
	    txtSdt.requestFocus();
	    MsgBox.alert(this, "Số điện thoại không được quá 10 ký tự");
	    return false;
	}
//matkhau
	if (txtMatKhau1.getText().equalsIgnoreCase("")) {
	    txtMatKhau1.requestFocus();
	    MsgBox.alert(this, "Không để trống mật khẩu");
	    return false;
	}
	if (txtMatKhau2.getText().equalsIgnoreCase("")) {
	    txtMatKhau2.requestFocus();
	    MsgBox.alert(this, "Không để trống xác nhận mật khảu");
	    return false;
	}
	if (!txtMatKhau2.getText().equalsIgnoreCase(txtMatKhau1.getText())) {
	    txtMatKhau2.requestFocus();
	    MsgBox.alert(this, "Mật khẩu không khớp");
	    return false;
	}
//cccd
	if (txtCccd.getText().equalsIgnoreCase("")) {
	    txtCccd.requestFocus();
	    MsgBox.alert(this, "Không để trống Căn Cước Công Dân");
	    return false;
	}
	//,^\\w+ bắt buộc bắt đầu chuỗi ký tự thành câu,[a-z0-9] chuỗi tự - số,(*) lấy 1 or nhìu,($)end.
	Pattern pcccd = Pattern.compile("^0[0-9]{11}");
	Matcher mcccd = pcccd.matcher(txtCccd.getText());
	if (!mcccd.matches()) {
	    txtCccd.requestFocus();
	    MsgBox.alert(this, "Sai định dạng cccd");
	    return false;
	}

//	Pattern p_cccd = Pattern.compile("0[1-9]{11}");
//	Matcher m_cccd = p_cccd.matcher(txtCccd.getText());
//	if (!m_sdt.matches()) {
//	    txtCccd.requestFocus();
//	    MsgBox.alert(this, "Số căn cước công dân chưa đúng");
//	    return false;
//	}
//	if (txtCccd.getText().length() > 12) {
//	    txtCccd.requestFocus();
//	    MsgBox.alert(this, "Số căn cước công dân không được quá 12 ký tự");
//	    return false;
//	}
//diachi
	if (txtDiaChi.getText().equalsIgnoreCase("")) {
	    txtDiaChi.requestFocus();
	    MsgBox.alert(this, "Không để trống địa chỉ");
	    return false;
	}
//ngaysinh
	if (dtcNgaySinh.getDate() == null) {
	    dtcNgaySinh.requestFocus();
	    MsgBox.alert(this, "Không để trống ngày sinh");
	    return false;
	}

	return true;
    }

//    boolean kiemTraEmailTrung() {
//	List<NhanVien> list = nvdao.selectAll();
//	for (int i = 0; i < list.size(); i++) {
//	    if (list.get(i).getEmail().equalsIgnoreCase(txtEmail.getText())) {
//		txtEmail.requestFocus();
//		MsgBox.alert(this, "không được trùng email");
//		return false;
//	    }
//	}
//	return true;
//    }
//    public boolean xetEmailTrungCapNhat() {
//	List<NhanVien> list = nvdao.selectAll2(tblNhanVien.getValueAt(index, 4).toString());
//	for (int i = 0; i < list.size(); i++) {
//	    if (txtEmail.getText().equalsIgnoreCase(list.get(i).getEmail())) {
//		MsgBox.alert(this, "Email đã được đăng ký");
//		txtEmail.requestFocus();
//		return false;
//	    }
//	}
//	return true;
//    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        pnl_big = new javax.swing.JTabbedPane();
        pnl_danhSach = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNhanVien = new javax.swing.JTable();
        pnl_timKiem = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        pnl_capNhat = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtMaNV = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtHoTen = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        txtMatKhau1 = new javax.swing.JPasswordField();
        lblShowMatKhau1 = new javax.swing.JLabel();
        txtMatKhau2 = new javax.swing.JPasswordField();
        jPanel6 = new javax.swing.JPanel();
        lblShowMatKhau2 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rdoTruongPhong = new javax.swing.JRadioButton();
        rdoNhanVien = new javax.swing.JRadioButton();
        jLabel10 = new javax.swing.JLabel();
        lblHinhAnh = new javax.swing.JLabel();
        btnThem = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        btnCapNhat = new javax.swing.JButton();
        btnLui = new javax.swing.JButton();
        btnToi = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtSdt = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtCccd = new javax.swing.JTextField();
        jPanel8 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        rdoNam = new javax.swing.JRadioButton();
        rdoNu = new javax.swing.JRadioButton();
        jLabel16 = new javax.swing.JLabel();
        dtcNgaySinh = new com.toedter.calendar.JDateChooser();
        jLabel17 = new javax.swing.JLabel();
        rdodanglam = new javax.swing.JRadioButton();
        rdodanghi = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản lý nhân viên");
        setPreferredSize(new java.awt.Dimension(932, 612));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setOpaque(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(922, 612));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("QUẢN LÝ NHÂN VIÊN");

        pnl_big.setBackground(new java.awt.Color(255, 255, 255));
        pnl_big.setPreferredSize(new java.awt.Dimension(900, 550));

        pnl_danhSach.setBackground(new java.awt.Color(255, 255, 255));

        tblNhanVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Nhân Viên", "Họ Tên", "Mật Khẩu", "Vai Trò", "Email", "Số Điện Thoại", "CCCD", "Giới Tính", "Trạng thái", "Ngày Sinh", "Địa Chỉ"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhanVien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhanVienMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblNhanVien);
        if (tblNhanVien.getColumnModel().getColumnCount() > 0) {
            tblNhanVien.getColumnModel().getColumn(7).setPreferredWidth(40);
            tblNhanVien.getColumnModel().getColumn(8).setPreferredWidth(50);
        }

        pnl_timKiem.setBackground(new java.awt.Color(230, 229, 229));
        pnl_timKiem.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setText("Tìm Kiếm");

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        btnTimKiem.setBackground(new java.awt.Color(255, 255, 255));
        btnTimKiem.setText("Tìm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnl_timKiemLayout = new javax.swing.GroupLayout(pnl_timKiem);
        pnl_timKiem.setLayout(pnl_timKiemLayout);
        pnl_timKiemLayout.setHorizontalGroup(
            pnl_timKiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_timKiemLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(btnTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnl_timKiemLayout.setVerticalGroup(
            pnl_timKiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_timKiemLayout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(pnl_timKiemLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout pnl_danhSachLayout = new javax.swing.GroupLayout(pnl_danhSach);
        pnl_danhSach.setLayout(pnl_danhSachLayout);
        pnl_danhSachLayout.setHorizontalGroup(
            pnl_danhSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_danhSachLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 798, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(pnl_danhSachLayout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addComponent(pnl_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnl_danhSachLayout.setVerticalGroup(
            pnl_danhSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_danhSachLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(pnl_timKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE)
                .addContainerGap())
        );

        pnl_big.addTab("Danh Sách", pnl_danhSach);

        pnl_capNhat.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setText("Mã Nhân Viên");

        txtMaNV.setBorder(null);

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel4.setText("Họ Tên");

        txtHoTen.setBorder(null);

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel5.setText("Mật Khẩu");

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel6.setText("Xác Nhận Lại Mật Khẩu");

        txtMatKhau1.setBorder(null);

        lblShowMatKhau1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/hidden.png"))); // NOI18N
        lblShowMatKhau1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblShowMatKhau1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblShowMatKhau1MouseExited(evt);
            }
        });

        txtMatKhau2.setBorder(null);
        txtMatKhau2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMatKhau2ActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        lblShowMatKhau2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/hidden.png"))); // NOI18N
        lblShowMatKhau2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblShowMatKhau2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblShowMatKhau2MouseExited(evt);
            }
        });

        jLabel9.setText("Vai Trò");

        rdoTruongPhong.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(rdoTruongPhong);
        rdoTruongPhong.setText("Quản Lý");

        rdoNhanVien.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(rdoNhanVien);
        rdoNhanVien.setText("Nhân Viên");

        jLabel10.setText("Hình Ảnh");

        lblHinhAnh.setText("Ảnh");
        lblHinhAnh.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        lblHinhAnh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblHinhAnhMouseClicked(evt);
            }
        });

        btnThem.setBackground(new java.awt.Color(255, 255, 255));
        btnThem.setText("Thêm Nhân Viên");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnLamMoi.setBackground(new java.awt.Color(255, 255, 255));
        btnLamMoi.setText("Làm Mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        btnCapNhat.setBackground(new java.awt.Color(255, 255, 255));
        btnCapNhat.setText("Cập Nhật ");
        btnCapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatActionPerformed(evt);
            }
        });

        btnLui.setBackground(new java.awt.Color(255, 255, 255));
        btnLui.setText("<");
        btnLui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuiActionPerformed(evt);
            }
        });

        btnToi.setBackground(new java.awt.Color(255, 255, 255));
        btnToi.setText(">");
        btnToi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnToiActionPerformed(evt);
            }
        });

        jLabel11.setText("Email");

        txtEmail.setBorder(null);

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel12.setText("Số Điện Thoại");

        txtSdt.setBorder(null);

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel13.setText("Căn Cước Công Dân");

        txtCccd.setBorder(null);

        jPanel8.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel14.setText("Địa Chỉ");

        txtDiaChi.setBorder(null);

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3, Short.MAX_VALUE)
        );

        jLabel15.setText("Giới Tính");

        rdoNam.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(rdoNam);
        rdoNam.setSelected(true);
        rdoNam.setText("Nam");

        rdoNu.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(rdoNu);
        rdoNu.setText("Nữ");

        jLabel16.setText("Ngày Sinh");

        dtcNgaySinh.setBackground(new java.awt.Color(255, 255, 255));
        dtcNgaySinh.setToolTipText("");
        dtcNgaySinh.setDateFormatString("dd-MM-yyyy");

        jLabel17.setText("Trạng thái:");

        rdodanglam.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup3.add(rdodanglam);
        rdodanglam.setSelected(true);
        rdodanglam.setText("Đang làm");

        rdodanghi.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup3.add(rdodanghi);
        rdodanghi.setText("Đã nghĩ");

        javax.swing.GroupLayout pnl_capNhatLayout = new javax.swing.GroupLayout(pnl_capNhat);
        pnl_capNhat.setLayout(pnl_capNhatLayout);
        pnl_capNhatLayout.setHorizontalGroup(
            pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addComponent(btnThem, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(btnLamMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCapNhat, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLui, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(btnToi, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtHoTen)
                                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtMaNV)
                                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                    .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtMatKhau1)
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_capNhatLayout.createSequentialGroup()
                                                        .addGap(0, 0, Short.MAX_VALUE)
                                                        .addComponent(txtMatKhau2, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(134, 134, 134)))
                                    .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblShowMatKhau1)
                                        .addComponent(lblShowMatKhau2))))
                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnl_capNhatLayout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdoTruongPhong))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnl_capNhatLayout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addGap(18, 18, 18)
                                        .addComponent(rdodanglam)))
                                .addGap(10, 10, 10)
                                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rdodanghi, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rdoNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(18, 18, 18)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtSdt, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCccd, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnl_capNhatLayout.createSequentialGroup()
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(dtcNgaySinh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pnl_capNhatLayout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(rdoNam, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(rdoNu, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblHinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(46, 46, 46))))
        );
        pnl_capNhatLayout.setVerticalGroup(
            pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtMaNV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtHoTen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtMatKhau1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblShowMatKhau1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtMatKhau2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblShowMatKhau2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblHinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnl_capNhatLayout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtSdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtCccd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel16)
                        .addComponent(dtcNgaySinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdodanglam)
                            .addComponent(rdodanghi))
                        .addComponent(jLabel17)))
                .addGap(41, 41, 41)
                .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(rdoNam)
                            .addComponent(rdoNu))
                        .addGap(18, 40, Short.MAX_VALUE)
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnLui)
                                .addComponent(btnToi))
                            .addComponent(btnCapNhat)
                            .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btnThem)
                                .addComponent(btnLamMoi)))
                        .addGap(47, 47, 47))
                    .addGroup(pnl_capNhatLayout.createSequentialGroup()
                        .addGroup(pnl_capNhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(rdoTruongPhong)
                            .addComponent(rdoNhanVien))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pnl_big.addTab("Cập Nhật", pnl_capNhat);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(726, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnl_big, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(pnl_big, javax.swing.GroupLayout.PREFERRED_SIZE, 485, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 903, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnToiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnToiActionPerformed
	toi();
    }//GEN-LAST:event_btnToiActionPerformed

    private void btnLuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuiActionPerformed

	lui();
    }//GEN-LAST:event_btnLuiActionPerformed

    private void btnCapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatActionPerformed
	if (kiemTraLoi()) {
	    suaNV();
	}
    }//GEN-LAST:event_btnCapNhatActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
	clearForm();
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
	if (kiemTraLoi()) {
	    themNV();
	}
    }//GEN-LAST:event_btnThemActionPerformed

    private void lblShowMatKhau2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblShowMatKhau2MouseExited
	txtMatKhau2.setEchoChar('*');
	URL url = CuaSoDangNhap.class.getResource("/com/img/hidden.png");
	lblShowMatKhau2.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lblShowMatKhau2MouseExited

    private void lblShowMatKhau2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblShowMatKhau2MouseEntered
	txtMatKhau2.setEchoChar((char) 0);
	URL url = CuaSoDangNhap.class.getResource("/com/img/view.png");
	lblShowMatKhau2.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lblShowMatKhau2MouseEntered

    private void lblShowMatKhau1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblShowMatKhau1MouseExited
	txtMatKhau1.setEchoChar('*');
	URL url = CuaSoDangNhap.class.getResource("/com/img/hidden.png");
	lblShowMatKhau1.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lblShowMatKhau1MouseExited

    private void lblShowMatKhau1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblShowMatKhau1MouseEntered
	txtMatKhau1.setEchoChar((char) 0);
	URL url = CuaSoDangNhap.class.getResource("/com/img/view.png");
	lblShowMatKhau1.setIcon(new ImageIcon(url));
    }//GEN-LAST:event_lblShowMatKhau1MouseEntered

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
	timKiem();
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
	// TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void tblNhanVienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhanVienMouseClicked
	if (evt.getClickCount() == 2) {
	    index = tblNhanVien.getSelectedRow();
	    edit();
	}
    }//GEN-LAST:event_tblNhanVienMouseClicked

    private void txtMatKhau2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMatKhau2ActionPerformed
	// TODO add your handling code here:
    }//GEN-LAST:event_txtMatKhau2ActionPerformed

    private void txtMatKhau1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMatKhau1ActionPerformed
	// TODO add your handling code here:
    }//GEN-LAST:event_txtMatKhau1ActionPerformed

    private void lblHinhAnhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblHinhAnhMouseClicked
	try {
	    JFileChooser fc = new JFileChooser("image\\");

	    //	    lọc file hình ảnh
	    FileFilter filter = new FileNameExtensionFilter("Image Files", "png", "GIF", "jpg");
	    fc.setFileFilter(filter);
	    //	    Mở hộp thoại
	    fc.showOpenDialog(null);
	    File f = fc.getSelectedFile();
	    Ximg.save_img(f);
	    ImageIcon icon = Ximg.read_img(f.getName());
	    if (icon.getIconHeight() > 100) {
		JOptionPane.showMessageDialog(this, "Chọn ảnh 100x100 để có chất lượng tốt nhất!");
	    }
	    lblHinhAnh.setIcon(icon);
	    lblHinhAnh.setToolTipText(f.getName());
	} catch (IllegalArgumentException e) {
	    //            Msg_Box.alert(this, "Bạn chưa chọn hình ảnh");
	} catch (NullPointerException e) {

	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
    }//GEN-LAST:event_lblHinhAnhMouseClicked

    private void txtTimKiemKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTimKiemKeyReleased
	// TODO add your handling code here:
	timKiem();
    }//GEN-LAST:event_txtTimKiemKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
	/* Set the Nimbus look and feel */
	//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
	/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
	 */
	try {
	    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
		if ("Windows".equals(info.getName())) {
		    javax.swing.UIManager.setLookAndFeel(info.getClassName());
		    break;
		}
	    }
	} catch (ClassNotFoundException ex) {
	    java.util.logging.Logger.getLogger(QuanLyNhanVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (InstantiationException ex) {
	    java.util.logging.Logger.getLogger(QuanLyNhanVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (IllegalAccessException ex) {
	    java.util.logging.Logger.getLogger(QuanLyNhanVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	} catch (javax.swing.UnsupportedLookAndFeelException ex) {
	    java.util.logging.Logger.getLogger(QuanLyNhanVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	}
	//</editor-fold>
	//</editor-fold>

	/* Create and display the dialog */
	java.awt.EventQueue.invokeLater(new Runnable() {
	    public void run() {
		QuanLyNhanVien dialog = new QuanLyNhanVien(new javax.swing.JFrame(), true);
		dialog.addWindowListener(new java.awt.event.WindowAdapter() {
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent e) {
			System.exit(0);
		    }
		});
		dialog.setVisible(true);
	    }
	});
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCapNhat;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnLui;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnToi;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private com.toedter.calendar.JDateChooser dtcNgaySinh;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblHinhAnh;
    private javax.swing.JLabel lblShowMatKhau1;
    private javax.swing.JLabel lblShowMatKhau2;
    private javax.swing.JTabbedPane pnl_big;
    private javax.swing.JPanel pnl_capNhat;
    private javax.swing.JPanel pnl_danhSach;
    private javax.swing.JPanel pnl_timKiem;
    private javax.swing.JRadioButton rdoNam;
    private javax.swing.JRadioButton rdoNhanVien;
    private javax.swing.JRadioButton rdoNu;
    private javax.swing.JRadioButton rdoTruongPhong;
    private javax.swing.JRadioButton rdodanghi;
    private javax.swing.JRadioButton rdodanglam;
    private javax.swing.JTable tblNhanVien;
    private javax.swing.JTextField txtCccd;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtMaNV;
    private javax.swing.JPasswordField txtMatKhau1;
    private javax.swing.JPasswordField txtMatKhau2;
    private javax.swing.JTextField txtSdt;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
