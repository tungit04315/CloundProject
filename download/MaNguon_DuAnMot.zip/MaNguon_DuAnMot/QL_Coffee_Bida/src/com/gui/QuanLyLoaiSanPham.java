/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.LoaiDao;
import com.model.LoaiSanPham;
import com.utils.MsgBox;
import com.utils.Ximg;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author tungt
 */
public class QuanLyLoaiSanPham extends javax.swing.JDialog {

    /**
     * Creates new form Product_Type_Interface
     */
    LoaiDao dao = new LoaiDao();
    int index = -1;

    public QuanLyLoaiSanPham(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();

    }

    void init() {
        this.setIconImage(Ximg.getImage());
        fill_tbl();
        trangThaiNut();
        index = -1;
    }

    void trangThaiNut() {
        boolean k = (this.index >= 0);

        btn_sua.setEnabled(k);
        btn_xoa.setEnabled(k);

        btn_them.setEnabled(!k);

    }

    boolean kiemTraLoi() {

        if (txt_tenLoaiSP.getText().equalsIgnoreCase("")) {
            txt_tenLoaiSP.requestFocus();
            MsgBox.alert(this, "Không để trống tên loại sản phẩm");
            return false;
        }

        return true;
    }

    boolean kiemTraTenLoai() {
        List<LoaiSanPham> list = dao.selectAll();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getTenSP().equalsIgnoreCase(txt_tenLoaiSP.getText())) {
                txt_tenLoaiSP.requestFocus();
                MsgBox.alert(this, "Trùng tên loại sản phẩm");
                return false;
            }
        }
        return true;
    }

    boolean kiemTraTenLoaiCapNhat() {
        List<LoaiSanPham> list = dao.selectAll();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getTenSP().equalsIgnoreCase(txt_tenLoaiSP.getText())) {
                if(index == i){
                    return true;
                }else {
                    txt_tenLoaiSP.requestFocus();
                    MsgBox.alert(this, "Trùng tên loại sản phẩm");
                    return false;
                }
               
            }
        }
        return true;
    }

    void clear() {
        txt_tenLoaiSP.setText("");
        index = -1;
        trangThaiNut();

    }

    void fill_tbl() {
        DefaultTableModel tblmd = (DefaultTableModel) tbl_loaiSP.getModel();
        tblmd.setRowCount(0);
        try {
            List<LoaiSanPham> list = dao.selectAll();
            for (LoaiSanPham l : list) {
                Object[] row = {l.getMaSp(), l.getTenSP()};
                tblmd.addRow(row);

            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    LoaiSanPham getForm() {
        LoaiSanPham l = new LoaiSanPham();
        int ma = (int) tbl_loaiSP.getValueAt(index, 0);
        l.setMaSp(ma);
        l.setTenSP(txt_tenLoaiSP.getText());
        return l;
    }

    LoaiSanPham getForm_add() {
        LoaiSanPham l = new LoaiSanPham();

        l.setTenSP(txt_tenLoaiSP.getText());
        return l;
    }

    void setForm(LoaiSanPham l) {
        txt_tenLoaiSP.setText(l.getTenSP());
    }

    void edit() {
        int maSP = (int) tbl_loaiSP.getValueAt(index, 0);
        LoaiSanPham s = dao.select_byID(String.valueOf(maSP));
        setForm(s);
        trangThaiNut();
    }

    void themSanPham() {
        LoaiSanPham l = getForm_add();
        try {
            dao.insert(l);
            fill_tbl();
            clear();
            MsgBox.alert(this, "Thêm sản phẩm thành công");
        } catch (Exception e) {
            System.out.println(e);
            MsgBox.alert(this, "Thêm sản phẩm thất bại");
        }
    }

    void capNhatSanPham() {
        LoaiSanPham l = getForm();
        try {

            dao.update(l);
            fill_tbl();
            clear();
            MsgBox.alert(this, "Cập nhật sản phẩm thành công");
        } catch (Exception e) {
            System.out.println(e);
            MsgBox.alert(this, "Cập nhật sản phẩm thất bại");
        }
    }

    void xoaSanPham() {
        int maSP = (int) tbl_loaiSP.getValueAt(index, 0);
        try {
            if (MsgBox.confirm(this, "Bạn có chắc muốn xoá loại sản phẩm này không ?")) {
                dao.delete(String.valueOf(maSP));
                fill_tbl();
                clear();
                MsgBox.alert(this, "Xoá sản phẩm thành công");
            }
        } catch (Exception e) {
            MsgBox.alert(this, "Xoá sản phẩm thất bại");
        }
    }

    void timKiem() {
        DefaultTableModel tblmd = (DefaultTableModel) tbl_loaiSP.getModel();
        tblmd.setRowCount(0);
        try {
            String ten = txt_tenLoaiSP.getText();
            List<LoaiSanPham> list = dao.searchLSP(ten);
            for (LoaiSanPham l : list) {
                Object[] row = {l.getMaSp(), l.getTenSP()};
                tblmd.addRow(row);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_background1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_loaiSP = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_tenLoaiSP = new javax.swing.JTextField();
        btn_them = new javax.swing.JButton();
        btn_lamMoi = new javax.swing.JButton();
        btn_sua = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        btn_tim = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản lý loại sản phẩm");
        setUndecorated(true);

        pnl_background1.setBackground(new java.awt.Color(255, 255, 255));
        pnl_background1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("QUẢN LÝ LOẠI SẢN PHẨM");

        tbl_loaiSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Mã Loại Sản Phẩm", "Tên Loại Sản Phẩm"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_loaiSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_loaiSPMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_loaiSP);
        if (tbl_loaiSP.getColumnModel().getColumnCount() > 0) {
            tbl_loaiSP.getColumnModel().getColumn(0).setMinWidth(130);
            tbl_loaiSP.getColumnModel().getColumn(0).setMaxWidth(130);
        }

        jPanel1.setBackground(new java.awt.Color(243, 243, 243));

        jLabel2.setText("Tên loại sản phẩm");

        btn_them.setBackground(new java.awt.Color(255, 255, 255));
        btn_them.setText("Thêm ");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_lamMoi.setBackground(new java.awt.Color(255, 255, 255));
        btn_lamMoi.setText("Làm mới");
        btn_lamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lamMoiActionPerformed(evt);
            }
        });

        btn_sua.setBackground(new java.awt.Color(255, 255, 255));
        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_xoa.setBackground(new java.awt.Color(255, 255, 255));
        btn_xoa.setText("Xoá");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        btn_tim.setBackground(new java.awt.Color(255, 255, 255));
        btn_tim.setText("Tìm");
        btn_tim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_tenLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_lamMoi)
                        .addGap(18, 18, 18)
                        .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btn_xoa, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                        .addComponent(btn_tim, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_tenLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_lamMoi)
                    .addComponent(btn_sua)
                    .addComponent(btn_xoa)
                    .addComponent(btn_tim))
                .addContainerGap())
        );

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/close_button.png"))); // NOI18N
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnl_background1Layout = new javax.swing.GroupLayout(pnl_background1);
        pnl_background1.setLayout(pnl_background1Layout);
        pnl_background1Layout.setHorizontalGroup(
            pnl_background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_background1Layout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(pnl_background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_background1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(235, 235, 235)
                        .addComponent(jLabel4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnl_background1Layout.createSequentialGroup()
                        .addGroup(pnl_background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );
        pnl_background1Layout.setVerticalGroup(
            pnl_background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnl_background1Layout.createSequentialGroup()
                .addGroup(pnl_background1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(pnl_background1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_background1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_background1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        if (kiemTraLoi()) {
            if (kiemTraTenLoai()) {
                themSanPham();
            }
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_lamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lamMoiActionPerformed
        clear();
    }//GEN-LAST:event_btn_lamMoiActionPerformed

    private void tbl_loaiSPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_loaiSPMouseClicked

        index = tbl_loaiSP.getSelectedRow();
        edit();

    }//GEN-LAST:event_tbl_loaiSPMouseClicked

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        if (kiemTraLoi()) {
            if (kiemTraTenLoaiCapNhat()) {
                capNhatSanPham();
            }
        }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        xoaSanPham();
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void btn_timActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timActionPerformed
        timKiem();
    }//GEN-LAST:event_btn_timActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        // TODO add your handling code here:
        if (MsgBox.confirm(this, "Bạn có chắc chắn muốn thoát không ?")) {
//            System.exit(0);
            dispose();
        } else {

        }
    }//GEN-LAST:event_jLabel4MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoaiSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoaiSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoaiSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoaiSanPham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuanLyLoaiSanPham dialog = new QuanLyLoaiSanPham(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_lamMoi;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_tim;
    private javax.swing.JButton btn_xoa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel pnl_background1;
    private javax.swing.JTable tbl_loaiSP;
    private javax.swing.JTextField txt_tenLoaiSP;
    // End of variables declaration//GEN-END:variables
}
