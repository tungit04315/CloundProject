/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.BanDao;
import com.dao.OrderDao;
import com.model.Ban;
import com.utils.MsgBox;
import com.utils.Ximg;
import java.util.List;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author tungt
 */
public class ChuyenBan extends javax.swing.JDialog {

    /**
     * Creates new form ChuyenBan
     */
    OrderDao daoOrders = new OrderDao();
    BanDao daoBan = new BanDao();
    int a;

    public ChuyenBan(java.awt.Frame parent, boolean modal, int maBanCu) {
        super(parent, modal);
        initComponents();
        a= maBanCu;       
        
         this.setIconImage(Ximg.getImage());
         fillListTable();
    }

    void fillListTable() {

   DefaultComboBoxModel cbomd = (DefaultComboBoxModel) cboBan.getModel();
        cbomd.removeAllElements();
        List<Ban> list = daoBan.selectAll();
        for (Ban s : list) {
            if(a==s.getMaBan()){
                
            }else{
                  cbomd.addElement(s.getTenBan());
            }
        }
    }

    void chuyenBan() {
        int maBanMoi = daoOrders.toMaBan((String) cboBan.getSelectedItem());
        daoBan.chuyenBan(a, maBanMoi);
        MsgBox.alert(null, "Chuyển bàn thành công");
        this.dispose();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTieuDe = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        cboBan = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        lblHinhNen = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Chuyển Bàn");
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblTieuDe.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        lblTieuDe.setForeground(new java.awt.Color(255, 255, 255));
        lblTieuDe.setText("Chuyển Bàn");
        getContentPane().add(lblTieuDe, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 120, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Bàn muốn chuyển tới");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, -1, -1));

        cboBan.setBackground(java.awt.Color.pink);
        getContentPane().add(cboBan, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 190, -1));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Chuyển");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 90, -1));

        lblHinhNen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/banChuyen (1).jpg"))); // NOI18N
        getContentPane().add(lblHinhNen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 230));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        chuyenBan();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ChuyenBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ChuyenBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ChuyenBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ChuyenBan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ChuyenBan dialog = new ChuyenBan(new javax.swing.JFrame(), true,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cboBan;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel lblHinhNen;
    private javax.swing.JLabel lblTieuDe;
    // End of variables declaration//GEN-END:variables
}
