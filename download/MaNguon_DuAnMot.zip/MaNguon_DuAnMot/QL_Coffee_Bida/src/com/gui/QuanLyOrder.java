/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package com.gui;

import com.dao.HoaDonChiTietDao;
import com.dao.HoaDonDao;
import com.dao.LoaiDao;
import com.dao.MenuDao;
import com.dao.OrderDao;
import com.model.Order;
import com.model.SanPham;
import com.helper.ConnectionDatabase;
import com.model.HoaDon;
import com.model.HoaDonChiTiet;
import com.model.LoaiSanPham;
import com.utils.MsgBox;
import com.utils.XAuth;
import com.utils.Ximg;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.Timer;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author tungt
 */
public class QuanLyOrder extends javax.swing.JDialog {

    /**
     * Creates new form Order_Management_Interface
     */
    MenuDao menu_Dao = new MenuDao();
    OrderDao or_dao = new OrderDao();
    HoaDonChiTietDao hdct_dao = new HoaDonChiTietDao();

    int index = -1;
    String banDuocChon = "";
    int SL = 0;

    Date date = new Date();

    public QuanLyOrder(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setIconImage(Ximg.getImage());
        init();
    }

    void init() {
        fillToMenu();
        fillCboLoai();
        trangThaiTextField();
        chayTB();
        lbl_anhSanPham.resize(100, 100);
    }

    void chayTB() {
        new Timer(15, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int x = lbl_thongBao.getX();
                int y = lbl_thongBao.getY();

                if (x == 350) {
                    x = 0;
                } else {
                    x++;
                }
                lbl_thongBao.setLocation(x, y);
            }
        }).start();
    }

    void fillCboLoai() {
        DefaultComboBoxModel cbomd = (DefaultComboBoxModel) cboLoaiSanPham.getModel();
        cbomd.removeAllElements();
        cbomd.addElement("Tất cả");
        List<LoaiSanPham> list = loai_Dao.selectAll();
        for (LoaiSanPham s : list) {
            cbomd.addElement(s.getTenSP());
        }
    }

    void fillToMenu() {
        DefaultTableModel tblmd = (DefaultTableModel) tbl_menu.getModel();
        tblmd.setRowCount(0);
        try {
            List<SanPham> list = menu_Dao.selectAll();
            for (SanPham s : list) {
                Object[] row = {s.getTenSP(), s.getGia()};
                tblmd.addRow(row);
                //   lbl_anhSanPham.setIcon(Ximg.read_img(s.getHinhAnh()));
                // System.out.println("a: "+Ximg.read_img(s.getHinhAnh()));
            }
        } catch (Exception e) {

        }
    }

    void setForm(SanPham s) {
//        System.out.println(s.getHinhAnh());
        if (s.getHinhAnh() == null) {
            lbl_anhSanPham.setText("Ảnh SP");
        } else {
            ImageIcon icon = Ximg.read_img(s.getHinhAnh());
            Image scale = icon.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
            lbl_anhSanPham.setText("");
            lbl_anhSanPham.setIcon(icon);

        }

    }

    Order getForm() {
        index = tbl_menu.getSelectedRow();
        int maBan = or_dao.toMaBan(banDuocChon);
        String maSP = or_dao.toMaMon(String.valueOf(tbl_menu.getValueAt(index, 0)));
        Order or = new Order();
        or.setMaBan(maBan);
        or.setMaMon(maSP);
        or.setMaNV(XAuth.user.getMaNV());
//       XAuth.user.getMaNV()
        return or;
    }

    void edit() {
        String tenSP = (String) tbl_menu.getValueAt(index, 0);
        SanPham s = menu_Dao.select_byname(tenSP);
        setForm(s);
    }

    void fillToOrders(String tenBan) {
        pnl_big.setSelectedIndex(1);
        DefaultTableModel tbl_or = (DefaultTableModel) tbl_order.getModel();
        tbl_or.setRowCount(0);
        try {
            Connection conn = (Connection) ConnectionDatabase.openConn();
            String selectAllname = "select SanPham.tenSP, SanPham.gia, COUNT(Orders.maBan) as N'SoLuong', SUM(SanPham.gia) as N'ThanhTien'\n"
                    + "from Orders inner join SanPham on Orders.maMon = SanPham.maSP\n"
                    + "where Orders.maBan = ?\n"
                    + "group by SanPham.tenSP, SanPham.gia";
            int maBan = or_dao.toMaBan(tenBan);

            PreparedStatement ps = conn.prepareStatement(selectAllname);
            ps.setInt(1, maBan);
            ResultSet rs = (ResultSet) ps.executeQuery();

            double thanhTien = 0;

            while (rs.next()) {
                Vector v = new Vector();
                v.add(rs.getString("tenSP"));
                v.add(rs.getString("gia"));
                v.add(rs.getString("SoLuong"));
                v.add(rs.getString("ThanhTien"));
                tbl_or.addRow(v);

                thanhTien += Double.parseDouble(rs.getString("ThanhTien"));
            }

            tbl_order.setModel(tbl_or);
            txt_thanhTien.setText(String.valueOf(thanhTien) + " VNĐ");

            conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    void themOrders() {
        index = tbl_menu.getSelectedRow();
        String tenMon = (String) tbl_menu.getValueAt(index, 0);
        SL = MsgBox.prompt(this, tenMon);
        Order or = getForm();
        try {
            for (int i = 0; i < SL; i++) {
                or_dao.insert(or);
                fillToOrders(banDuocChon);
                tbl_menu.clearSelection();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void xoaOrders() {
        try {

            index = tbl_order.getSelectedRow();
            String maSP = or_dao.toMaMon(String.valueOf(tbl_order.getValueAt(index, 0)));
            int slCoSan = or_dao.soLuongMon(maSP, or_dao.toMaBan(lblBan.getText()));

            SL = MsgBox.prompt(this, String.valueOf(tbl_order.getValueAt(index, 0)));
//            System.out.println(SL);
            if (SL > slCoSan) {
                MsgBox.alert(this, "Vui lòng chọn số lượng nhỏ hơn");
            } else {
                or_dao.delete2(SL, maSP);
                fillToOrders(banDuocChon);
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    boolean kiemTra() {
        if (banDuocChon == "") {
            MsgBox.alert(this, "Bạn chưa chọn bàn !");
            pnl_big.setSelectedIndex(0);
            return false;
        }
        return true;
    }
    LoaiDao loai_Dao = new LoaiDao();

    void locSanPham() {
        try {
            if (cboLoaiSanPham.getSelectedIndex() <= 0) {
                fillToMenu();
            } else {
                DefaultTableModel tblmd = (DefaultTableModel) tbl_menu.getModel();
                tblmd.setRowCount(0);
                int maLoai = loai_Dao.toMaLoai((String) cboLoaiSanPham.getSelectedItem());
                List<SanPham> list = menu_Dao.selectMaLoai(maLoai);
                for (SanPham s : list) {
                    Object[] row = {s.getTenSP(), s.getGia()};
                    tblmd.addRow(row);
                    lbl_anhSanPham.setIcon(Ximg.read_img(s.getHinhAnh()));
                }
            }
        } catch (Exception e) {

        }

    }

    void timKiemSanPham() {
        try {
            DefaultTableModel tblmd = (DefaultTableModel) tbl_menu.getModel();
            tblmd.setRowCount(0);
            List<SanPham> list = menu_Dao.searchSP(txtTiemKiemSanPham.getText());
            for (SanPham s : list) {
                Object[] row = {s.getTenSP(), s.getGia()};
                tblmd.addRow(row);
                lbl_anhSanPham.setIcon(Ximg.read_img(s.getHinhAnh()));
            }
        } catch (Exception e) {
        }

    }
    HoaDonDao hdDao = new HoaDonDao();

    void HoaDon() {
        try {
            int maBan = or_dao.toMaBan(banDuocChon);
            List<Order> list = or_dao.selectAll2(maBan);

            HoaDon h = new HoaDon();

            h.setMaBan(maBan);
            h.setNgayTao(date);
            h.setMaNV(XAuth.user.getMaNV());

            hdDao.insert(h);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e);
        }

    }

    void HoaDonChiTiet() {
        try {
            Random ngauNhien = new Random();
            int soNN = 0;
            for (int a = 0; a <= 6; a++) {
                soNN = ngauNhien.nextInt(1000);
            }
            int maBan = or_dao.toMaBan(banDuocChon);
            List<HoaDonChiTiet> list = new ArrayList<HoaDonChiTiet>();
            int maHoaDon = hdct_dao.getMaHDVuaThem();

            for (int i = 0; i < tbl_order.getRowCount(); i++) {
                HoaDonChiTiet hdct = new HoaDonChiTiet();

                String masp = menu_Dao.toMaMon((String) tbl_order.getValueAt(i, 0));
                int SL = Integer.parseInt((String) tbl_order.getValueAt(i, 2));
                float gia = menu_Dao.togia(masp);
                float tongTien = Float.parseFloat(tbl_order.getValueAt(i, 3).toString());

//                System.out.println("infor: " + masp + " | " + SL + " | " + gia + " | " + tongTien);
                hdct.setMaHD(maHoaDon);
                hdct.setMaSP(masp);
                hdct.setSoLuong(SL);
                hdct.setGia(gia);
                hdct.setThanhTien(tongTien);

                list.add(hdct);

                hdct_dao.insert(hdct);
            }

        } catch (Exception e) {
            e.printStackTrace();
//            System.out.println(e);
        }

    }

    void fileHoaDon() {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Hoá Đơn");
        XSSFRow row = null;
        Cell cell = null;

        row = sheet.createRow(3); // thụt trên trái 3 hàng
        cell = row.createCell(0, CellType.STRING);
        cell.setCellValue("Mã Hoá Đơn");
        cell = row.createCell(1, CellType.STRING);
        cell.setCellValue("Tên Bàn");
        cell = row.createCell(2, CellType.STRING);
        cell.setCellValue("Tên Món");
        cell = row.createCell(3, CellType.STRING);
        cell.setCellValue("Số Lượng");
        cell = row.createCell(4, CellType.STRING);
        cell.setCellValue("Đơn Giá");
        cell = row.createCell(5, CellType.STRING);
        cell.setCellValue("Tổng Tiền");
        cell = row.createCell(6, CellType.STRING);
        cell.setCellValue("Thời Gian");
        cell = row.createCell(7, CellType.STRING);
        cell.setCellValue("Nhân Viên");

        //
        Random ngauNhien = new Random();
        int soNN = 0;
        for (int a = 0; a <= 6; a++) {
            soNN = ngauNhien.nextInt(1000);
        }

        SimpleDateFormat fomat = new SimpleDateFormat("dd-MM-yyyy");
        String ngayTao = fomat.format(date);
        DefaultTableModel tbl_or = (DefaultTableModel) tbl_order.getModel();
        for (int i = 0; i < tbl_or.getRowCount(); i++) {

            row = sheet.createRow(4 + i);

            cell = row.createCell(0, CellType.STRING);
            cell.setCellValue(soNN);

            cell = row.createCell(1, CellType.STRING);
            cell.setCellValue(banDuocChon);

            cell = row.createCell(2, CellType.STRING);
            cell.setCellValue(tbl_order.getValueAt(i, 0).toString());

            cell = row.createCell(3, CellType.STRING);
            cell.setCellValue(tbl_order.getValueAt(i, 2).toString());

            cell = row.createCell(4, CellType.STRING);
            cell.setCellValue(tbl_order.getValueAt(i, 1).toString());

            cell = row.createCell(5, CellType.STRING);
            cell.setCellValue(tbl_order.getValueAt(i, 3).toString());

            cell = row.createCell(6, CellType.STRING);
            cell.setCellValue(ngayTao);

            cell = row.createCell(7, CellType.STRING);
            cell.setCellValue(XAuth.user.getMaNV());
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Lưu Hoá Đơn");
        int userSelection = fileChooser.showSaveDialog(null);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try {
                FileOutputStream fis = new FileOutputStream(fileToSave);
                workbook.write(fis);
                fis.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    void xoaTblOrders() {
        try {
            int maBan = or_dao.toMaBan(banDuocChon);
            or_dao.delete(String.valueOf(maBan));
            fillToOrders(banDuocChon);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    void trangThaiTextField() {
        txt_phi.setEditable(false);
        txt_thanhTien.setEditable(false);
    }

    void thanhToan() {
        HoaDon();

        HoaDonChiTiet();
        fileHoaDon();
        xoaTblOrders();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pnl_big = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        btn_banMot = new javax.swing.JButton();
        btn_banBa = new javax.swing.JButton();
        btn_banNam = new javax.swing.JButton();
        btn_banBay = new javax.swing.JButton();
        btn_banChin = new javax.swing.JButton();
        btn_banHai = new javax.swing.JButton();
        btn_banMuoiMot = new javax.swing.JButton();
        btn_banBon = new javax.swing.JButton();
        btn_banSau = new javax.swing.JButton();
        btn_banTam = new javax.swing.JButton();
        btn_banMuoi = new javax.swing.JButton();
        btn_banMuoiHai = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lbl_thongBao = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txt_phi = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txt_thanhTien = new javax.swing.JTextField();
        btn_thanhToan = new javax.swing.JButton();
        lblBan = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_menu = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        cboLoaiSanPham = new javax.swing.JComboBox<>();
        txtTiemKiemSanPham = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        lbl_anhSanPham = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_order = new javax.swing.JTable();
        btn_goiMon = new javax.swing.JButton();
        btn_xoaMon = new javax.swing.JButton();
        btnChuyenBan = new javax.swing.JButton();
        btnTachBan = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản lý order");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pnl_big.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBackground(new java.awt.Color(117, 83, 83));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Bàn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(255, 255, 255))); // NOI18N

        btn_banMot.setBackground(new java.awt.Color(255, 255, 255));
        btn_banMot.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banMot.setText("Bàn 1");
        btn_banMot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banMotActionPerformed(evt);
            }
        });

        btn_banBa.setBackground(new java.awt.Color(255, 255, 255));
        btn_banBa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banBa.setText("Bàn 3");
        btn_banBa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banBaActionPerformed(evt);
            }
        });

        btn_banNam.setBackground(new java.awt.Color(255, 255, 255));
        btn_banNam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banNam.setText("Bàn 5");
        btn_banNam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banNamActionPerformed(evt);
            }
        });

        btn_banBay.setBackground(new java.awt.Color(255, 255, 255));
        btn_banBay.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banBay.setText("Bàn 7");
        btn_banBay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banBayActionPerformed(evt);
            }
        });

        btn_banChin.setBackground(new java.awt.Color(255, 255, 255));
        btn_banChin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banChin.setText("Bàn 9");
        btn_banChin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banChinActionPerformed(evt);
            }
        });

        btn_banHai.setBackground(new java.awt.Color(255, 255, 255));
        btn_banHai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banHai.setText("Bàn 2");
        btn_banHai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banHaiActionPerformed(evt);
            }
        });

        btn_banMuoiMot.setBackground(new java.awt.Color(255, 255, 255));
        btn_banMuoiMot.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banMuoiMot.setText("Bàn 11");
        btn_banMuoiMot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banMuoiMotActionPerformed(evt);
            }
        });

        btn_banBon.setBackground(new java.awt.Color(255, 255, 255));
        btn_banBon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banBon.setText("Bàn 4");
        btn_banBon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banBonActionPerformed(evt);
            }
        });

        btn_banSau.setBackground(new java.awt.Color(255, 255, 255));
        btn_banSau.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banSau.setText("Bàn 6");
        btn_banSau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banSauActionPerformed(evt);
            }
        });

        btn_banTam.setBackground(new java.awt.Color(255, 255, 255));
        btn_banTam.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banTam.setText("Bàn 8");
        btn_banTam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banTamActionPerformed(evt);
            }
        });

        btn_banMuoi.setBackground(new java.awt.Color(255, 255, 255));
        btn_banMuoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banMuoi.setText("Bàn 10");
        btn_banMuoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banMuoiActionPerformed(evt);
            }
        });

        btn_banMuoiHai.setBackground(new java.awt.Color(255, 255, 255));
        btn_banMuoiHai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/tablethuog.png"))); // NOI18N
        btn_banMuoiHai.setText("Bàn 12");
        btn_banMuoiHai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_banMuoiHaiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_banMot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banBa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banNam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banBay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banChin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banMuoiMot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_banHai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banBon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banSau, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banTam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banMuoi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_banMuoiHai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banMot, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banHai, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banBa, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banBon, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banNam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banSau, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banBay, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banTam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banChin, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banMuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_banMuoiMot, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_banMuoiHai, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("KHU VỰC NGOÀI");

        lbl_thongBao.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        lbl_thongBao.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/coffee-shop.png"))); // NOI18N
        lbl_thongBao.setText("Xin chào Quý Khách đã đến với Coffee Relax");
        lbl_thongBao.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/bgr.png"))); // NOI18N

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(lbl_thongBao, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(47, 47, 47)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(47, 47, 47)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addComponent(lbl_thongBao, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5.getAccessibleContext().setAccessibleName("Bàn");

        pnl_big.addTab("Bàn", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jPanel6.setBackground(new java.awt.Color(204, 204, 204));
        jPanel6.setPreferredSize(new java.awt.Dimension(171, 640));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Phí Phục Vụ");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel8.setText("Thành Tiền");

        btn_thanhToan.setBackground(new java.awt.Color(255, 255, 255));
        btn_thanhToan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/payment-method.png"))); // NOI18N
        btn_thanhToan.setText("Thanh Toán");
        btn_thanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thanhToanActionPerformed(evt);
            }
        });

        lblBan.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBan.setText("Bàn");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_phi, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblBan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_thanhToan)
                    .addComponent(txt_thanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel8)
                    .addComponent(txt_phi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_thanhTien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_thanhToan)
                    .addComponent(lblBan))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(239, 239, 239));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Menu"));

        tbl_menu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Tên Món", "Đơn Giá"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_menu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_menuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_menu);

        jLabel5.setText("Loại nước");

        cboLoaiSanPham.setBackground(java.awt.Color.pink);
        cboLoaiSanPham.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất Cả" }));
        cboLoaiSanPham.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboLoaiSanPhamActionPerformed(evt);
            }
        });

        btnTimKiem.setBackground(new java.awt.Color(255, 255, 255));
        btnTimKiem.setText("Tìm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        lbl_anhSanPham.setText("Ảnh Sản Phẩm");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cboLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addComponent(txtTiemKiemSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(lbl_anhSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cboLoaiSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTiemKiemSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(lbl_anhSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel8.setBackground(new java.awt.Color(239, 239, 239));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Order"));

        tbl_order.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Tên Món", "Đơn Giá", "Số Lượng", "Thành Tiền"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tbl_order);
        if (tbl_order.getColumnModel().getColumnCount() > 0) {
            tbl_order.getColumnModel().getColumn(0).setMinWidth(180);
            tbl_order.getColumnModel().getColumn(0).setMaxWidth(180);
        }

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 527, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );

        btn_goiMon.setBackground(new java.awt.Color(255, 255, 255));
        btn_goiMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/soda.png"))); // NOI18N
        btn_goiMon.setText("Gọi Món");
        btn_goiMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_goiMonActionPerformed(evt);
            }
        });

        btn_xoaMon.setBackground(new java.awt.Color(255, 255, 255));
        btn_xoaMon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/remove.png"))); // NOI18N
        btn_xoaMon.setText("Xoá Món");
        btn_xoaMon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaMonActionPerformed(evt);
            }
        });

        btnChuyenBan.setBackground(new java.awt.Color(255, 255, 255));
        btnChuyenBan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/img/change.png"))); // NOI18N
        btnChuyenBan.setText("Chuyển Bàn");
        btnChuyenBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChuyenBanActionPerformed(evt);
            }
        });

        btnTachBan.setText("Tách");
        btnTachBan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTachBanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(btn_goiMon)
                            .addGap(49, 49, 49)
                            .addComponent(btn_xoaMon)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnTachBan, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnChuyenBan))
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(btn_xoaMon)
                                .addComponent(btn_goiMon)
                                .addComponent(btnChuyenBan))
                            .addComponent(btnTachBan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(117, Short.MAX_VALUE))
        );

        pnl_big.addTab("Gọi Món", jPanel3);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("QUẢN LÝ ORDER");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_big)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pnl_big, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_banChinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banChinActionPerformed
        banDuocChon = btn_banChin.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banChinActionPerformed

    private void btn_banBayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banBayActionPerformed
        banDuocChon = btn_banBay.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banBayActionPerformed

    private void tbl_menuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_menuMouseClicked
        index = tbl_menu.getSelectedRow();
        edit();
    }//GEN-LAST:event_tbl_menuMouseClicked

    private void btn_banMotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banMotActionPerformed
        banDuocChon = btn_banMot.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banMotActionPerformed

    private void btn_goiMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_goiMonActionPerformed
        index = tbl_menu.getSelectedRow();
        if (index < 0) {
            MsgBox.alert(this, "Vui lòng chọn món");
        } else {
            if (kiemTra()) {
                themOrders();
//            ainsertOrder();
            }
        }

    }//GEN-LAST:event_btn_goiMonActionPerformed

    private void btn_xoaMonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaMonActionPerformed
        index = tbl_order.getSelectedRow();
        if (index < 0) {
            MsgBox.alert(this, "Vui lòng chọn món");
        } else
            xoaOrders();
    }//GEN-LAST:event_btn_xoaMonActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
        timKiemSanPham();
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void cboLoaiSanPhamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboLoaiSanPhamActionPerformed
        locSanPham();
    }//GEN-LAST:event_cboLoaiSanPhamActionPerformed

    private void btn_thanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thanhToanActionPerformed
        thanhToan();
        MsgBox.alert(this, "Thanh Toán Thành Công");
    }//GEN-LAST:event_btn_thanhToanActionPerformed

    private void btnChuyenBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChuyenBanActionPerformed
        int ma = or_dao.toMaBan(lblBan.getText());
        ChuyenBan a = new ChuyenBan(null, true, ma);
        a.setVisible(true);
        fillToOrders(banDuocChon);
    }//GEN-LAST:event_btnChuyenBanActionPerformed

    private void btn_banHaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banHaiActionPerformed
        banDuocChon = btn_banHai.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banHaiActionPerformed

    private void btn_banBaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banBaActionPerformed
        banDuocChon = btn_banBa.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banBaActionPerformed

    private void btn_banBonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banBonActionPerformed
        banDuocChon = btn_banBon.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banBonActionPerformed

    private void btn_banNamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banNamActionPerformed
        banDuocChon = btn_banNam.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banNamActionPerformed

    private void btn_banSauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banSauActionPerformed
        banDuocChon = btn_banSau.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banSauActionPerformed

    private void btn_banTamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banTamActionPerformed
        banDuocChon = btn_banTam.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banTamActionPerformed

    private void btn_banMuoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banMuoiActionPerformed
        banDuocChon = btn_banMuoi.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banMuoiActionPerformed

    private void btn_banMuoiMotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banMuoiMotActionPerformed
        banDuocChon = btn_banMuoiMot.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banMuoiMotActionPerformed

    private void btn_banMuoiHaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_banMuoiHaiActionPerformed
        banDuocChon = btn_banMuoiHai.getText();
        pnl_big.setSelectedIndex(1);
        fillToOrders(banDuocChon);
        lblBan.setText(banDuocChon);
    }//GEN-LAST:event_btn_banMuoiHaiActionPerformed

    private void btnTachBanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTachBanActionPerformed
        String maSP;
        int maBan;
        index = tbl_order.getSelectedRow();
        if (index >= 0) {
            maSP = or_dao.toMaMon((String) tbl_order.getValueAt(index, 0));
            maBan = or_dao.toMaBan(lblBan.getText());
            TachBan a = new TachBan(null, true, maSP, maBan);
            a.setVisible(true);
            fillToOrders(banDuocChon);
        } else {
            MsgBox.alert(this, "Chọn sản phẩm muốn tách");
        }

    }//GEN-LAST:event_btnTachBanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QuanLyOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QuanLyOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QuanLyOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QuanLyOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                QuanLyOrder dialog = new QuanLyOrder(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChuyenBan;
    private javax.swing.JButton btnTachBan;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btn_banBa;
    private javax.swing.JButton btn_banBay;
    private javax.swing.JButton btn_banBon;
    private javax.swing.JButton btn_banChin;
    private javax.swing.JButton btn_banHai;
    private javax.swing.JButton btn_banMot;
    private javax.swing.JButton btn_banMuoi;
    private javax.swing.JButton btn_banMuoiHai;
    private javax.swing.JButton btn_banMuoiMot;
    private javax.swing.JButton btn_banNam;
    private javax.swing.JButton btn_banSau;
    private javax.swing.JButton btn_banTam;
    private javax.swing.JButton btn_goiMon;
    private javax.swing.JButton btn_thanhToan;
    private javax.swing.JButton btn_xoaMon;
    private javax.swing.JComboBox<String> cboLoaiSanPham;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblBan;
    private javax.swing.JLabel lbl_anhSanPham;
    private javax.swing.JLabel lbl_thongBao;
    private javax.swing.JTabbedPane pnl_big;
    private javax.swing.JTable tbl_menu;
    private javax.swing.JTable tbl_order;
    private javax.swing.JTextField txtTiemKiemSanPham;
    private javax.swing.JTextField txt_phi;
    private javax.swing.JTextField txt_thanhTien;
    // End of variables declaration//GEN-END:variables
}
