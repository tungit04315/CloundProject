/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.model;

import java.util.Date;

/**
 *
 * @author tungt
 */
public class HoaDon {

    private int maBan, maOrder;
    private String maNV;
    private Date ngayTao;

    public HoaDon() {
    }

    public HoaDon(int maBan, int maOrder, String maNV, Date ngayTao, String maSP) {

        this.maBan = maBan;
        this.maOrder = maOrder;
        this.maNV = maNV;
        this.ngayTao = ngayTao;
       
    }

 

    public int getMaBan() {
        return maBan;
    }

    public void setMaBan(int maBan) {
        this.maBan = maBan;
    }

    public int getMaOrder() {
        return maOrder;
    }

    public void setMaOrder(int maOrder) {
        this.maOrder = maOrder;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

}
