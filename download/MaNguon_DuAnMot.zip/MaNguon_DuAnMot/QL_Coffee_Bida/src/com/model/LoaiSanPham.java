/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.model;

/**
 *
 * @author tungt
 */
public class LoaiSanPham {
    private int maSp;
    private String tenSP;

    public LoaiSanPham() {
    }

    public LoaiSanPham(int maSp, String tenSP) {
        this.maSp = maSp;
        this.tenSP = tenSP;
    }

    public int getMaSp() {
        return maSp;
    }

    public void setMaSp(int maSp) {
        this.maSp = maSp;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }
    
    @Override
    public String toString(){
        return this.tenSP;
    }
}
