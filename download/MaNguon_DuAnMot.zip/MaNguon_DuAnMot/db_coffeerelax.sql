﻿create database coffee_relax

use coffee_relax

--tao bang nhan vien
create table NhanVien (
	maNV nvarchar(7) primary key not null,
	tenNV nvarchar(50) not null,
	matKhau nvarchar(50) not null,
	sdt varchar(10) not null,
	vaiTro bit not null, 
	cccd varchar(12) not null, 
	email varchar(100) not null,
	gioiTinh bit not null,
	trangThai bit not null,
	ngaySinh date not null,
	diaChi nvarchar(max) not null,
	hinhAnh nvarchar(max)
);

--tao bang loai nuoc
create table LoaiNuoc (
	maLoai int identity(1,1) primary key not null,
	tenLoai nvarchar(50) not null,
)

--tao bang ban
create table Ban(
	maBan int primary key not null,
	tenBan nvarchar(50) not null
)
--tao bang san pham
create table SanPham (
	maSP nvarchar(7) primary key not null,
	tenSP nvarchar(max) not null,
	loai int foreign key references LoaiNuoc(maLoai) not null,
	gia float not null,
	hinhAnh nvarchar(max) null,
)

-- tạo bảng Order
create table Orders(
	maOrder int identity(1,1) primary key,
	maBan int foreign key references Ban(maBan),
	maMon nvarchar(7) foreign key references SanPham(maSP),
	maNV nvarchar(7) foreign key references NhanVien(maNV)
)

--tao bang hoadon
create table HoaDon (
	maHD int identity(1,1) primary key not null,
	maBan int foreign key references Ban(maBan),
	ngayTao date,
	nhanVien nvarchar(7) foreign key references NhanVien(maNV),
)

--tao bang chi tiet hoa don
create table ChiTietHoaDon (
	maHDCT int identity(1,1) primary key,
	maHD int foreign key references hoadon(maHD),
	maSP nvarchar(7) references sanpham(maSP),
	donGia float,
	soLuong int,
	thanhTien float
)

insert into LoaiNuoc(tenLoai) values ( N'Cafe'),
									(N'Trà'),
									(N'Đá xay')

insert into ban 
values(1,'Bàn 1'),(2,'Bàn 2')
		,(3,'Bàn 4'),(4,'Bàn 4'),(5,'Bàn 5'),(6,'Bàn 6')
		,(7,'Bàn 7'),(8,'Bàn 8'),(9,'Bàn 9'),(10,'Bàn 10'),(11,'Bàn 11'),
		(12,'Bàn 12')


insert into nhanvien values ('admin','admin','admin','0931242511',1,'091234567899','admin@gmail.com',0,1,'2003-5-23','can tho','1.png')
insert into nhanvien values ('nv001','thien','123','0931242512',0,'091234567899','thien01@gmail.com',0,1,'2003-5-23','can tho','1.png')
insert into nhanvien values ('nv002','thien','123','0931242513',0,'091234567899','thien02@gmail.com',0,1,'2003-5-23','can tho','1.png')


insert into SanPham (maSP, tenSP, loai, gia, hinhAnh) values ('sp01',N'Cafe đá',1,20000, null),
													('sp02',N'Trà đào',2,30000, null),	
													('sp03',N'Matcha đá xay',3,40000, null)

insert into orders (maBan, maMon, maNV) values	(1,'sp01','nv001'),
												(3,'sp02','nv001'),
												(4,'sp03','nv002'),
												(2,'sp02','nv001')
											  

insert into hoadon (maBan, ngayTao, nhanVien) values (1,GETDATE(), 'nv001'),
													 (3,GETDATE(), 'nv001')

insert into chitiethoadon (maHD, maSP, donGia, soLuong, thanhTien) values (1, 'sp01',40000,2,80000)
-------------------------------------------------------------------------------------------------------------------------------------------------------
select * from sanpham
select * from nhanvien

select b.maHD, d.maBan, b.maSP, c.tenSP, b.donGia, b.soLuong, b.thanhTien from HoaDon a , ChiTietHoaDon b, SanPham c, ban d
where a.maHD = b.maHD and b.maSP = c.maSP and a.maBan = d.maBan and a.maBan = 1

select b.maHD, b.maBan, ngayTao, nhanVien, maSP, soLuong, thanhTien, dichVu, SUM(b.tongTien) as tongtien from hoadon a, chitiethoadon b 
where a.maHD=b.maHD and a.maBan = b.maBan
group by b.maHD, b.maBan, ngayTao, nhanVien, maSP, soLuong, thanhTien, dichVu

select  maban, mamon, count(maMon) as soluong, manv from orders 
group by maBan, maMon, maNV

select count(maMon) as soluong from orders 

select maMon,COUNT(maMon) as soluong from orders where maBan =2 and maMon = 'sp01' group by maMon


select * from Orders where maBan =1 group by manv, maban, maOrder, maMon

select maban, mamon, sum(soLuong) as soluong from Orders where maban = 1 group by maban, mamon

delete from Orders where maMon = 'sp03'

select top 1 maHD from HoaDon order by maHD desc
select * from HoaDon
select * from ChiTietHoaDon

select b.tenSP, count(masp) as 'sl', sum(b.gia) as 'thanhtien' from orders a, sanpham b, Ban c
where a.maBan = c.maBan and b.maSP = a.maMon
group by b.tenSP, b.gia