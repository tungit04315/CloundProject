$(function() {
	$("#formFile").change(function(event) {
		var x = event.target.files[0].name
		$("#Filename").val(x)
	});
	
	$("#deleteFile").click(function(){
		$("#Filename").val("")
	});
})