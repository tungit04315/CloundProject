package com.poly.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poly.entity.ProductType;

public interface ProductTypeDAO extends JpaRepository<ProductType, Integer>{

}
