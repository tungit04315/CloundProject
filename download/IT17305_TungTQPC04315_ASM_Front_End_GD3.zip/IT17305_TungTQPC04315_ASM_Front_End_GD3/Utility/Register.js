const app = angular.module("myapp", []);

app.controller("myctrl", function($scope, $rootScope, $http) {
    $rootScope.students = [];


    $http.get("../db/students.js").then(function(response) {
        $rootScope.students = response.data;
    });

    $scope.Register = function() {

        $scope.student = {};

        $rootScope.students.forEach(student => {
            if (student.email != $scope.student) {

                $rootScope.students.push(angular.copy($scope.student));
                swal({
                    title: "Đăng Ký Thành Công!",
                    text: "Tài Khoản Đã Được Đăng Ký!",
                    icon: "success",
                    button: "OK!",
                });
            } else {
                swal({
                    title: "Đăng Nhập Thất Bại!",
                    text: "Vui Lòng Kiểm Tra Tên Đăng Nhập Hoặc Mật Khẩu!",
                    icon: "warning",
                    button: "OK!",
                });
            }
        });

        // if (review == true) {

        // } else {

        // }

    }
});