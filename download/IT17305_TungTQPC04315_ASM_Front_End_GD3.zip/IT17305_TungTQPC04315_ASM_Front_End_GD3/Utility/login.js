var app = angular.module("myapp", []);
app.controller("myctrl", function($rootScope, $scope, $http) {
    $rootScope.students = [];

    $http.get("../db/students.js").then(function(response) {
        $rootScope.students = response.data;
    })

    $scope.login = function() {
        var exist = false;
        $rootScope.student = {
            username: "",
            password: "",
            fullname: "",
            email: "",
            gender: "",
            birthday: "",
            schoolfee: 0,
            marks: 0
        };
        $rootScope.students.forEach(st => {
            // console.log($rootScope.students);
            if (st.username == $scope.username && st.password == $scope.password) {
                exist = true;
                $rootScope.student.fullname = st.fullname;
                $rootScope.student.username = st.username;
                $rootScope.student.password = st.password;
                $rootScope.student.email = st.email;
                $rootScope.student.birthday = st.birthday;
                $rootScope.student.schoolfee = st.schoolfee;
                $rootScope.student.gender = st.gender;
            }
        });

        if (exist == true) {
            $rootScope.user = String($scope.username);
            window.location.href = "/html/index.html"
        } else {
            swal({
                title: "Đăng Nhập Thất Bại!",
                text: "Vui Lòng Kiểm Tra Tên Đăng Nhập Hoặc Mật Khẩu!",
                icon: "warning",
                button: "OK!",
            });
        }

    }
});