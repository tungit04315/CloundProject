// var app = angular.module("myapp", []);

var app = angular.module("myapp", ["ngRoute"]);

// sử dụng ng-route
app.config(function($routeProvider) {
    console.log("routeProvider", $routeProvider);
    $routeProvider
        .when("/Register", {
            templateUrl: "register.html"
        })
        .when("/forgetPassword", {
            templateUrl: "forgetPassword.html"
        })
        .when("/subjects", {
            templateUrl: "subjects.html"
        })
        .when("/Login", {
            templateUrl: "Login.html"
        })
        .when("/Viewtest/:idmh/:tenMH", {
            templateUrl: "Viewtest.html",
            controller: "TestLogin"
        })
        .when("/personal", {
            templateUrl: "personalPage.html",
        })
        .otherwise({
            redirectTo: "/"
        });
});

// lấy dữ liệu sinh viên
app.controller("mainController", function($scope, $http, $rootScope) {
    if (!localStorage.getItem("students")) {
        $http.get("../db/Students.json").then(function(response) {
            $rootScope.students = response.data;
            localStorage.setItem("students", JSON.stringify($rootScope.students));
        }, function(response) {
            swal({
                title: "Lỗi!",
                text: "Vui Lòng Kiểm Tra Lại Dữ Liệu!",
                icon: "warning",
                button: "OK!",
            });
        });
    }
});

// lấy dữ liệu môn học
app.controller("myctrlSubject", function($scope, $http, $rootScope, $routeParams) {
    $scope.supp = [];
    $http.get("../db/Subjects.json").then(function(response) {
        $scope.supp = response.data;
    }, function(response) {
        swal({
            title: "Lỗi!",
            text: "Không Có Dữ Liệu!",
            icon: "warning",
            button: "OK!",
        });
    })

    $scope.begin = 0;
    $scope.pageCount = Math.ceil($scope.supp.length / 8);

    $scope.first = function() {
        $scope.begin = 0
    }

    $scope.next = function() {
        if ($scope.begin < $scope.supp.length - 8) {
            $scope.begin += 8;
        } else {
            $scope.begin = 0;
        }
    }
    $scope.prev = function() {
        if ($scope.begin <= 0) {
            $scope.begin = $scope.supp.length - 8;
        } else {
            $scope.begin -= 8;
        }
    }
    $scope.last = function() {
        $scope.begin = ($scope.pageCount - 1) * 8;
    }

});

// đăng nhập
app.controller("myctrl", function($scope, $http, $rootScope) {

    // List Students -> Local Storage 
    let exits = false;
    $rootScope.students = [];
    $rootScope.index = 0;
    if (localStorage.getItem("students")) {
        $rootScope.students = JSON.parse(localStorage.getItem("students"));
    }
    // $http.get("../db/students.js").then(function(response) {
    //     $rootScope.students = response.data;
    // })
    $scope.login = function() {
        $rootScope.student = {
            username: "",
            password: "",
            fullname: "",
            email: "",
            gender: "",
            birthday: "",
            schoolfee: 0,
            marks: 0
        };

        $rootScope.students.forEach(st => {
            console.log($rootScope.students);
            if ($scope.user.Username == st.username && $scope.user.Password == st.password) {
                // console.log("Điều Kiện " + exits);
                exits = true;
                // $scope.student.fullname = st.fullname;
                // $scope.student.username = st.username;
                // $scope.student.password = st.password;
                // $scope.student.email = st.email;
                // $scope.student.birthday = st.birthday;
                // $scope.student.schoolfee = st.schoolfee;
                // $scope.student.gender = st.gender;

                localStorage.setItem("username", st.username);
                localStorage.setItem("fullname", st.fullname);
                localStorage.setItem("email", st.email);

            }
        });

        if (exits == true) {
            // $rootScope.user = String($scope.username);

            window.location.href = "/html/index.html"
        } else {
            console.log(exits);
            swal({
                title: "Đăng Nhập Thất Bại!",
                text: "Vui Lòng Kiểm Tra Tên Đăng Nhập Hoặc Mật Khẩu!",
                icon: "warning",
                button: "OK!",
            });
        }

    }

    $scope.Out = function() {
        localStorage.setItem("username", " ");
        localStorage.setItem("fullname", " ");
        localStorage.setItem("email", " ");
        window.location.href = "/html/index.html"
    }
});
// đăng ký
app.controller("myctrl_res", function($scope, $http, $rootScope) {

    $rootScope.students = [];
    let exits = false;
    if (localStorage.getItem("students")) {
        $rootScope.students = JSON.parse(localStorage.getItem("students"));
    }
    $scope.Register = function() {
        // console.log("new student", student);
        $rootScope.students.forEach(st => {
            console.log($rootScope.students);
            if ($scope.student.email != st.email) {
                exits = true;
                alert(st.email)
                alert($scope.student.email)
            }
        });
        if (exits == true) {
            swal({
                title: "Đăng Ký Thành Công!",
                text: "Bạn Đã Đăng Ký Tài Khoản Thành Công!",
                icon: "success",
                button: "OK!",
            });

            $rootScope.students.push(angular.copy($scope.student));
            // console.log("students registration:", $rootScope.students);
            localStorage.setItem("students", JSON.stringify($rootScope.students));
        } else {
            swal({
                title: "Đăng Ký Không Thành Công!",
                text: "Email Đã Được Đăng Ký Hoặc Nhập Thiếu Thông Tin!",
                icon: "warning",
                button: "OK!",
            });
        }

    };
});
// quên mật khẩu
app.controller("myctrl_forges", function($scope, $http, $rootScope) {
    $scope.Forges = function() {
        if (localStorage.getItem("students")) {
            $rootScope.students = JSON.parse(localStorage.getItem("students"));
            for (let i = 0; i < $rootScope.students.length; i++) {
                if ($scope.username == $rootScope.students[i].username && $scope.email == $rootScope.students[i].email) {
                    swal({
                        title: "Mật Khẩu!",
                        text: "Thông Tin Mật Khẩu Của Bạn " + $rootScope.students[i].password + "!",
                        icon: "success",
                        button: "OK!",
                    });
                }
            }
        }
    }

});
// lấy thông tin tài khoản
app.controller("Personal_information", function($scope, $http, $rootScope) {
    var fullname = localStorage.getItem("fullname");
    var email = localStorage.getItem("email");
    var usernames = localStorage.getItem("username");

    console.log(usernames);

    if (fullname != null && fullname != " ") {
        // console.log(fullname);
        $scope.FullName = fullname;
        $scope.email = email;
        $scope.login_f = true;
        $scope.resign_f = true;
        $scope.forgetpass_f = true;
        $scope.Personal_infor = true;
    } else {
        $scope.login_f = false;
        $scope.resign_f = false;
        $scope.forgetpass_f = false;
        $scope.Personal_infor = false;
    }

    if (localStorage.getItem("students")) {
        $rootScope.students = JSON.parse(localStorage.getItem("students"));
        for (let i = 0; i < $rootScope.students.length; i++) {
            if (usernames == $rootScope.students[i].username) {
                $scope.student = angular.copy($rootScope.students[i]);
            }
        }
    }

    $scope.savePersonal = function() {
        for (let i = 0; i < $rootScope.students.length; i++) {
            if (usernames == $rootScope.students[i].username) {
                $rootScope.students[i] = $scope.student;
                localStorage.setItem("students", JSON.stringify($rootScope.students));
                swal({
                    title: "Cập Nhật Thành Công!",
                    text: "Thông Tin Đã Được Cập Nhật!",
                    icon: "success",
                    button: "OK!",
                });
            }
        }

    }
});

// kiểm tra đăng nhập
app.controller("TestLogin", function($scope, $http, $routeParams, $interval) {
    if (localStorage.getItem("username") == " " || localStorage.getItem("username") == null) {
        swal({
            title: "Lỗi!",
            text: "Bạn Chưa Đăng Nhập!",
            icon: "warning",
            button: "Quay Lại!",
        });

    } else {
        var idmh = $routeParams.idmh;
        $scope.anhienKQ = true;
        $scope.nameSubject = $routeParams.tenMH;
        $scope.listch = [];
        $scope.indexch = 1;
        $scope.startTest = 0;
        $scope.sumPoint = 0;

        $http.get("/db/Quizs/" + idmh + ".js").then(function(d) {
            $scope.listch = d.data;
        })

        $scope.cautl = {
            idtl: ''
        };
        var listtl = [];


        $scope.chonctl = function() {
            var idch1 = $scope.cautl.idtl.substr(0, $scope.cautl.idtl.indexOf(","));
            var idtl1 = $scope.cautl.idtl.substr($scope.cautl.idtl.indexOf(",") + 1, $scope.cautl.idtl.length);
            var kt = true;

            if ($scope.cautl.idtl != '') {
                if (listtl != '') {
                    for (let i = 0; i < listtl.length; i++) {
                        if (listtl[i].idch == idch1) {
                            listtl.splice(i, 1, {
                                idch: idch1,
                                idtl: idtl1
                            });
                            kt = false;
                            break;
                        }
                    }
                    if (kt) {
                        listtl.push({
                            idch: idch1,
                            idtl: idtl1
                        });
                    }
                } else {
                    listtl.push({
                        idch: idch1,
                        idtl: idtl1
                    });
                }
            }

        }


        $scope.tinhdiem = function() {
            $http.get("/db/Quizs/" + idmh + ".js").then(function(d) {
                var listch1 = d.data;
                var listnew = [];
                $scope.chonctl();
                if (listtl.length < listch1.length) {
                    listnew = listtl;
                    for (let i = 0; i < listch1.length; i++) {
                        if (listtl[i] == undefined) {
                            listnew.push({
                                idch: listch1[i].Id.toString(),
                                idtl: ''
                            });
                        } else if (listtl[i].idch == '') {
                            listnew.splice(i, 1, {
                                idch: listch1[i].Id.toString(),
                                idtl: ''
                            });
                        }
                    }
                }

                if (listtl != '') {
                    var diem = 0;
                    listtl.forEach(element1 => {
                        listch1.forEach(element2 => {
                            if (element1.idch == element2.Id) {
                                if (element1.idtl == element2.AnswerId) {
                                    diem += element2.Marks;
                                }
                            }
                        });
                    });
                    $scope.sumPoint = (10 / listch1.length) * diem;
                    $scope.anhienKQ = false;
                    $scope.showDapan = function(idch, idda) {
                        var kq = "";
                        listch1.forEach(element1 => {
                            listtl.forEach(element2 => {
                                if (idch == element1.Id && idch == element2.idch) {
                                    if (idda == element1.AnswerId) {
                                        kq = "dung";
                                    } else {
                                        if (idda == element2.idtl) {
                                            kq = "sai";
                                        } else {
                                            kq = "binhthuong";
                                        }
                                    }
                                    if (element2.idtl == '') {
                                        kq = "binhthuong";
                                    }
                                }
                            });
                        });
                        return kq;
                    }

                    $scope.tdtungcau = function(idch) {
                        var tinhdiem1c = false;
                        listch1.forEach(element1 => {
                            listtl.forEach(element2 => {
                                if (idch == element1.Id && idch == element2.idch) {
                                    if (element1.AnswerId == element2.idtl) {
                                        tinhdiem1c = true;
                                    } else {
                                        tinhdiem1c = false;
                                    }
                                }
                            });
                        });
                        if (tinhdiem1c) {
                            return 1;
                        } else return 0;
                    }
                } else {
                    $scope.sumPoint = 0;
                    $scope.anhienKQ = false;
                }
            })
        }

        var historycheck = function(index) {
            listtl.forEach(element => {
                if (element.idch == $scope.listch[index].Id) {
                    $scope.cautl.idtl = element.idch + "," + element.idtl;
                }
            });
        }

        $scope.countDown = 50;
        const stop = $interval(function() {
            if ($scope.countDown > 0) {
                $scope.countDown--;
                const totalMinutes = Math.floor($scope.countDown / 60);
                const seconds = $scope.countDown % 60;
                const minutes = totalMinutes % 60;
                $scope.minutes = minutes;
                $scope.seconds = seconds;
            } else if ($scope.countDown == 0) {
                $scope.tinhdiem();
                $interval.cancel(stop);
            }


        }, 1000, 0);

        $scope.nextch = function() {
            if ($scope.startTest < $scope.listch.length - 1) {
                $scope.startTest += 1;
                $scope.indexch += 1;
            }
            historycheck($scope.startTest);

        }

        $scope.prevch = function() {
            if ($scope.startTest > 0) {
                $scope.startTest -= 1;
                $scope.indexch -= 1;
            }
            historycheck($scope.startTest);
        }

    }
});