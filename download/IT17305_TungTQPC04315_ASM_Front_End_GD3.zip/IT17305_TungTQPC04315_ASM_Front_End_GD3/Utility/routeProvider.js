var app = angular.module("myapp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider.when("/1", {
        templateUrl: "supject.html"
    })
});